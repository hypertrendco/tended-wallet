// Applies sql/*.sql in order, once each. Skips gracefully when DATABASE_URL is not set
// (so a first Vercel build succeeds and the app shows its /setup page).
import fs from 'node:fs';
import path from 'node:path';
import pg from 'pg';

const url = process.env.DATABASE_URL;
if (!url) { console.log('[migrate] DATABASE_URL not set — skipping migrations'); process.exit(0); }

const local = /localhost|127\.0\.0\.1/.test(url);
const client = new pg.Client({ connectionString: url, ssl: local ? false : { rejectUnauthorized: false } });
await client.connect();
await client.query(`CREATE TABLE IF NOT EXISTS schema_migrations (name text PRIMARY KEY, applied_at timestamptz NOT NULL DEFAULT now())`);
const dir = path.join(process.cwd(), 'sql');
const files = fs.readdirSync(dir).filter(f => f.endsWith('.sql')).sort();
for (const f of files) {
  const { rowCount } = await client.query('SELECT 1 FROM schema_migrations WHERE name=$1', [f]);
  if (rowCount) continue;
  console.log('[migrate] applying', f);
  await client.query('BEGIN');
  try {
    await client.query(fs.readFileSync(path.join(dir, f), 'utf8'));
    await client.query('INSERT INTO schema_migrations(name) VALUES ($1)', [f]);
    await client.query('COMMIT');
  } catch (e) { await client.query('ROLLBACK'); console.error(e); process.exit(1); }
}
console.log('[migrate] up to date');
await client.end();
