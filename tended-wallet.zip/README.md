# Tended — community care credit wallet

Members earn credits by volunteering with verified community organizations and redeem them
for healthcare services and products from participating providers, using QR codes and NFC.

**Stack:** Next.js 15 (App Router, server actions) · Neon Postgres · Auth0 passwordless email · Tailwind v4 · deploys to Vercel.

## Roles
| Role | Can |
|---|---|
| Member | Check in/out of shifts by QR, log hours, pay by scanning a provider QR, show a one-time pay code, tap an NFC card + PIN, gift credits, browse the provider catalog |
| Verifier org (staff/owner) | Create opportunities with printable check-in QR, approve/adjust/reject hours (credits minted on approval), log hours for a member |
| Provider org (staff/owner) | Checkout: show a QR charge, scan a member pay code, or read an NFC card; manage catalog; counter QR poster & NFC sticker; request settlement |
| Network admin | Approve/suspend orgs and members, set base rate + activity multipliers, caps and limits, view supply & integrity, reverse transactions, manual grants, settle provider credits, export ledger CSV |

## Credit model
`credits = hours × base rate × activity multiplier` (default 1 credit/hour; multipliers configurable, e.g. licensed service ×2).

## Ledger
Double-entry, amounts in integer hundredths. Credits are minted from a system **issuance** wallet
(its negative balance = credits in circulation) and retired back to it on provider settlement.
Every money movement goes through `post_txn()` in Postgres, which locks wallets in a fixed order,
rejects unbalanced or overdrawing transactions, and enforces the optional balance cap. Claim approval,
QR payment, pay-code redemption and reversals are each a single atomic SQL function. The admin
overview continuously checks the `ledger_integrity` view.

## Payment methods
- **QR charge** – provider shows a QR for a specific amount; member scans (any camera app works) and confirms. Single-use, expires (default 15 min).
- **Member pay code** – member shows a signed, single-use QR valid ~90 s (optional spending limit); provider scans and charges.
- **NFC card** – member writes a card/sticker/fob (NTAG213/215/216) from their wallet; provider reads it on Android Chrome and the member enters a PIN. Per-tap limit; 5 wrong PINs freezes the card.
- **NFC counter sticker / counter QR** – opens the provider’s payment page. Works on iPhone and Android (native URL tags).

Web NFC reading/writing works in Chrome on Android only; iPhones can still use QR and URL stickers.

## Setup
1. Create the Vercel project, add **Neon** from Vercel Storage (sets `DATABASE_URL`).
2. Auth0: create a Regular Web Application, enable **Passwordless → Email** for it, set Allowed Callback URL `https://<app>/auth/callback` and Allowed Logout URL `https://<app>`.
3. Add env vars from `.env.example`. Redeploy — `npm run build` applies SQL migrations in `sql/` automatically.
4. Sign in with `BOOTSTRAP_ADMIN_EMAIL` → **Admin**.

Local: `DATABASE_URL=… DEV_LOGIN=1 npm run build:app && npm start` (demo sign-in, no email verification).

## Tests
`TEST_DATABASE_URL=postgres://postgres@localhost:5432/postgres npm test` — ledger tests against real
Postgres (minting math, double-spend, expiry, single-use codes, 20-way concurrent spend race,
balance cap, reversals, integrity).

## Important
Credits are a community exchange unit, not money: no cash value, not purchasable or withdrawable.
Before launch, have counsel review how credits interact with healthcare regulations (e.g. beneficiary
inducement / anti-kickback rules when providers bill Medicare/Medicaid), tax treatment of services,
and state money-transmission rules. Keep PHI out of memos and catalog names.
