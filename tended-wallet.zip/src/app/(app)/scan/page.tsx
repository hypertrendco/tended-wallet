import ScanRouter from '@/components/ScanRouter';
import { requireUser } from '@/lib/session';
export default async function Scan() {
  await requireUser();
  return (
    <div className="mx-auto max-w-md space-y-4">
      <h1 className="h1">Scan</h1>
      <p className="muted">Scan a provider’s payment QR to pay, or a volunteer shift QR to check in and out.</p>
      <ScanRouter />
    </div>
  );
}
