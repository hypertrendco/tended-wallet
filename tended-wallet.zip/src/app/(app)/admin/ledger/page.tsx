import ActionForm from '@/components/ActionForm';
import Submit from '@/components/Submit';
import { reverseTxnAction } from '@/app/actions/admin';
import { q } from '@/lib/db';
import { fmt } from '@/lib/money';
import { dt } from '@/lib/time';

const KINDS = ['mint', 'payment', 'transfer', 'reversal', 'retire', 'adjustment'];

export default async function Ledger({ searchParams }: { searchParams: Promise<{ kind?: string; q?: string }> }) {
  const { kind = '', q: term = '' } = await searchParams;
  const txns = await q<any>(`
    SELECT t.*, cb.email AS by_email,
      json_agg(json_build_object('amount', e.amount, 'who', coalesce(o.name, u.email, w.system_key)) ORDER BY e.amount) AS legs
    FROM txns t JOIN entries e ON e.txn_id=t.id JOIN wallets w ON w.id=e.wallet_id
    LEFT JOIN orgs o ON o.id=w.org_id LEFT JOIN users u ON u.id=w.user_id LEFT JOIN users cb ON cb.id=t.created_by
    WHERE ($1='' OR t.kind=$1)
    GROUP BY t.id, cb.email
    HAVING $2='' OR bool_or(coalesce(o.name,'') ILIKE '%'||$2||'%' OR coalesce(u.email,'') ILIKE '%'||$2||'%' OR coalesce(t.memo,'') ILIKE '%'||$2||'%')
    ORDER BY t.created_at DESC LIMIT 150`, [KINDS.includes(kind) ? kind : '', term.slice(0, 60)]);
  return (
    <div className="space-y-3">
      <form className="flex flex-wrap gap-2">
        <select name="kind" defaultValue={kind} className="input w-auto"><option value="">All types</option>{KINDS.map((k) => <option key={k}>{k}</option>)}</select>
        <input name="q" defaultValue={term} className="input flex-1 min-w-40" placeholder="Member email, org, memo" />
        <button className="btn-secondary">Filter</button>
        <a href={`/api/admin/ledger?kind=${kind}`} className="btn-ghost">Export CSV</a>
      </form>
      <div className="card overflow-x-auto">
        <table className="table">
          <thead><tr><th>When</th><th>Type</th><th>Memo</th><th>From → To</th><th>Credits</th><th></th></tr></thead>
          <tbody>{txns.map((t) => {
            const from = t.legs.filter((l: any) => l.amount < 0).map((l: any) => l.who).join(', ');
            const to = t.legs.filter((l: any) => l.amount > 0).map((l: any) => l.who).join(', ');
            return (
              <tr key={t.id} className={t.reversed ? 'opacity-50' : ''}>
                <td className="whitespace-nowrap">{dt(t.created_at)}</td>
                <td>{t.kind}<span className="muted block text-xs">{t.method}</span></td>
                <td>{t.memo}<span className="muted block text-xs">by {t.by_email || 'system'}{t.reversed && ' · reversed'}</span></td>
                <td className="text-xs">{from} → {to}</td>
                <td className="tabular-nums font-semibold">{fmt(t.amount)}</td>
                <td>{!t.reversed && t.kind !== 'reversal' && (
                  <details><summary className="cursor-pointer text-xs text-red-700">Reverse</summary>
                    <ActionForm action={reverseTxnAction} className="mt-1 flex gap-1">
                      <input type="hidden" name="txn_id" value={t.id} />
                      <input name="reason" required placeholder="Reason" className="input py-1 text-sm" />
                      <Submit className="btn-danger px-2 py-1">Go</Submit>
                    </ActionForm>
                  </details>)}</td>
              </tr>);
          })}</tbody>
        </table>
      </div>
    </div>
  );
}
