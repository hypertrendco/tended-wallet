import ActionForm from '@/components/ActionForm';
import Submit from '@/components/Submit';
import { setUserAction } from '@/app/actions/admin';
import { q } from '@/lib/db';
import { fmt } from '@/lib/money';
import { dDate } from '@/lib/time';

export default async function AdminUsers({ searchParams }: { searchParams: Promise<{ q?: string }> }) {
  const { q: term = '' } = await searchParams;
  const users = await q<any>(`SELECT u.*, w.balance,
      (SELECT coalesce(sum(minutes),0)::int FROM hour_claims c WHERE c.user_id=u.id AND c.status='approved') AS minutes
    FROM users u JOIN wallets w ON w.user_id=u.id
    WHERE $1='' OR u.email ILIKE '%'||$1||'%' OR u.name ILIKE '%'||$1||'%' ORDER BY u.created_at DESC LIMIT 200`, [term.slice(0, 60)]);
  return (
    <div className="space-y-3">
      <form className="flex gap-2"><input name="q" defaultValue={term} className="input" placeholder="Search name or email" /><button className="btn-secondary">Search</button></form>
      <div className="card overflow-x-auto">
        <table className="table">
          <thead><tr><th>Member</th><th>Joined</th><th>Hours</th><th>Balance</th><th>Status</th><th></th></tr></thead>
          <tbody>{users.map((u) => (
            <tr key={u.id}>
              <td>{u.name || '—'}<span className="muted block text-xs">{u.email}{u.is_admin && ' · admin'}</span></td>
              <td>{dDate(u.created_at)}</td><td>{Math.round(u.minutes / 6) / 10}</td><td className="tabular-nums">{fmt(u.balance)}</td>
              <td>{u.status}</td>
              <td className="whitespace-nowrap">
                <ActionForm action={setUserAction} className="inline-flex flex-wrap gap-1">
                  <input type="hidden" name="user_id" value={u.id} />
                  <Submit name="op" value={u.status === 'active' ? 'suspend' : 'activate'} className="btn-ghost px-2 py-1">{u.status === 'active' ? 'Suspend' : 'Activate'}</Submit>
                  <Submit name="op" value="admin" className="btn-ghost px-2 py-1">{u.is_admin ? 'Remove admin' : 'Make admin'}</Submit>
                </ActionForm>
              </td>
            </tr>))}</tbody>
        </table>
      </div>
    </div>
  );
}
