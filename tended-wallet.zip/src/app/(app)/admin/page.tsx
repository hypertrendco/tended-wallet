import Link from 'next/link';
import { one, q } from '@/lib/db';
import { fmt, hours } from '@/lib/money';
import { dDate } from '@/lib/time';

export default async function AdminHome() {
  const [s, integ, flags, byMethod, daily] = await Promise.all([
    one<any>(`SELECT
      (SELECT -balance FROM wallets WHERE system_key='issuance') AS circulating,
      (SELECT coalesce(sum(amount),0)::bigint FROM txns WHERE kind='mint' AND NOT reversed) AS minted,
      (SELECT coalesce(sum(amount),0)::bigint FROM txns WHERE kind='payment' AND NOT reversed) AS redeemed,
      (SELECT coalesce(sum(amount),0)::bigint FROM txns WHERE kind='retire') AS retired,
      (SELECT coalesce(sum(balance),0)::bigint FROM wallets WHERE owner_type='user') AS member_bal,
      (SELECT coalesce(sum(balance),0)::bigint FROM wallets WHERE owner_type='org') AS org_bal,
      (SELECT coalesce(sum(minutes),0)::int FROM hour_claims WHERE status='approved') AS minutes,
      (SELECT count(*)::int FROM users) AS members,
      (SELECT count(*)::int FROM orgs WHERE status='active' AND kind<>'provider') AS verifiers,
      (SELECT count(*)::int FROM orgs WHERE status='active' AND kind<>'verifier') AS providers`),
    one<any>(`SELECT * FROM ledger_integrity`),
    q<any>(`SELECT c.*, u.email, o.name AS org_name FROM hour_claims c JOIN users u ON u.id=c.user_id JOIN orgs o ON o.id=c.org_id
            WHERE c.flagged IS NOT NULL AND c.created_at > now() - interval '30 days' ORDER BY c.created_at DESC LIMIT 20`),
    q<any>(`SELECT method, count(*)::int n, sum(amount)::bigint total FROM txns WHERE kind='payment' AND NOT reversed GROUP BY method ORDER BY total DESC`),
    q<any>(`SELECT d::date AS day,
       coalesce((SELECT sum(amount) FROM txns WHERE kind='mint' AND NOT reversed AND created_at::date=d::date),0)::bigint AS minted,
       coalesce((SELECT sum(amount) FROM txns WHERE kind='payment' AND NOT reversed AND created_at::date=d::date),0)::bigint AS redeemed
       FROM generate_series(current_date - 13, current_date, interval '1 day') d ORDER BY d`),
  ]);
  const ok = integ.wallet_mismatches === 0 && integ.unbalanced_txns === 0 && integ.total_sum === 0;
  const max = Math.max(1, ...daily.map((d) => Math.max(d.minted, d.redeemed)));
  const tiles = [
    ['Credits in circulation', fmt(s.circulating)], ['Held by members', fmt(s.member_bal)], ['Held by providers', fmt(s.org_bal)],
    ['Total earned', fmt(s.minted)], ['Total redeemed', fmt(s.redeemed)], ['Settled / retired', fmt(s.retired)],
    ['Service hours', Math.round(s.minutes / 6) / 10], ['Members', s.members], ['Verifiers · Providers', `${s.verifiers} · ${s.providers}`],
  ];
  return (
    <div className="space-y-4">
      <div className={`card flex items-center gap-3 ${ok ? 'border-brand-200' : 'border-red-300 bg-red-50'}`}>
        <span className={`grid h-8 w-8 place-items-center rounded-full text-white ${ok ? 'bg-brand-600' : 'bg-red-600'}`}>{ok ? '✓' : '!'}</span>
        <div><p className="font-semibold">Ledger integrity {ok ? 'verified' : 'PROBLEM'}</p>
          <p className="muted">{integ.unbalanced_txns} unbalanced transactions · {integ.wallet_mismatches} wallet mismatches · net sum {integ.total_sum}</p></div>
      </div>
      <div className="grid grid-cols-2 gap-3 md:grid-cols-3">
        {tiles.map(([k, v]) => <div key={k} className="card"><p className="muted">{k}</p><p className="text-2xl font-bold tabular-nums">{v}</p></div>)}
      </div>
      <div className="grid gap-4 lg:grid-cols-2">
        <section className="card">
          <h2 className="h2">Last 14 days</h2>
          <div className="mt-3 flex h-40 items-end gap-1" role="img" aria-label="Credits earned and redeemed per day">
            {daily.map((d) => (
              <div key={d.day} className="flex h-full flex-1 items-end gap-px" title={`${d.day}: earned ${fmt(d.minted)}, redeemed ${fmt(d.redeemed)}`}>
                <div className="flex-1 rounded-t bg-brand-500" style={{ height: `${(d.minted / max) * 100}%` }} />
                <div className="flex-1 rounded-t bg-sun-400" style={{ height: `${(d.redeemed / max) * 100}%` }} />
              </div>
            ))}
          </div>
          <p className="muted mt-2 text-xs"><span className="inline-block h-2 w-2 rounded bg-brand-500" /> earned &nbsp; <span className="inline-block h-2 w-2 rounded bg-sun-400" /> redeemed</p>
        </section>
        <section className="card">
          <h2 className="h2 mb-2">Redemptions by method</h2>
          {!byMethod.length ? <p className="muted">No payments yet.</p> : (
            <table className="table"><thead><tr><th>Method</th><th>Count</th><th>Credits</th></tr></thead>
              <tbody>{byMethod.map((m) => <tr key={m.method}><td>{m.method.replace('_', ' ')}</td><td>{m.n}</td><td>{fmt(m.total)}</td></tr>)}</tbody></table>
          )}
        </section>
      </div>
      <section className="card overflow-x-auto">
        <h2 className="h2 mb-2">Flagged service claims (30 days)</h2>
        {!flags.length ? <p className="muted">No flags.</p> : (
          <table className="table"><thead><tr><th>Member</th><th>Org</th><th>Date</th><th>Time</th><th>Status</th><th>Flag</th></tr></thead>
            <tbody>{flags.map((c) => <tr key={c.id}><td>{c.email}</td><td><Link className="underline" href={`/orgs/${c.org_id}/claims`}>{c.org_name}</Link></td><td>{c.work_date}</td><td>{hours(c.minutes)}</td><td>{c.status}</td><td className="text-red-700">{c.flagged}</td></tr>)}</tbody></table>
        )}
      </section>
      <p className="muted text-xs">Stats as of {dDate(new Date())}.</p>
    </div>
  );
}
