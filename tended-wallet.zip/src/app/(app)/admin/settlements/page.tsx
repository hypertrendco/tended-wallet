import ActionForm from '@/components/ActionForm';
import Submit from '@/components/Submit';
import { settleAction } from '@/app/actions/admin';
import { q } from '@/lib/db';
import { fmt } from '@/lib/money';
import { dDate } from '@/lib/time';

export default async function Settlements() {
  const rows = await q<any>(`SELECT s.*, o.name, w.balance, u.email FROM settlement_requests s JOIN orgs o ON o.id=s.org_id JOIN wallets w ON w.org_id=o.id
    LEFT JOIN users u ON u.id=s.requested_by ORDER BY (s.status='pending') DESC, s.created_at DESC LIMIT 100`);
  return (
    <div className="space-y-3">
      <p className="muted">Providers request settlement for credits they’ve received. Pay them through your sponsor fund or agreement outside Tended, then mark settled here — the credits are retired from circulation.</p>
      {!rows.length && <div className="card muted">No settlement requests.</div>}
      {rows.map((r) => (
        <div key={r.id} className="card flex flex-wrap items-center justify-between gap-3">
          <div>
            <p className="font-semibold">{r.name} — {fmt(r.amount)} credits <span className="badge bg-black/5">{r.status}</span></p>
            <p className="muted text-xs">Requested {dDate(r.created_at)} by {r.email} · provider balance {fmt(r.balance)}{r.note ? ` · “${r.note}”` : ''}</p>
          </div>
          {r.status === 'pending' && (
            <ActionForm action={settleAction} className="flex flex-wrap gap-2">
              <input type="hidden" name="id" value={r.id} />
              <input name="reference" placeholder="Payment reference" className="input w-44 py-1.5" />
              <Submit name="decision" value="settle">Mark settled</Submit>
              <Submit name="decision" value="reject" className="btn-danger">Reject</Submit>
            </ActionForm>
          )}
        </div>
      ))}
    </div>
  );
}
