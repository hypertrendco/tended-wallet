import SubNav from '@/components/SubNav';
import { one } from '@/lib/db';
import { requireAdmin } from '@/lib/session';

export default async function AdminLayout({ children }: { children: React.ReactNode }) {
  await requireAdmin();
  const c = await one<any>(`SELECT (SELECT count(*)::int FROM orgs WHERE status='pending') AS orgs,
    (SELECT count(*)::int FROM settlement_requests WHERE status='pending') AS settle`);
  return (
    <div className="space-y-4">
      <h1 className="h1">Network admin</h1>
      <SubNav items={[
        { href: '/admin', label: 'Overview' },
        { href: '/admin/orgs', label: 'Organizations', badge: c.orgs },
        { href: '/admin/users', label: 'Members' },
        { href: '/admin/ledger', label: 'Ledger' },
        { href: '/admin/settlements', label: 'Settlements', badge: c.settle },
        { href: '/admin/settings', label: 'Settings' },
      ]} />
      {children}
    </div>
  );
}
