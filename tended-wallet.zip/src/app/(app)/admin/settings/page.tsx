import ActionForm from '@/components/ActionForm';
import Submit from '@/components/Submit';
import { adjustAction, saveActivityTypeAction, saveSettingsAction } from '@/app/actions/admin';
import { fmt } from '@/lib/money';
import { activityTypes } from '@/lib/queries';
import { settings } from '@/lib/session';

export default async function Settings() {
  const [s, types] = await Promise.all([settings(), activityTypes()]);
  const F = ({ id, label, hint, ...p }: any) => (
    <div><label className="label" htmlFor={id}>{label}</label><input id={id} name={id} className="input" {...p} />{hint && <p className="muted mt-1 text-xs">{hint}</p>}</div>
  );
  return (
    <div className="grid gap-4 lg:grid-cols-2">
      <section className="card">
        <h2 className="h2 mb-3">Network rules</h2>
        <ActionForm action={saveSettingsAction} className="grid gap-3 sm:grid-cols-2">
          <div className="sm:col-span-2"><F id="network_name" label="Network name" defaultValue={s.network_name} /></div>
          <F id="base_rate" label="Credits per hour (base)" defaultValue={s.base_rate / 100} inputMode="decimal" hint="Time-banking default is 1. Activity multipliers apply on top." />
          <F id="daily_hours_cap" label="Daily hours flag threshold" type="number" min={1} max={24} defaultValue={s.daily_minute_cap / 60} hint="Claims beyond this per member/day are flagged for review." />
          <F id="card_tx_limit" label="NFC card limit per tap" defaultValue={s.card_tx_limit / 100} inputMode="decimal" />
          <F id="max_balance" label="Max member balance" defaultValue={s.max_balance ? s.max_balance / 100 : ''} placeholder="No cap" inputMode="decimal" hint="Optional. Discourages hoarding." />
          <F id="pay_code_ttl_sec" label="Pay code lifetime (sec)" type="number" min={30} max={600} defaultValue={s.pay_code_ttl_sec} />
          <F id="request_ttl_min" label="QR charge lifetime (min)" type="number" min={1} max={120} defaultValue={s.request_ttl_min} />
          <label className="flex items-center gap-2 text-sm sm:col-span-2"><input type="checkbox" name="p2p_enabled" defaultChecked={s.p2p_enabled} className="h-4 w-4 accent-brand-600" /> Allow members to gift credits to each other</label>
          <div className="sm:col-span-2"><Submit>Save rules</Submit></div>
        </ActionForm>
      </section>
      <section className="card">
        <h2 className="h2 mb-1">Activity types & multipliers</h2>
        <p className="muted mb-3">Credits = hours × base rate × multiplier.</p>
        <ul className="divide-y divide-black/5">
          {types.map((t) => (
            <li key={t.id} className="py-2">
              <details>
                <summary className={`flex cursor-pointer justify-between ${t.active ? '' : 'opacity-50'}`}><span>{t.name}</span><span className="font-semibold">×{t.multiplier} · {fmt(Math.round(s.base_rate * t.multiplier))} cr/hr</span></summary>
                <ActionForm action={saveActivityTypeAction} className="mt-2 grid gap-2 sm:grid-cols-[1fr_6rem]">
                  <input type="hidden" name="id" value={t.id} />
                  <input name="name" defaultValue={t.name} className="input" aria-label="Name" />
                  <input name="multiplier" defaultValue={t.multiplier} className="input" aria-label="Multiplier" inputMode="decimal" />
                  <input name="description" defaultValue={t.description || ''} className="input sm:col-span-2" aria-label="Description" />
                  <label className="flex items-center gap-2 text-sm"><input type="checkbox" name="active" defaultChecked={t.active} className="accent-brand-600" /> Active</label>
                  <Submit className="btn-secondary">Save</Submit>
                </ActionForm>
              </details>
            </li>
          ))}
        </ul>
        <ActionForm action={saveActivityTypeAction} resetOnOk className="mt-3 grid gap-2 sm:grid-cols-[1fr_6rem_auto]">
          <input name="name" placeholder="New activity type" className="input" required />
          <input name="multiplier" placeholder="×1.0" defaultValue="1" className="input" inputMode="decimal" />
          <Submit className="btn-secondary">Add</Submit>
        </ActionForm>
      </section>
      <section className="card lg:col-span-2">
        <h2 className="h2 mb-1">Manual grant or debit</h2>
        <p className="muted mb-3">For corrections, welcome grants, or sponsored allocations. Always recorded in the ledger and audit log.</p>
        <ActionForm action={adjustAction} resetOnOk className="grid gap-2 sm:grid-cols-[1.5fr_7rem_8rem_2fr_auto]">
          <input name="email" type="email" placeholder="Member email" className="input" required />
          <input name="amount" placeholder="Credits" className="input" inputMode="decimal" required />
          <select name="direction" className="input"><option value="credit">Grant</option><option value="debit">Debit</option></select>
          <input name="memo" placeholder="Reason (required)" className="input" required />
          <Submit>Apply</Submit>
        </ActionForm>
      </section>
    </div>
  );
}
