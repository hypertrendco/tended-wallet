import Link from 'next/link';
import ActionForm from '@/components/ActionForm';
import Submit from '@/components/Submit';
import { setOrgStatusAction } from '@/app/actions/admin';
import { q } from '@/lib/db';
import { fmt } from '@/lib/money';
import { dDate } from '@/lib/time';

export default async function AdminOrgs() {
  const orgs = await q<any>(`SELECT o.*, w.balance, u.email AS creator FROM orgs o JOIN wallets w ON w.org_id=o.id LEFT JOIN users u ON u.id=o.created_by
    ORDER BY (o.status='pending') DESC, o.created_at DESC`);
  return (
    <div className="space-y-3">
      {!orgs.length && <div className="card muted">No organizations yet.</div>}
      {orgs.map((o) => (
        <div key={o.id} className={`card ${o.status === 'pending' ? 'border-sun-400' : ''}`}>
          <div className="flex flex-wrap items-start justify-between gap-2">
            <div>
              <p className="font-semibold"><Link href={`/orgs/${o.id}`} className="hover:underline">{o.name}</Link> <span className="badge bg-black/5">{o.kind}</span> <span className="badge bg-black/5">{o.status}</span></p>
              <p className="muted">{o.address || 'No address'}{o.npi ? ` · NPI ${o.npi}` : ''}{o.website ? ` · ${o.website}` : ''}</p>
              <p className="muted text-xs">Applied {dDate(o.created_at)} by {o.creator} · balance {fmt(o.balance)}</p>
              {o.description && <p className="mt-1 text-sm">{o.description}</p>}
            </div>
            <div className="flex flex-wrap gap-2">
              {o.status !== 'active' && <ActionForm action={setOrgStatusAction}><input type="hidden" name="org_id" value={o.id} /><input type="hidden" name="status" value="active" /><Submit>Approve</Submit></ActionForm>}
              {o.status === 'pending' && <ActionForm action={setOrgStatusAction}><input type="hidden" name="org_id" value={o.id} /><input type="hidden" name="status" value="rejected" /><Submit className="btn-danger">Reject</Submit></ActionForm>}
              {o.status === 'active' && <ActionForm action={setOrgStatusAction}><input type="hidden" name="org_id" value={o.id} /><input type="hidden" name="status" value="suspended" /><Submit className="btn-danger">Suspend</Submit></ActionForm>}
            </div>
          </div>
        </div>
      ))}
    </div>
  );
}
