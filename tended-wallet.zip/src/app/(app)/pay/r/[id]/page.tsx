import Link from 'next/link';
import { notFound } from 'next/navigation';
import PayConfirm from '@/components/PayConfirm';
import { payRequestAction } from '@/app/actions/wallet';
import { one } from '@/lib/db';
import { fmt } from '@/lib/money';
import { requireUser } from '@/lib/session';

export default async function PayRequest({ params }: { params: Promise<{ id: string }> }) {
  const { id } = await params;
  const user = await requireUser(`/pay/r/${id}`);
  if (!/^[0-9a-f-]{36}$/.test(id)) notFound();
  const r = await one<any>(`SELECT r.*, r.expires_at < now() AS expired, o.name AS org_name, o.address FROM payment_requests r JOIN orgs o ON o.id=r.org_id WHERE r.id=$1`, [id]);
  if (!r) notFound();
  if (r.status === 'paid' && r.paid_by === user.id) return (
    <div className="mx-auto max-w-md card text-center py-10" role="status">
      <div className="mx-auto grid h-16 w-16 place-items-center rounded-full bg-brand-600 text-3xl text-white">✓</div>
      <p className="mt-4 text-2xl font-bold">Paid. Thank you!</p>
      <p className="muted mt-1">{fmt(r.amount)} credits to {r.org_name}{r.memo ? ` · ${r.memo}` : ''}</p>
      <p className="muted">Remaining balance {fmt(user.balance)} credits</p>
      <Link href="/wallet" className="btn-secondary mt-6">Back to wallet</Link>
    </div>
  );
  const state = r.status === 'paid' ? 'This request was already paid.'
    : r.status === 'cancelled' ? 'The provider cancelled this request.' : r.expired ? 'This request expired. Ask for a new code.' : null;
  const short = user.balance < r.amount;
  return (
    <div className="mx-auto max-w-md space-y-4">
      <div className="card text-center py-8">
        <p className="muted">Pay</p>
        <p className="text-lg font-semibold">{r.org_name}</p>
        <p className="mt-3 text-5xl font-bold tabular-nums">{fmt(r.amount)}<span className="ml-2 text-lg text-black/50">credits</span></p>
        {r.memo && <p className="mt-2 text-black/70">{r.memo}</p>}
        {r.items?.length > 0 && (
          <ul className="mx-auto mt-4 max-w-xs text-left text-sm">
            {r.items.map((i: any) => <li key={i.id} className="flex justify-between border-b border-black/5 py-1"><span>{i.name}</span><span>{fmt(i.price)}</span></li>)}
          </ul>
        )}
      </div>
      {state ? <div className="card text-center">{state}</div> : (
        <div className="card space-y-3">
          <p className="muted text-center">Your balance: <b>{fmt(user.balance)}</b> credits{short && <span className="text-red-700"> — not enough to pay this</span>}</p>
          <PayConfirm action={payRequestAction} hidden={{ request_id: r.id }} label={`Pay ${fmt(r.amount)} credits`} disabled={short} />
        </div>
      )}
    </div>
  );
}
