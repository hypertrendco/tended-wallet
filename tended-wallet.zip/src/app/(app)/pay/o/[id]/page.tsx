import { notFound } from 'next/navigation';
import ProviderPay from '@/components/ProviderPay';
import { payProviderAction } from '@/app/actions/wallet';
import { one, q } from '@/lib/db';
import { requireUser } from '@/lib/session';

export default async function PayOrg({ params, searchParams }: { params: Promise<{ id: string }>; searchParams: Promise<{ via?: string }> }) {
  const { id } = await params;
  const { via } = await searchParams;
  const user = await requireUser(`/pay/o/${id}${via ? `?via=${via}` : ''}`);
  if (!/^[0-9a-f-]{36}$/.test(id)) notFound();
  const org = await one<any>(`SELECT * FROM orgs WHERE id=$1`, [id]);
  if (!org || org.kind === 'verifier') notFound();
  const items = await q<any>(`SELECT id, name, description, price, category FROM catalog_items WHERE org_id=$1 AND active ORDER BY category, name`, [id]);
  return (
    <div className="mx-auto max-w-md space-y-4">
      <div>
        <p className="muted">Pay provider</p>
        <h1 className="h1">{org.name}</h1>
        {org.address && <p className="muted">{org.address}</p>}
      </div>
      {org.status !== 'active' ? <div className="card">This provider is not currently accepting credits.</div>
        : <ProviderPay action={payProviderAction} orgId={org.id} items={items} balance={user.balance} via={via === 'nfc_tag' || via === 'qr_static' ? via : 'market'} />}
    </div>
  );
}
