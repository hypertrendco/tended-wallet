import { dt, dTime, today } from '@/lib/time';
import Link from 'next/link';
import ActionForm from '@/components/ActionForm';
import Submit from '@/components/Submit';
import { submitClaimAction } from '@/app/actions/earn';
import { q } from '@/lib/db';
import { fmt, hours } from '@/lib/money';
import { activityTypes } from '@/lib/queries';
import { requireUser, settings } from '@/lib/session';

const STATUS: Record<string, string> = { open: 'bg-sun-400/25 text-black', pending: 'bg-black/5 text-black/70', approved: 'bg-brand-50 text-brand-700', rejected: 'bg-red-50 text-red-700' };

export default async function Earn() {
  const user = await requireUser();
  const [st, types, orgs, opps, claims] = await Promise.all([
    settings(), activityTypes(),
    q<any>(`SELECT id, name FROM orgs WHERE status='active' AND kind IN ('verifier','both') ORDER BY name`),
    q<any>(`SELECT p.*, o.name AS org_name, a.name AS type_name, a.multiplier FROM opportunities p JOIN orgs o ON o.id=p.org_id JOIN activity_types a ON a.id=p.activity_type_id
            WHERE p.active AND o.status='active' AND (p.ends_at IS NULL OR p.ends_at > now() - interval '1 day') ORDER BY p.starts_at NULLS LAST LIMIT 30`),
    q<any>(`SELECT c.*, o.name AS org_name, a.name AS type_name, p.checkin_code FROM hour_claims c JOIN orgs o ON o.id=c.org_id JOIN activity_types a ON a.id=c.activity_type_id
            LEFT JOIN opportunities p ON p.id=c.opportunity_id WHERE c.user_id=$1 ORDER BY c.created_at DESC LIMIT 40`, [user.id]),
  ]);
  const open = claims.filter((c) => c.status === 'open');
  const todayStr = today();
  return (
    <div className="space-y-5">
      <div>
        <h1 className="h1">Earn credits</h1>
        <p className="muted">Base rate: {fmt(st.base_rate)} credit per hour of service. Some activities earn more.</p>
      </div>
      {open.map((c) => (
        <div key={c.id} className="card border-sun-400 bg-sun-400/10 flex flex-wrap items-center gap-3">
          <div className="flex-1"><p className="font-semibold">Checked in: {c.description}</p><p className="muted">{c.org_name} · since {dTime(c.checkin_at)}</p></div>
          <Link href={`/checkin/${c.checkin_code}`} className="btn-primary">Check out</Link>
        </div>
      ))}
      <div className="grid gap-5 lg:grid-cols-2">
        <section className="card">
          <h2 className="h2">Opportunities</h2>
          <p className="muted mb-2">At the event, scan the organizer’s QR code to check in and out.</p>
          {!opps.length && <p className="muted py-4">No open opportunities yet.</p>}
          <ul className="divide-y divide-black/5">
            {opps.map((p) => (
              <li key={p.id} className="py-3">
                <div className="flex items-start justify-between gap-2">
                  <div>
                    <p className="font-medium">{p.title}</p>
                    <p className="muted">{p.org_name}{p.location ? ` · ${p.location}` : ''}</p>
                    {p.starts_at && <p className="muted text-xs">{dt(p.starts_at, { weekday: 'short', month: 'short', day: 'numeric', hour: 'numeric', minute: '2-digit' })}</p>}
                  </div>
                  <span className="badge bg-brand-50 text-brand-700 whitespace-nowrap">{fmt(Math.round(st.base_rate * p.multiplier))} cr/hr</span>
                </div>
                {p.description && <p className="mt-1 text-sm text-black/70">{p.description}</p>}
              </li>
            ))}
          </ul>
        </section>
        <section className="card">
          <h2 className="h2">Log hours you served</h2>
          <p className="muted mb-3">The organization confirms your hours before credits are issued.</p>
          {!orgs.length ? <p className="muted">No verifying organizations are active yet.</p> : (
            <ActionForm action={submitClaimAction} resetOnOk className="grid gap-3 sm:grid-cols-2">
              <div className="sm:col-span-2"><label className="label" htmlFor="org">Organization</label>
                <select id="org" name="org_id" className="input" required>{orgs.map((o) => <option key={o.id} value={o.id}>{o.name}</option>)}</select></div>
              <div className="sm:col-span-2"><label className="label" htmlFor="at">Type of service</label>
                <select id="at" name="activity_type_id" className="input" required>{types.filter((t) => t.active).map((t) => <option key={t.id} value={t.id}>{t.name} — {fmt(Math.round(st.base_rate * t.multiplier))} cr/hr</option>)}</select></div>
              <div><label className="label" htmlFor="d">Date</label><input id="d" type="date" name="work_date" max={todayStr} defaultValue={todayStr} className="input" required /></div>
              <div className="grid grid-cols-2 gap-2">
                <div><label className="label" htmlFor="h">Hours</label><input id="h" name="hours" type="number" min={0} max={24} defaultValue={1} className="input" /></div>
                <div><label className="label" htmlFor="m">Minutes</label><input id="m" name="minutes" type="number" min={0} max={59} step={5} defaultValue={0} className="input" /></div>
              </div>
              <div className="sm:col-span-2"><label className="label" htmlFor="desc">What did you do?</label><textarea id="desc" name="description" className="input" rows={2} required minLength={5} maxLength={500} /></div>
              <div className="sm:col-span-2"><Submit>Submit hours</Submit></div>
            </ActionForm>
          )}
        </section>
      </div>
      <section className="card">
        <h2 className="h2 mb-2">My service record</h2>
        {!claims.length ? <p className="muted">Nothing yet.</p> : (
          <div className="overflow-x-auto"><table className="table">
            <thead><tr><th>Date</th><th>Organization</th><th>Service</th><th>Time</th><th>Credits</th><th>Status</th></tr></thead>
            <tbody>{claims.map((c) => (
              <tr key={c.id}>
                <td className="whitespace-nowrap">{c.work_date}</td><td>{c.org_name}</td>
                <td>{c.description}<span className="muted block text-xs">{c.type_name}</span></td>
                <td>{hours(c.minutes)}</td><td>{c.credits ? fmt(c.credits) : '—'}</td>
                <td><span className={`badge ${STATUS[c.status]}`}>{c.status === 'open' ? 'checked in' : c.status}</span>{c.review_note && <span className="muted block text-xs">{c.review_note}</span>}</td>
              </tr>))}</tbody>
          </table></div>
        )}
      </section>
      <p className="muted text-center text-xs">Run a volunteer program? <Link href="/orgs" className="underline">Register your organization</Link>.</p>
    </div>
  );
}
