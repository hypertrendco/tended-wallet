import Link from 'next/link';
import { q } from '@/lib/db';
import { fmt } from '@/lib/money';
import { requireUser } from '@/lib/session';

export default async function Market({ searchParams }: { searchParams: Promise<{ q?: string; cat?: string }> }) {
  await requireUser();
  const { q: term = '', cat = '' } = await searchParams;
  const rows = await q<any>(`
    SELECT o.id, o.name, o.description, o.address, o.website,
      coalesce(json_agg(json_build_object('id', i.id, 'name', i.name, 'description', i.description, 'price', i.price, 'category', i.category) ORDER BY i.price)
        FILTER (WHERE i.id IS NOT NULL), '[]') AS items
    FROM orgs o LEFT JOIN catalog_items i ON i.org_id=o.id AND i.active AND ($2 = '' OR i.category = $2)
    WHERE o.status='active' AND o.kind IN ('provider','both')
      AND ($1 = '' OR o.name ILIKE '%'||$1||'%' OR i.name ILIKE '%'||$1||'%' OR o.description ILIKE '%'||$1||'%')
    GROUP BY o.id ORDER BY o.name`, [term.slice(0, 60), ['service', 'product'].includes(cat) ? cat : '']);
  return (
    <div className="space-y-4">
      <div><h1 className="h1">Redeem for care</h1><p className="muted">Participating providers and what they accept credits for.</p></div>
      <form className="flex flex-wrap gap-2">
        <input name="q" defaultValue={term} placeholder="Search services, products, providers" className="input flex-1 min-w-48" />
        <select name="cat" defaultValue={cat} className="input w-auto"><option value="">All</option><option value="service">Services</option><option value="product">Products</option></select>
        <button className="btn-secondary">Search</button>
      </form>
      {!rows.length && <div className="card muted text-center">No providers match yet.</div>}
      <div className="grid gap-4 md:grid-cols-2">
        {rows.map((o) => (
          <section key={o.id} className="card flex flex-col">
            <h2 className="h2">{o.name}</h2>
            {o.address && <p className="muted">{o.address}</p>}
            {o.description && <p className="mt-1 text-sm text-black/70">{o.description}</p>}
            <ul className="mt-3 flex-1 divide-y divide-black/5 text-sm">
              {o.items.slice(0, 8).map((i: any) => (
                <li key={i.id} className="flex justify-between gap-2 py-1.5"><span>{i.name} <span className="badge bg-black/5 text-black/60">{i.category}</span></span><span className="font-semibold tabular-nums">{fmt(i.price)} cr</span></li>
              ))}
              {!o.items.length && <li className="muted py-1.5">Ask the provider about pricing.</li>}
            </ul>
            <Link href={`/pay/o/${o.id}?via=market`} className="btn-secondary mt-3">Pay this provider</Link>
          </section>
        ))}
      </div>
    </div>
  );
}
