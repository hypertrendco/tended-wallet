import ActionForm from '@/components/ActionForm';
import Submit from '@/components/Submit';
import { profileAction } from '@/app/actions/wallet';
import { requireUser } from '@/lib/session';

export default async function Profile() {
  const user = await requireUser();
  return (
    <div className="mx-auto max-w-md space-y-4">
      <h1 className="h1">Profile</h1>
      <div className="card">
        <p className="muted mb-3">Signed in as <b>{user.email}</b></p>
        <ActionForm action={profileAction} className="space-y-3">
          <div><label className="label" htmlFor="name">Name</label><input id="name" name="name" defaultValue={user.name || ''} className="input" /></div>
          <div><label className="label" htmlFor="phone">Phone (optional)</label><input id="phone" name="phone" defaultValue={user.phone || ''} className="input" /></div>
          <Submit>Save</Submit>
        </ActionForm>
      </div>
      <a href="/logout" className="btn-secondary w-full">Sign out</a>
    </div>
  );
}
