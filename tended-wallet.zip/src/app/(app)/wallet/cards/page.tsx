import { dDate } from '@/lib/time';
import ActionForm from '@/components/ActionForm';
import NewCard from '@/components/NewCard';
import NfcWriteButton from '@/components/NfcWriteButton';
import Submit from '@/components/Submit';
import { CARD_PREFIX } from '@/lib/constants';
import { createCardAction, setCardStatusAction } from '@/app/actions/wallet';
import { q } from '@/lib/db';
import { fmt } from '@/lib/money';
import { requireUser, settings } from '@/lib/session';

export default async function Cards() {
  const user = await requireUser();
  const [cards, st] = await Promise.all([
    q<any>(`SELECT * FROM nfc_cards WHERE user_id=$1 ORDER BY created_at DESC`, [user.id]), settings()]);
  return (
    <div className="mx-auto max-w-2xl space-y-4">
      <h1 className="h1">Tap-to-pay cards</h1>
      <p className="muted">Link an NFC card, sticker or key fob to your wallet. Providers tap it on their Android device and you enter your PIN. Each tap is limited to {fmt(st.card_tx_limit)} credits. Five wrong PINs freezes the card.</p>
      <section className="card space-y-3">
        <h2 className="h2">Your cards</h2>
        {!cards.length && <p className="muted">No cards yet.</p>}
        <ul className="divide-y divide-black/5">
          {cards.map((c) => (
            <li key={c.id} className="flex flex-wrap items-center gap-3 py-3">
              <div className="flex-1">
                <p className="font-medium">{c.label || 'Card'} <span className={`badge ml-1 ${c.status === 'active' ? 'bg-brand-50 text-brand-700' : 'bg-red-50 text-red-700'}`}>{c.status}</span></p>
                <p className="muted text-xs">Added {dDate(c.created_at)} · {c.last_used_at ? `last used ${dDate(c.last_used_at)}` : 'never used'}</p>
              </div>
              {c.status === 'active' && <NfcWriteButton text={CARD_PREFIX + c.card_token} label="Rewrite tag" className="btn-ghost" />}
              <ActionForm action={setCardStatusAction}>
                <input type="hidden" name="id" value={c.id} />
                <input type="hidden" name="status" value={c.status === 'active' ? 'frozen' : 'active'} />
                <Submit className={c.status === 'active' ? 'btn-danger' : 'btn-secondary'}>{c.status === 'active' ? 'Freeze' : 'Unfreeze'}</Submit>
              </ActionForm>
            </li>
          ))}
        </ul>
      </section>
      <section className="card space-y-3">
        <h2 className="h2">Add a card</h2>
        <NewCard action={createCardAction} />
      </section>
    </div>
  );
}
