import PayCode from '@/components/PayCode';
import { requireUser } from '@/lib/session';
export default async function Code() {
  await requireUser();
  return (
    <div className="mx-auto max-w-md space-y-4">
      <h1 className="h1">Your pay code</h1>
      <p className="muted">Show this to a provider. They scan it and enter the amount — the code works once and expires quickly, so a screenshot is useless to anyone else.</p>
      <PayCode />
    </div>
  );
}
