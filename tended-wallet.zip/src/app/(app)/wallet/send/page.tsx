import ActionForm from '@/components/ActionForm';
import Submit from '@/components/Submit';
import { sendAction } from '@/app/actions/wallet';
import { fmt } from '@/lib/money';
import { requireUser, settings } from '@/lib/session';

export default async function Send() {
  const user = await requireUser();
  const st = await settings();
  return (
    <div className="mx-auto max-w-md space-y-4">
      <h1 className="h1">Gift credits</h1>
      {!st.p2p_enabled ? <div className="card">Member-to-member gifts are turned off in this network.</div> : (
        <div className="card">
          <p className="muted mb-3">Share credits with a family member or neighbor so they can get care. Balance: <b>{fmt(user.balance)}</b></p>
          <ActionForm action={sendAction} resetOnOk className="space-y-3">
            <div><label className="label" htmlFor="email">Recipient’s email</label><input id="email" name="email" type="email" required className="input" /></div>
            <div><label className="label" htmlFor="amount">Credits</label><input id="amount" name="amount" inputMode="decimal" required className="input" /></div>
            <div><label className="label" htmlFor="memo">Note</label><input id="memo" name="memo" className="input" maxLength={200} /></div>
            <Submit>Send gift</Submit>
          </ActionForm>
        </div>
      )}
    </div>
  );
}
