import Link from 'next/link';
import ActivityList from '@/components/ActivityList';
import { fmt } from '@/lib/money';
import { activity } from '@/lib/queries';
import { one } from '@/lib/db';
import { requireUser, settings } from '@/lib/session';

export default async function Wallet() {
  const user = await requireUser();
  const [items, st, pending] = await Promise.all([
    activity(user.wallet_id, 25), settings(),
    one<{ n: number; m: number }>(`SELECT count(*)::int n, coalesce(sum(minutes),0)::int m FROM hour_claims WHERE user_id=$1 AND status IN ('pending','open')`, [user.id]),
  ]);
  const actions = [
    { href: '/scan', label: 'Scan to pay', d: 'M4 8V5a1 1 0 0 1 1-1h3M16 4h3a1 1 0 0 1 1 1v3M20 16v3a1 1 0 0 1-1 1h-3M8 20H5a1 1 0 0 1-1-1v-3M7 12h10' },
    { href: '/wallet/code', label: 'Show pay code', d: 'M4 4h6v6H4zM14 4h6v6h-6zM4 14h6v6H4zM14 14h2v2h-2zM18 18h2v2h-2zM14 18h2' },
    { href: '/wallet/cards', label: 'Tap cards', d: 'M3 6h18v12H3zM3 10h18M7 15h3' },
    ...(st.p2p_enabled ? [{ href: '/wallet/send', label: 'Gift credits', d: 'M20 12v9H4v-9M2 7h20v5H2zM12 22V7M12 7H7.5a2.5 2.5 0 1 1 0-5C11 2 12 7 12 7zM12 7h4.5a2.5 2.5 0 1 0 0-5C13 2 12 7 12 7z' }] : []),
  ];
  return (
    <div className="grid gap-5 md:grid-cols-[1fr_1.3fr]">
      <section className="min-w-0 space-y-4">
        <div className="rounded-3xl bg-brand-700 p-6 text-white shadow-lg">
          <p className="text-sm text-white/70">Hi {user.name?.split(' ')[0] || 'there'} — your balance</p>
          <p className="mt-1 text-5xl font-bold tabular-nums" data-testid="balance">{fmt(user.balance)}<span className="ml-2 text-lg font-medium text-white/70">credits</span></p>
          {pending && pending.n > 0 && <p className="mt-3 text-sm text-sun-400">{pending.n} service claim{pending.n > 1 ? 's' : ''} awaiting approval</p>}
        </div>
        <div className="grid grid-cols-4 gap-2">
          {actions.map((a) => (
            <Link key={a.href} href={a.href} className="card flex min-w-0 flex-col items-center gap-1.5 px-1 py-3 text-center text-[11px] leading-tight font-medium hover:border-brand-200">
              <svg viewBox="0 0 24 24" className="h-6 w-6 text-brand-600" fill="none" stroke="currentColor" strokeWidth={1.8} strokeLinecap="round" strokeLinejoin="round"><path d={a.d} /></svg>
              {a.label}
            </Link>
          ))}
        </div>
        <div className="card flex items-center justify-between">
          <div><p className="font-semibold">Earn more credits</p><p className="muted">Find a shift or log hours you served.</p></div>
          <Link href="/earn" className="btn-secondary">Earn</Link>
        </div>
      </section>
      <section className="card min-w-0">
        <h2 className="h2">Activity</h2>
        <ActivityList items={items} empty="No activity yet. Volunteer with a local organization to earn your first credits." />
      </section>
    </div>
  );
}
