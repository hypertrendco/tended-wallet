import Link from 'next/link';
import ActionForm from '@/components/ActionForm';
import Submit from '@/components/Submit';
import { applyOrgAction } from '@/app/actions/org';
import { myOrgs, requireUser } from '@/lib/session';

const KIND: Record<string, string> = { verifier: 'Verifies volunteer hours', provider: 'Accepts credits for care', both: 'Verifies hours & accepts credits' };
const ST: Record<string, string> = { active: 'bg-brand-50 text-brand-700', pending: 'bg-sun-400/25', suspended: 'bg-red-50 text-red-700', rejected: 'bg-red-50 text-red-700' };

export default async function Orgs() {
  const user = await requireUser();
  const orgs = await myOrgs(user.id);
  return (
    <div className="grid gap-5 lg:grid-cols-2">
      <section className="space-y-3">
        <h1 className="h1">Organizations</h1>
        {!orgs.length && <div className="card muted">You aren’t part of any organization. Coordinators and providers register here; staff are added by their organization’s owner.</div>}
        {orgs.map((o) => (
          <Link key={o.org_id} href={`/orgs/${o.org_id}`} className="card flex items-center justify-between hover:border-brand-200">
            <div><p className="font-semibold">{o.name}</p><p className="muted">{KIND[o.kind]} · {o.role}</p></div>
            <span className={`badge ${ST[o.status]}`}>{o.status}</span>
          </Link>
        ))}
      </section>
      <section className="card">
        <h2 className="h2">Register an organization</h2>
        <p className="muted mb-3">Applications are reviewed by the network admin before going live.</p>
        <ActionForm action={applyOrgAction} resetOnOk className="space-y-3">
          <div><label className="label" htmlFor="name">Name</label><input id="name" name="name" required className="input" /></div>
          <fieldset>
            <legend className="label">Role in the network</legend>
            <div className="grid gap-2">
              {(['verifier', 'provider', 'both'] as const).map((k) => (
                <label key={k} className="flex items-center gap-2 rounded-xl border border-black/10 p-2.5 text-sm"><input type="radio" name="kind" value={k} required className="accent-brand-600" defaultChecked={k === 'verifier'} /> {KIND[k]}</label>
              ))}
            </div>
          </fieldset>
          <div><label className="label" htmlFor="desc">Description</label><textarea id="desc" name="description" rows={2} className="input" /></div>
          <div><label className="label" htmlFor="addr">Address</label><input id="addr" name="address" className="input" /></div>
          <div className="grid grid-cols-2 gap-2">
            <div><label className="label" htmlFor="npi">NPI (providers)</label><input id="npi" name="npi" inputMode="numeric" maxLength={10} className="input" /></div>
            <div><label className="label" htmlFor="web">Website</label><input id="web" name="website" className="input" /></div>
          </div>
          <Submit>Submit application</Submit>
        </ActionForm>
      </section>
    </div>
  );
}
