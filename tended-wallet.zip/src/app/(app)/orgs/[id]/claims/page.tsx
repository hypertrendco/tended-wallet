import { dTime, today } from '@/lib/time';
import { notFound } from 'next/navigation';
import ActionForm from '@/components/ActionForm';
import Submit from '@/components/Submit';
import { logHoursAction, reviewClaimAction } from '@/app/actions/org';
import { q } from '@/lib/db';
import { fmt, hours } from '@/lib/money';
import { activityTypes } from '@/lib/queries';
import { requireOrg, settings } from '@/lib/session';

export default async function Claims({ params }: { params: Promise<{ id: string }> }) {
  const { id } = await params;
  const { org, user } = await requireOrg(id);
  if (org.kind === 'provider') notFound();
  const [pending, open, recent, types, st] = await Promise.all([
    q<any>(`SELECT c.*, u.name, u.email, a.name AS type_name, a.multiplier FROM hour_claims c JOIN users u ON u.id=c.user_id JOIN activity_types a ON a.id=c.activity_type_id
            WHERE c.org_id=$1 AND c.status='pending' ORDER BY c.flagged IS NULL, c.created_at`, [id]),
    q<any>(`SELECT c.*, u.name, u.email FROM hour_claims c JOIN users u ON u.id=c.user_id WHERE c.org_id=$1 AND c.status='open' ORDER BY c.checkin_at`, [id]),
    q<any>(`SELECT c.*, u.name, u.email, r.email AS reviewer FROM hour_claims c JOIN users u ON u.id=c.user_id LEFT JOIN users r ON r.id=c.reviewed_by
            WHERE c.org_id=$1 AND c.status IN ('approved','rejected') ORDER BY c.reviewed_at DESC LIMIT 30`, [id]),
    activityTypes(), settings(),
  ]);
  const active = org.status === 'active';
  return (
    <div className="grid gap-4 lg:grid-cols-[1.5fr_1fr]">
      <div className="space-y-4">
        <section className="card">
          <h2 className="h2 mb-1">Awaiting review ({pending.length})</h2>
          <p className="muted mb-2">Adjust the minutes if needed, then approve to issue credits.</p>
          {!pending.length && <p className="muted py-3">All caught up.</p>}
          <ul className="divide-y divide-black/5">
            {pending.map((c) => (
              <li key={c.id} className="py-3">
                <div className="flex flex-wrap justify-between gap-2">
                  <div>
                    <p className="font-medium">{c.name || c.email} <span className="muted font-normal">· {c.work_date} · {c.source}</span></p>
                    <p className="text-sm">{c.description}</p>
                    <p className="muted text-xs">{c.type_name} ×{c.multiplier} · {hours(c.minutes)} ≈ {fmt(Math.round((c.minutes / 60) * st.base_rate * c.multiplier))} credits</p>
                    {c.flagged && <p className="mt-1 badge bg-red-50 text-red-700">⚑ {c.flagged}</p>}
                    {c.user_id === user.id && <p className="muted text-xs">Your own claim — another coordinator must review it.</p>}
                  </div>
                </div>
                {active && c.user_id !== user.id && (
                  <ActionForm action={reviewClaimAction} className="mt-2 flex flex-wrap items-center gap-2">
                    <input type="hidden" name="org_id" value={id} /><input type="hidden" name="claim_id" value={c.id} />
                    <label className="text-sm">Minutes <input name="minutes" type="number" min={1} max={1440} defaultValue={c.minutes} className="input inline w-24 py-1.5" /></label>
                    <input name="note" placeholder="Note (optional)" className="input w-auto flex-1 py-1.5" />
                    <Submit name="decision" value="approve">Approve</Submit>
                    <Submit name="decision" value="reject" className="btn-danger">Reject</Submit>
                  </ActionForm>
                )}
              </li>
            ))}
          </ul>
        </section>
        {open.length > 0 && (
          <section className="card">
            <h2 className="h2 mb-2">Checked in now ({open.length})</h2>
            <ul className="text-sm">{open.map((c) => <li key={c.id} className="flex justify-between border-b border-black/5 py-1.5"><span>{c.name || c.email} — {c.description}</span><span className="muted">since {dTime(c.checkin_at)}</span></li>)}</ul>
          </section>
        )}
        <section className="card overflow-x-auto">
          <h2 className="h2 mb-2">Recently reviewed</h2>
          <table className="table"><thead><tr><th>Member</th><th>Date</th><th>Time</th><th>Credits</th><th>Status</th><th>By</th></tr></thead>
            <tbody>{recent.map((c) => <tr key={c.id}><td>{c.name || c.email}</td><td>{c.work_date}</td><td>{hours(c.minutes)}</td><td>{c.credits ? fmt(c.credits) : '—'}</td><td>{c.status}</td><td className="muted">{c.reviewer}</td></tr>)}</tbody></table>
        </section>
      </div>
      <section className="card h-fit">
        <h2 className="h2 mb-1">Log hours for a member</h2>
        <p className="muted mb-3">Credits are issued immediately. The member must have signed in to Tended at least once.</p>
        <ActionForm action={logHoursAction} resetOnOk className="space-y-3">
          <input type="hidden" name="org_id" value={id} />
          <div><label className="label" htmlFor="e">Member email</label><input id="e" name="email" type="email" required className="input" /></div>
          <div><label className="label" htmlFor="t">Service type</label><select id="t" name="activity_type_id" className="input">{types.filter((t) => t.active).map((t) => <option key={t.id} value={t.id}>{t.name} (×{t.multiplier})</option>)}</select></div>
          <div className="grid grid-cols-2 gap-2">
            <div><label className="label" htmlFor="h">Hours</label><input id="h" name="hours" type="number" step="0.25" min="0.25" max="24" required className="input" /></div>
            <div><label className="label" htmlFor="d">Date</label><input id="d" name="work_date" type="date" className="input" defaultValue={today()} /></div>
          </div>
          <div><label className="label" htmlFor="ds">Description</label><input id="ds" name="description" className="input" /></div>
          <Submit>Log & issue credits</Submit>
        </ActionForm>
      </section>
    </div>
  );
}
