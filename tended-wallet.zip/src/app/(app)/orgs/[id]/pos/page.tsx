import { notFound } from 'next/navigation';
import POS from '@/components/POS';
import { cancelChargeAction, chargeCardAction, chargePayCodeAction, createChargeAction } from '@/app/actions/org';
import { q } from '@/lib/db';
import { requireOrg, settings } from '@/lib/session';

export default async function PosPage({ params }: { params: Promise<{ id: string }> }) {
  const { id } = await params;
  const { org } = await requireOrg(id);
  if (org.kind === 'verifier') notFound();
  const [items, st] = await Promise.all([q<any>(`SELECT id, name, price FROM catalog_items WHERE org_id=$1 AND active ORDER BY name`, [id]), settings()]);
  if (org.status !== 'active') return <div className="card muted">Checkout opens once the organization is approved.</div>;
  return (
    <div className="mx-auto max-w-2xl">
      <POS orgId={id} items={items} cardLimit={st.card_tx_limit}
        actions={{ create: createChargeAction, cancel: cancelChargeAction, payCode: chargePayCodeAction, card: chargeCardAction }} />
    </div>
  );
}
