import ActionForm from '@/components/ActionForm';
import Submit from '@/components/Submit';
import { addStaffAction, removeStaffAction } from '@/app/actions/org';
import { q } from '@/lib/db';
import { requireOrg } from '@/lib/session';

export default async function Team({ params }: { params: Promise<{ id: string }> }) {
  const { id } = await params;
  const { role } = await requireOrg(id);
  const members = await q<any>(`SELECT m.role, u.id, u.email, u.name, u.auth_sub IS NOT NULL AS joined FROM org_members m JOIN users u ON u.id=m.user_id WHERE m.org_id=$1 ORDER BY m.role, u.email`, [id]);
  const owner = role !== 'staff';
  return (
    <div className="grid gap-4 lg:grid-cols-[1.5fr_1fr]">
      <section className="card">
        <h2 className="h2 mb-2">Team</h2>
        <ul className="divide-y divide-black/5">
          {members.map((m) => (
            <li key={m.id} className="flex items-center gap-2 py-2.5">
              <div className="flex-1"><p className="font-medium">{m.name || m.email}</p><p className="muted text-xs">{m.email} · {m.role}{!m.joined && ' · invited'}</p></div>
              {owner && <ActionForm action={removeStaffAction}><input type="hidden" name="org_id" value={id} /><input type="hidden" name="user_id" value={m.id} /><Submit className="btn-ghost">Remove</Submit></ActionForm>}
            </li>
          ))}
        </ul>
      </section>
      {owner && (
        <section className="card h-fit">
          <h2 className="h2 mb-2">Add staff</h2>
          <p className="muted mb-3">Staff can run checkout and review hours. Owners can also manage the team, details, and settlements.</p>
          <ActionForm action={addStaffAction} resetOnOk className="space-y-3">
            <input type="hidden" name="org_id" value={id} />
            <div><label className="label" htmlFor="e">Email</label><input id="e" name="email" type="email" required className="input" /></div>
            <div><label className="label" htmlFor="r">Role</label><select id="r" name="role" className="input"><option value="staff">Staff</option><option value="owner">Owner</option></select></div>
            <Submit>Add</Submit>
          </ActionForm>
        </section>
      )}
    </div>
  );
}
