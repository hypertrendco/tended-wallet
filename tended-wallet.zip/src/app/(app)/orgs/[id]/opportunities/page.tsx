import { dt } from '@/lib/time';
import { notFound } from 'next/navigation';
import ActionForm from '@/components/ActionForm';
import PrintQR from '@/components/PrintQR';
import Submit from '@/components/Submit';
import { saveOpportunityAction, toggleOpportunityAction } from '@/app/actions/org';
import { q } from '@/lib/db';
import { activityTypes } from '@/lib/queries';
import { requireOrg } from '@/lib/session';

export default async function Opps({ params }: { params: Promise<{ id: string }> }) {
  const { id } = await params;
  const { org } = await requireOrg(id);
  if (org.kind === 'provider') notFound();
  const [opps, types] = await Promise.all([
    q<any>(`SELECT p.*, a.name AS type_name, (SELECT count(*)::int FROM hour_claims c WHERE c.opportunity_id=p.id) AS checkins
            FROM opportunities p JOIN activity_types a ON a.id=p.activity_type_id WHERE p.org_id=$1 ORDER BY p.active DESC, p.starts_at DESC NULLS LAST`, [id]),
    activityTypes()]);
  return (
    <div className="grid gap-4 lg:grid-cols-[1.5fr_1fr]">
      <section className="space-y-3">
        {!opps.length && <div className="card muted">Create a volunteer opportunity to get a check-in QR code.</div>}
        {opps.map((p) => (
          <div key={p.id} className={`card space-y-2 ${p.active ? '' : 'opacity-60'}`}>
            <div className="flex flex-wrap justify-between gap-2">
              <div>
                <p className="font-semibold">{p.title}</p>
                <p className="muted">{p.type_name}{p.location ? ` · ${p.location}` : ''}{p.starts_at ? ` · ${dt(p.starts_at, { month: 'short', day: 'numeric', hour: 'numeric', minute: '2-digit' })}` : ''} · {p.checkins} check-ins</p>
              </div>
              <ActionForm action={toggleOpportunityAction}><input type="hidden" name="org_id" value={id} /><input type="hidden" name="id" value={p.id} /><Submit className="btn-ghost">{p.active ? 'Close' : 'Reopen'}</Submit></ActionForm>
            </div>
            {p.active && <details><summary className="cursor-pointer text-sm font-medium text-brand-700">Check-in QR code</summary><div className="mt-2"><PrintQR url={`/checkin/${p.checkin_code}`} title={p.title} subtitle="Scan to check in / check out" /></div></details>}
          </div>
        ))}
      </section>
      <section className="card h-fit">
        <h2 className="h2 mb-2">New opportunity</h2>
        <ActionForm action={saveOpportunityAction} resetOnOk className="space-y-3">
          <input type="hidden" name="org_id" value={id} />
          <div><label className="label" htmlFor="t">Title</label><input id="t" name="title" required className="input" placeholder="Saturday food pantry shift" /></div>
          <div><label className="label" htmlFor="a">Service type</label><select id="a" name="activity_type_id" className="input">{types.filter((t) => t.active).map((t) => <option key={t.id} value={t.id}>{t.name} (×{t.multiplier})</option>)}</select></div>
          <div><label className="label" htmlFor="l">Location</label><input id="l" name="location" className="input" /></div>
          <div className="grid grid-cols-2 gap-2">
            <div><label className="label" htmlFor="s">Starts</label><input id="s" name="starts_at" type="datetime-local" className="input" /></div>
            <div><label className="label" htmlFor="e">Ends</label><input id="e" name="ends_at" type="datetime-local" className="input" /></div>
          </div>
          <div><label className="label" htmlFor="c">Capacity (optional)</label><input id="c" name="capacity" type="number" min={1} className="input" /></div>
          <div><label className="label" htmlFor="d">Description</label><textarea id="d" name="description" rows={2} className="input" /></div>
          <Submit>Create</Submit>
        </ActionForm>
      </section>
    </div>
  );
}
