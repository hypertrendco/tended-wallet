import { dDate } from '@/lib/time';
import ActionForm from '@/components/ActionForm';
import ActivityList from '@/components/ActivityList';
import NfcWriteButton from '@/components/NfcWriteButton';
import PrintQR from '@/components/PrintQR';
import Submit from '@/components/Submit';
import { requestSettlementAction, updateOrgAction } from '@/app/actions/org';
import { q } from '@/lib/db';
import { fmt } from '@/lib/money';
import { activity } from '@/lib/queries';
import { requireOrg } from '@/lib/session';

export default async function OrgHome({ params }: { params: Promise<{ id: string }> }) {
  const { id } = await params;
  const { org, role } = await requireOrg(id);
  const prov = org.kind !== 'verifier', ver = org.kind !== 'provider';
  const [items, stats, settlements] = await Promise.all([
    activity(org.wallet_id, 20),
    q<any>(`SELECT
       (SELECT coalesce(sum(credits),0)::bigint FROM hour_claims WHERE org_id=$1 AND status='approved') AS issued,
       (SELECT coalesce(sum(minutes),0)::int FROM hour_claims WHERE org_id=$1 AND status='approved') AS minutes,
       (SELECT count(DISTINCT user_id)::int FROM hour_claims WHERE org_id=$1 AND status='approved') AS volunteers,
       (SELECT count(*)::int FROM txns t JOIN entries e ON e.txn_id=t.id WHERE e.wallet_id=$2 AND t.kind='payment' AND e.amount>0) AS sales`, [org.id, org.wallet_id]),
    q<any>(`SELECT * FROM settlement_requests WHERE org_id=$1 ORDER BY created_at DESC LIMIT 5`, [org.id]),
  ]);
  const s = stats[0];
  const tiles = [
    ...(ver ? [['Credits issued', fmt(s.issued)], ['Hours verified', Math.round(s.minutes / 6) / 10], ['Volunteers', s.volunteers]] : []),
    ...(prov ? [['Balance', fmt(org.balance)], ['Payments received', s.sales]] : []),
  ];
  const payUrl = `/pay/o/${org.id}`;
  return (
    <div className="grid gap-4 lg:grid-cols-2">
      <div className="grid grid-cols-2 gap-3 sm:grid-cols-3 lg:col-span-2">
        {tiles.map(([k, v]) => <div key={k} className="card"><p className="muted">{k}</p><p className="text-2xl font-bold tabular-nums">{v}</p></div>)}
      </div>
      {prov && (
        <section className="card space-y-3">
          <h2 className="h2">Counter QR & NFC sticker</h2>
          <p className="muted">Print this QR or write it to an NFC sticker for your counter. Members scan or tap it to open your payment page (works on iPhone and Android).</p>
          <PrintQR url={`${payUrl}?via=qr_static`} title={org.name} subtitle="Scan to pay with Tended credits" />
          <NfcWriteButton url={`${payUrl}?via=nfc_tag`} label="Write NFC counter sticker" />
        </section>
      )}
      {prov && role !== 'staff' && (
        <section className="card space-y-3">
          <h2 className="h2">Settlement</h2>
          <p className="muted">Request that the network settle credits you’ve received (e.g., from its sponsor fund). Settled credits are retired from circulation.</p>
          <ActionForm action={requestSettlementAction} resetOnOk className="flex flex-wrap gap-2">
            <input type="hidden" name="org_id" value={org.id} />
            <input name="amount" inputMode="decimal" placeholder="Credits" className="input w-32" required />
            <input name="note" placeholder="Note (optional)" className="input flex-1 min-w-40" />
            <Submit>Request</Submit>
          </ActionForm>
          {settlements.length > 0 && <ul className="text-sm">{settlements.map((r) => <li key={r.id} className="flex justify-between border-b border-black/5 py-1"><span>{dDate(r.created_at)} · {fmt(r.amount)} cr</span><span className="badge bg-black/5">{r.status}</span></li>)}</ul>}
        </section>
      )}
      <section className="card">
        <h2 className="h2">Recent activity</h2>
        <ActivityList items={items} empty={prov ? 'No payments yet.' : 'Credits you approve are minted directly to members.'} />
      </section>
      {role !== 'staff' && (
        <section className="card">
          <h2 className="h2 mb-2">Details</h2>
          <ActionForm action={updateOrgAction} className="space-y-3">
            <input type="hidden" name="org_id" value={org.id} />
            <div><label className="label" htmlFor="d">Description</label><textarea id="d" name="description" defaultValue={org.description || ''} rows={3} className="input" /></div>
            <div><label className="label" htmlFor="a">Address</label><input id="a" name="address" defaultValue={org.address || ''} className="input" /></div>
            <div><label className="label" htmlFor="w">Website</label><input id="w" name="website" defaultValue={org.website || ''} className="input" /></div>
            <Submit>Save</Submit>
          </ActionForm>
        </section>
      )}
    </div>
  );
}
