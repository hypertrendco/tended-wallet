import { notFound } from 'next/navigation';
import SubNav from '@/components/SubNav';
import { one } from '@/lib/db';
import { fmt } from '@/lib/money';
import { requireUser } from '@/lib/session';

export default async function OrgLayout({ children, params }: { children: React.ReactNode; params: Promise<{ id: string }> }) {
  const { id } = await params;
  const user = await requireUser();
  if (!/^[0-9a-f-]{36}$/.test(id)) notFound();
  const org = await one<any>(`SELECT o.*, w.balance, m.role,
      (SELECT count(*)::int FROM hour_claims c WHERE c.org_id=o.id AND c.status='pending') AS pending
    FROM orgs o JOIN wallets w ON w.org_id=o.id LEFT JOIN org_members m ON m.org_id=o.id AND m.user_id=$2 WHERE o.id=$1`, [id, user.id]);
  if (!org || (!org.role && !user.is_admin)) notFound();
  const prov = org.kind !== 'verifier', ver = org.kind !== 'provider';
  const base = `/orgs/${id}`;
  const items = [
    { href: base, label: 'Overview' },
    ...(prov ? [{ href: `${base}/pos`, label: 'Checkout' }, { href: `${base}/catalog`, label: 'Catalog' }] : []),
    ...(ver ? [{ href: `${base}/claims`, label: 'Hours', badge: org.pending }, { href: `${base}/opportunities`, label: 'Opportunities' }] : []),
    { href: `${base}/team`, label: 'Team' },
  ];
  return (
    <div className="space-y-4">
      <div className="flex flex-wrap items-end justify-between gap-2">
        <div>
          <h1 className="h1">{org.name}</h1>
          <p className="muted">{org.kind === 'both' ? 'Verifier & provider' : org.kind === 'verifier' ? 'Verifying organization' : 'Care provider'} · {org.role || 'admin view'}</p>
        </div>
        {prov && <div className="text-right"><p className="muted">Credits received</p><p className="text-2xl font-bold tabular-nums">{fmt(org.balance)}</p></div>}
      </div>
      {org.status !== 'active' && <div className="card border-sun-400 bg-sun-400/15 text-sm">Status: <b>{org.status}</b>. {org.status === 'pending' ? 'A network admin must approve this organization before it can issue or accept credits.' : 'Contact the network admin.'}</div>}
      <SubNav items={items} />
      {children}
    </div>
  );
}
