import { notFound } from 'next/navigation';
import ActionForm from '@/components/ActionForm';
import Submit from '@/components/Submit';
import { saveItemAction, toggleItemAction } from '@/app/actions/org';
import { q } from '@/lib/db';
import { fmt } from '@/lib/money';
import { requireOrg } from '@/lib/session';

export default async function Catalog({ params }: { params: Promise<{ id: string }> }) {
  const { id } = await params;
  const { org } = await requireOrg(id);
  if (org.kind === 'verifier') notFound();
  const items = await q<any>(`SELECT * FROM catalog_items WHERE org_id=$1 ORDER BY active DESC, name`, [id]);
  return (
    <div className="grid gap-4 lg:grid-cols-[1.4fr_1fr]">
      <section className="card">
        <h2 className="h2 mb-2">Services & products</h2>
        {!items.length && <p className="muted">Add what members can redeem credits for.</p>}
        <ul className="divide-y divide-black/5">
          {items.map((i) => (
            <li key={i.id} className={`py-3 ${i.active ? '' : 'opacity-50'}`}>
              <details>
                <summary className="flex cursor-pointer items-center gap-2">
                  <span className="flex-1 font-medium">{i.name} <span className="badge bg-black/5 text-black/60">{i.category}</span></span>
                  <span className="font-semibold tabular-nums">{fmt(i.price)} cr</span>
                </summary>
                <ActionForm action={saveItemAction} className="mt-3 grid gap-2 sm:grid-cols-2">
                  <input type="hidden" name="org_id" value={id} /><input type="hidden" name="id" value={i.id} />
                  <input name="name" defaultValue={i.name} className="input" aria-label="Name" required />
                  <input name="price" defaultValue={i.price / 100} className="input" aria-label="Price" inputMode="decimal" required />
                  <select name="category" defaultValue={i.category} className="input" aria-label="Category"><option value="service">Service</option><option value="product">Product</option></select>
                  <input name="description" defaultValue={i.description || ''} className="input" aria-label="Description" />
                  <div className="sm:col-span-2"><Submit className="btn-secondary">Save</Submit></div>
                </ActionForm>
                <ActionForm action={toggleItemAction} className="mt-2"><input type="hidden" name="org_id" value={id} /><input type="hidden" name="id" value={i.id} /><Submit className="btn-ghost">{i.active ? 'Hide from members' : 'Show to members'}</Submit></ActionForm>
              </details>
            </li>
          ))}
        </ul>
      </section>
      <section className="card">
        <h2 className="h2 mb-2">Add item</h2>
        <ActionForm action={saveItemAction} resetOnOk className="space-y-3">
          <input type="hidden" name="org_id" value={id} />
          <div><label className="label" htmlFor="n">Name</label><input id="n" name="name" required className="input" placeholder="Blood pressure check" /></div>
          <div className="grid grid-cols-2 gap-2">
            <div><label className="label" htmlFor="p">Price (credits)</label><input id="p" name="price" required inputMode="decimal" className="input" /></div>
            <div><label className="label" htmlFor="c">Type</label><select id="c" name="category" className="input"><option value="service">Service</option><option value="product">Product</option></select></div>
          </div>
          <div><label className="label" htmlFor="d">Description</label><input id="d" name="description" className="input" /></div>
          <Submit>Add</Submit>
        </ActionForm>
      </section>
    </div>
  );
}
