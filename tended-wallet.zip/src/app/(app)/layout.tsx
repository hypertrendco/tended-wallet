import Link from 'next/link';
import { redirect } from 'next/navigation';
import Logo from '@/components/Logo';
import Nav from '@/components/Nav';
import { devLoginEnabled, missingConfig } from '@/lib/config';
import { getUser } from '@/lib/session';
import { fmt } from '@/lib/money';

export const dynamic = 'force-dynamic';

export default async function AppLayout({ children }: { children: React.ReactNode }) {
  if (missingConfig().length) redirect('/setup');
  const user = await getUser();
  return (
    <div className="min-h-dvh pb-24 md:pb-8">
      {devLoginEnabled() && <div className="bg-sun-400 px-4 py-1 text-center text-xs font-medium">Demo mode — sign-in is not verified. Configure Auth0 before real use.</div>}
      <header className="sticky top-0 z-20 border-b border-black/5 bg-[#f6f7f4]/90 backdrop-blur">
        <div className="mx-auto flex max-w-5xl items-center gap-3 px-4 py-3">
          <Link href="/wallet" className="flex items-center gap-2"><Logo /><span className="font-bold text-brand-700">Tended</span></Link>
          <div className="hidden md:block ml-4"><Nav /></div>
          <div className="ml-auto flex items-center gap-2">
            {user && <Link href="/wallet" className="badge bg-brand-50 text-brand-700 text-sm px-3 py-1" aria-label="Balance">{fmt(user.balance)} cr</Link>}
            {user?.is_admin && <Link href="/admin" className="btn-ghost px-3 py-1.5">Admin</Link>}
            {user && <Link href="/profile" className="grid h-8 w-8 place-items-center rounded-full bg-brand-600 text-sm font-bold text-white" aria-label="Profile">{(user.name || user.email)[0].toUpperCase()}</Link>}
          </div>
        </div>
      </header>
      <main className="mx-auto max-w-5xl px-4 py-5">{children}</main>
      <div className="md:hidden"><Nav /></div>
    </div>
  );
}
