import { dTime } from '@/lib/time';
import { notFound } from 'next/navigation';
import ActionForm from '@/components/ActionForm';
import Submit from '@/components/Submit';
import { checkinAction } from '@/app/actions/earn';
import { one } from '@/lib/db';
import { fmt } from '@/lib/money';
import { requireUser, settings } from '@/lib/session';

export default async function Checkin({ params }: { params: Promise<{ code: string }> }) {
  const { code } = await params;
  const user = await requireUser(`/checkin/${code}`);
  const opp = await one<any>(`SELECT p.*, o.name AS org_name, o.status AS org_status, a.name AS type_name, a.multiplier FROM opportunities p
    JOIN orgs o ON o.id=p.org_id JOIN activity_types a ON a.id=p.activity_type_id WHERE p.checkin_code=$1`, [code]);
  if (!opp) notFound();
  const st = await settings();
  const open = await one<any>(`SELECT checkin_at FROM hour_claims WHERE user_id=$1 AND opportunity_id=$2 AND status='open'`, [user.id, opp.id]);
  const usable = opp.active && opp.org_status === 'active';
  return (
    <div className="mx-auto max-w-md space-y-4">
      <div className="card text-center py-8">
        <p className="muted">{opp.org_name}</p>
        <h1 className="h1 mt-1">{opp.title}</h1>
        {opp.location && <p className="muted">{opp.location}</p>}
        <p className="mt-3"><span className="badge bg-brand-50 text-brand-700">{opp.type_name} · {fmt(Math.round(st.base_rate * opp.multiplier))} credits/hr</span></p>
        {open && <p className="mt-4 text-sm">You checked in at <b>{dTime(open.checkin_at)}</b>.</p>}
      </div>
      {!usable ? <div className="card text-center">This check-in is closed.</div> : (
        <ActionForm action={checkinAction} className="card text-center">
          <input type="hidden" name="code" value={code} />
          <Submit className="btn-primary w-full py-3.5 text-base">{open ? 'Check out' : 'Check in'}</Submit>
        </ActionForm>
      )}
    </div>
  );
}
