import { redirect } from 'next/navigation';
import { missingConfig } from '@/lib/config';
export const dynamic = 'force-dynamic';

const HELP: Record<string, string> = {
  DATABASE_URL: 'Neon Postgres connection string (Vercel → Storage → Neon adds this automatically). Schema is created on the next deploy.',
  AUTH0_DOMAIN: 'Your Auth0 tenant domain, e.g. your-tenant.us.auth0.com',
  AUTH0_CLIENT_ID: 'Client ID of a “Regular Web Application” in Auth0',
  AUTH0_CLIENT_SECRET: 'Client secret of that application',
  AUTH0_SECRET: '32+ random bytes, e.g. output of: openssl rand -hex 32',
};

export default function Setup() {
  const miss = missingConfig();
  if (!miss.length) redirect('/');
  return (
    <main className="mx-auto max-w-xl px-4 py-10">
      <h1 className="h1">Finish setting up Tended</h1>
      <p className="muted mt-2">Add these environment variables in Vercel → Project → Settings → Environment Variables, then redeploy.</p>
      <ul className="mt-6 space-y-3">
        {miss.map((k) => (
          <li key={k} className="card"><code className="font-mono font-semibold">{k}</code><p className="muted mt-1">{HELP[k]}</p></li>
        ))}
      </ul>
      <div className="card mt-6 text-sm space-y-2">
        <p className="font-semibold">Also recommended</p>
        <p><code>BOOTSTRAP_ADMIN_EMAIL</code> — your email; that account becomes the network admin on first sign-in.</p>
        <p><code>APP_BASE_URL</code> — your production URL (e.g. https://tended.vercel.app).</p>
        <p>In Auth0: enable the <b>Passwordless → Email</b> connection for the app, and add <code>{'<APP_BASE_URL>'}/auth/callback</code> to Allowed Callback URLs and <code>{'<APP_BASE_URL>'}</code> to Allowed Logout URLs.</p>
      </div>
    </main>
  );
}
