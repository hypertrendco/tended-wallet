'use server';
import { revalidatePath } from 'next/cache';
import { one, q, friendlyError } from '@/lib/db';
import { fmt, parseCredits } from '@/lib/money';
import { audit, requireAdmin } from '@/lib/session';
import type { ActionResult } from '@/components/ActionForm';

const s = (v: FormDataEntryValue | null, max = 200) => String(v ?? '').trim().slice(0, max);

export async function saveSettingsAction(_: ActionResult, fd: FormData): Promise<ActionResult> {
  try {
    const admin = await requireAdmin();
    const num = (k: string, min: number, max: number) => {
      const n = Number(fd.get(k)); if (!Number.isFinite(n) || n < min || n > max) throw new Error(`${k.replace(/_/g, ' ')} must be between ${min} and ${max}`); return n;
    };
    const cap = s(fd.get('max_balance'));
    const vals = [
      s(fd.get('network_name'), 80) || 'Tended Community Network',
      parseCredits(fd.get('base_rate')),
      fd.get('p2p_enabled') === 'on',
      Math.round(num('daily_hours_cap', 1, 24) * 60),
      parseCredits(fd.get('card_tx_limit')),
      num('pay_code_ttl_sec', 30, 600),
      num('request_ttl_min', 1, 120),
      cap ? parseCredits(cap) : null,
    ];
    await q(`UPDATE app_settings SET network_name=$1, base_rate=$2, p2p_enabled=$3, daily_minute_cap=$4, card_tx_limit=$5,
             pay_code_ttl_sec=$6, request_ttl_min=$7, max_balance=$8, updated_at=now() WHERE id=1`, vals);
    await audit(admin.id, 'settings.update', { vals });
    revalidatePath('/admin', 'layout');
    return { ok: 'Settings saved.' };
  } catch (e) { return { error: friendlyError(e) }; }
}

export async function saveActivityTypeAction(_: ActionResult, fd: FormData): Promise<ActionResult> {
  try {
    const admin = await requireAdmin();
    const name = s(fd.get('name'), 80); if (!name) throw new Error('Name required.');
    const mult = Number(fd.get('multiplier'));
    if (!(mult > 0 && mult <= 10)) throw new Error('Multiplier must be between 0.01 and 10.');
    const id = s(fd.get('id'));
    if (id) await q(`UPDATE activity_types SET name=$2, multiplier=$3, description=$4, active=$5 WHERE id=$1`, [id, name, mult, s(fd.get('description'), 300) || null, fd.get('active') === 'on']);
    else await q(`INSERT INTO activity_types (name, multiplier, description) VALUES ($1,$2,$3)`, [name, mult, s(fd.get('description'), 300) || null]);
    await audit(admin.id, 'activity_type.save', { name, mult });
    revalidatePath('/admin/settings');
    return { ok: 'Saved.' };
  } catch (e) { return { error: friendlyError(e) }; }
}

export async function setOrgStatusAction(_: ActionResult, fd: FormData): Promise<ActionResult> {
  try {
    const admin = await requireAdmin();
    const status = String(fd.get('status'));
    if (!['active', 'suspended', 'rejected', 'pending'].includes(status)) throw new Error('Bad status');
    await q(`UPDATE orgs SET status=$2 WHERE id=$1`, [fd.get('org_id'), status]);
    await audit(admin.id, 'org.status', { org: fd.get('org_id'), status });
    revalidatePath('/admin', 'layout');
    return { ok: `Organization ${status}.` };
  } catch (e) { return { error: friendlyError(e) }; }
}

export async function setUserAction(_: ActionResult, fd: FormData): Promise<ActionResult> {
  try {
    const admin = await requireAdmin();
    const id = String(fd.get('user_id'));
    const op = String(fd.get('op'));
    if (id === admin.id && op !== 'activate') throw new Error('You cannot change your own admin access or status.');
    if (op === 'suspend') await q(`UPDATE users SET status='suspended' WHERE id=$1`, [id]);
    else if (op === 'activate') await q(`UPDATE users SET status='active' WHERE id=$1`, [id]);
    else if (op === 'admin') await q(`UPDATE users SET is_admin = NOT is_admin WHERE id=$1`, [id]);
    else throw new Error('Unknown operation');
    await audit(admin.id, `user.${op}`, { user: id });
    revalidatePath('/admin/users');
    return { ok: 'Updated.' };
  } catch (e) { return { error: friendlyError(e) }; }
}

export async function reverseTxnAction(_: ActionResult, fd: FormData): Promise<ActionResult> {
  try {
    const admin = await requireAdmin();
    const reason = s(fd.get('reason'), 200);
    if (reason.length < 3) throw new Error('Give a reason for the reversal.');
    await one(`SELECT reverse_txn($1,$2,$3)`, [fd.get('txn_id'), admin.id, reason]);
    await audit(admin.id, 'txn.reverse', { txn: fd.get('txn_id'), reason });
    revalidatePath('/admin', 'layout');
    return { ok: 'Reversed.' };
  } catch (e) { return { error: friendlyError(e) }; }
}

/** Grant (mint) or claw back credits outside the claim flow — always audited. */
export async function adjustAction(_: ActionResult, fd: FormData): Promise<ActionResult> {
  try {
    const admin = await requireAdmin();
    const email = s(fd.get('email')).toLowerCase();
    const w = await one<any>(`SELECT w.id FROM users u JOIN wallets w ON w.user_id=u.id WHERE u.email=$1`, [email]);
    if (!w) throw new Error('No member with that email.');
    const amount = parseCredits(fd.get('amount'));
    const memo = s(fd.get('memo'), 200); if (memo.length < 3) throw new Error('A memo is required for adjustments.');
    const sign = fd.get('direction') === 'debit' ? -1 : 1;
    await one(`SELECT post_txn($1,'manual',$2,$3,jsonb_build_array(jsonb_build_object('wallet_id',issuance_wallet(),'amount',$4::bigint), jsonb_build_object('wallet_id',$5::uuid,'amount',$6::bigint)))`,
      [sign > 0 ? 'mint' : 'adjustment', memo, admin.id, -sign * amount, w.id, sign * amount]);
    await audit(admin.id, 'wallet.adjust', { email, amount: sign * amount, memo });
    revalidatePath('/admin', 'layout');
    return { ok: `${sign > 0 ? 'Granted' : 'Debited'} ${fmt(amount)} credits ${sign > 0 ? 'to' : 'from'} ${email}.` };
  } catch (e) { return { error: friendlyError(e) }; }
}

export async function settleAction(_: ActionResult, fd: FormData): Promise<ActionResult> {
  try {
    const admin = await requireAdmin();
    const r = await one<any>(`SELECT sr.*, w.id AS wallet_id FROM settlement_requests sr JOIN wallets w ON w.org_id = sr.org_id WHERE sr.id=$1 AND sr.status='pending'`, [fd.get('id')]);
    if (!r) throw new Error('Request not found or already processed.');
    if (fd.get('decision') === 'reject') {
      await q(`UPDATE settlement_requests SET status='rejected', reviewed_by=$2, reviewed_at=now() WHERE id=$1`, [r.id, admin.id]);
    } else {
      const t = await one<{ post_txn: string }>(`SELECT post_txn('retire','settlement',$1,$2,jsonb_build_array(jsonb_build_object('wallet_id',$3::uuid,'amount',$4::bigint), jsonb_build_object('wallet_id',issuance_wallet(),'amount',$5::bigint)),'settlement',$6)`,
        [`Settlement ${s(fd.get('reference'), 80) || ''}`.trim(), admin.id, r.wallet_id, -r.amount, r.amount, r.id]);
      await q(`UPDATE settlement_requests SET status='settled', reviewed_by=$2, reviewed_at=now(), txn_id=$3 WHERE id=$1`, [r.id, admin.id, t!.post_txn]);
    }
    await audit(admin.id, 'settlement.' + (fd.get('decision') === 'reject' ? 'reject' : 'settle'), { id: r.id });
    revalidatePath('/admin', 'layout');
    return { ok: fd.get('decision') === 'reject' ? 'Rejected.' : 'Settled — credits retired from circulation.' };
  } catch (e) { return { error: friendlyError(e) }; }
}
