'use server';
import { revalidatePath } from 'next/cache';
import { one, q, friendlyError } from '@/lib/db';
import { fmt, parseCredits } from '@/lib/money';
import { audit, requireOrg, requireUser, settings } from '@/lib/session';
import { checkPin, verify } from '@/lib/tokens';
import { today } from '@/lib/time';
import type { ActionResult } from '@/components/ActionForm';

const s = (v: FormDataEntryValue | null, max = 200) => String(v ?? '').trim().slice(0, max);
function active(org: any) { if (org.status !== 'active') throw new Error('This organization is awaiting network approval.'); }

export async function applyOrgAction(_: ActionResult, fd: FormData): Promise<ActionResult> {
  try {
    const user = await requireUser();
    const name = s(fd.get('name'), 120);
    const kind = String(fd.get('kind'));
    if (name.length < 2) throw new Error('Enter the organization name.');
    if (!['verifier', 'provider', 'both'].includes(kind)) throw new Error('Choose what the organization does.');
    const org = await one<any>(`INSERT INTO orgs (name, kind, description, address, npi, website, created_by) VALUES ($1,$2,$3,$4,$5,$6,$7) RETURNING id`,
      [name, kind, s(fd.get('description'), 1000) || null, s(fd.get('address')) || null, s(fd.get('npi'), 10) || null, s(fd.get('website')) || null, user.id]);
    await q(`INSERT INTO wallets (owner_type, org_id) VALUES ('org',$1)`, [org.id]);
    await q(`INSERT INTO org_members (org_id, user_id, role) VALUES ($1,$2,'owner')`, [org.id, user.id]);
    await audit(user.id, 'org.apply', { org: org.id, name, kind });
    revalidatePath('/orgs');
    return { ok: 'Application submitted. A network admin will review it.', data: { id: org.id } };
  } catch (e) { return { error: friendlyError(e) }; }
}

export async function updateOrgAction(_: ActionResult, fd: FormData): Promise<ActionResult> {
  try {
    const { org } = await requireOrg(String(fd.get('org_id')), undefined, { owner: true });
    await q(`UPDATE orgs SET description=$2, address=$3, website=$4 WHERE id=$1`, [org.id, s(fd.get('description'), 1000) || null, s(fd.get('address')) || null, s(fd.get('website')) || null]);
    revalidatePath(`/orgs/${org.id}`);
    return { ok: 'Saved.' };
  } catch (e) { return { error: friendlyError(e) }; }
}

// ---------- Provider: point of sale ----------
async function chargeAmount(orgId: string, fd: FormData) {
  const itemIds = fd.getAll('item').map(String).filter(Boolean);
  if (itemIds.length) {
    const items = await q<any>(`SELECT id, name, price FROM catalog_items WHERE org_id=$1 AND active AND id = ANY($2::uuid[])`, [orgId, itemIds]);
    return { amount: items.reduce((a, i) => a + i.price, 0), items, memo: s(fd.get('memo')) || items.map((i) => i.name).join(', ') };
  }
  return { amount: parseCredits(fd.get('amount')), items: [], memo: s(fd.get('memo')) };
}

export async function createChargeAction(_: ActionResult, fd: FormData): Promise<ActionResult> {
  try {
    const { user, org } = await requireOrg(String(fd.get('org_id')), 'provider'); active(org);
    const { amount, items, memo } = await chargeAmount(org.id, fd);
    const st = await settings();
    const r = await one<any>(`INSERT INTO payment_requests (org_id, created_by, amount, memo, items, expires_at)
      VALUES ($1,$2,$3,$4,$5, now() + make_interval(mins => $6)) RETURNING id, amount, memo, expires_at`,
      [org.id, user.id, amount, memo || null, JSON.stringify(items), st.request_ttl_min]);
    return { ok: 'Show this code to the member.', data: r };
  } catch (e) { return { error: friendlyError(e) }; }
}

export async function cancelChargeAction(_: ActionResult, fd: FormData): Promise<ActionResult> {
  try {
    const { org } = await requireOrg(String(fd.get('org_id')), 'provider');
    await q(`UPDATE payment_requests SET status='cancelled' WHERE id=$1 AND org_id=$2 AND status='open'`, [fd.get('request_id'), org.id]);
    return { ok: 'Cancelled.' };
  } catch (e) { return { error: friendlyError(e) }; }
}

export async function chargePayCodeAction(_: ActionResult, fd: FormData): Promise<ActionResult> {
  try {
    const { user, org } = await requireOrg(String(fd.get('org_id')), 'provider'); active(org);
    const tok = verify<{ n: string; t: string }>(s(fd.get('token'), 500).replace(/^TENDED:PAY:/, ''));
    if (!tok || tok.t !== 'pay') throw new Error('That is not a Tended pay code.');
    const { amount, memo } = await chargeAmount(org.id, fd);
    await one(`SELECT redeem_pay_code($1,$2,$3,$4,$5)`, [tok.n, org.id, amount, user.id, memo || `Payment to ${org.name}`]);
    const who = await one<any>(`SELECT u.name, u.email FROM pay_codes p JOIN users u ON u.id=p.user_id WHERE p.nonce=$1`, [tok.n]);
    revalidatePath(`/orgs/${org.id}`);
    return { ok: `Received ${fmt(amount)} credits from ${who?.name || who?.email}.` };
  } catch (e) { return { error: friendlyError(e) }; }
}

export async function chargeCardAction(_: ActionResult, fd: FormData): Promise<ActionResult> {
  try {
    const { user, org } = await requireOrg(String(fd.get('org_id')), 'provider'); active(org);
    const token = s(fd.get('card_token'), 200).replace(/^tended-card:/, '');
    const card = await one<any>(`SELECT c.*, w.id AS wallet_id, u.name, u.email, u.status AS user_status FROM nfc_cards c
      JOIN users u ON u.id=c.user_id JOIN wallets w ON w.user_id=c.user_id WHERE c.card_token=$1`, [token]);
    if (!card) throw new Error('Card not recognized.');
    if (card.status !== 'active' || card.user_status !== 'active') throw new Error('This card is frozen.');
    if (!checkPin(s(fd.get('pin'), 10), card.pin_hash)) {
      const r = await one<any>(`UPDATE nfc_cards SET failed_attempts = failed_attempts + 1,
        status = CASE WHEN failed_attempts + 1 >= 5 THEN 'frozen' ELSE status END WHERE id=$1 RETURNING failed_attempts, status`, [card.id]);
      throw new Error(r.status === 'frozen' ? 'Too many wrong PINs — card frozen. Member can unfreeze it in their wallet.' : `Wrong PIN (${5 - r.failed_attempts} tries left).`);
    }
    const { amount, memo } = await chargeAmount(org.id, fd);
    const st = await settings();
    if (amount > st.card_tx_limit) throw new Error(`Card taps are limited to ${fmt(st.card_tx_limit)} credits. Use a QR charge instead.`);
    await one(`SELECT post_txn('payment','nfc_card',$1,$2,$3,'nfc_card',$4)`, [memo || `Payment to ${org.name}`, user.id,
      JSON.stringify([{ wallet_id: card.wallet_id, amount: -amount }, { wallet_id: org.wallet_id, amount }]), card.id]);
    await q(`UPDATE nfc_cards SET failed_attempts=0, last_used_at=now() WHERE id=$1`, [card.id]);
    revalidatePath(`/orgs/${org.id}`);
    return { ok: `Received ${fmt(amount)} credits from ${card.name || card.email}.` };
  } catch (e) { return { error: friendlyError(e) }; }
}

// ---------- Provider: catalog ----------
export async function saveItemAction(_: ActionResult, fd: FormData): Promise<ActionResult> {
  try {
    const { org } = await requireOrg(String(fd.get('org_id')), 'provider');
    const name = s(fd.get('name'), 120); if (!name) throw new Error('Name is required.');
    const price = parseCredits(fd.get('price'));
    const cat = fd.get('category') === 'product' ? 'product' : 'service';
    const id = s(fd.get('id'));
    if (id) await q(`UPDATE catalog_items SET name=$3, description=$4, price=$5, category=$6 WHERE id=$1 AND org_id=$2`, [id, org.id, name, s(fd.get('description'), 500) || null, price, cat]);
    else await q(`INSERT INTO catalog_items (org_id, name, description, price, category) VALUES ($1,$2,$3,$4,$5)`, [org.id, name, s(fd.get('description'), 500) || null, price, cat]);
    revalidatePath(`/orgs/${org.id}/catalog`);
    return { ok: 'Saved.' };
  } catch (e) { return { error: friendlyError(e) }; }
}
export async function toggleItemAction(_: ActionResult, fd: FormData): Promise<ActionResult> {
  try {
    const { org } = await requireOrg(String(fd.get('org_id')), 'provider');
    await q(`UPDATE catalog_items SET active = NOT active WHERE id=$1 AND org_id=$2`, [fd.get('id'), org.id]);
    revalidatePath(`/orgs/${org.id}/catalog`);
    return { ok: 'Updated.' };
  } catch (e) { return { error: friendlyError(e) }; }
}

export async function requestSettlementAction(_: ActionResult, fd: FormData): Promise<ActionResult> {
  try {
    const { user, org } = await requireOrg(String(fd.get('org_id')), 'provider', { owner: true }); active(org);
    const amount = parseCredits(fd.get('amount'));
    const pending = await one<{ t: number }>(`SELECT coalesce(sum(amount),0)::bigint t FROM settlement_requests WHERE org_id=$1 AND status='pending'`, [org.id]);
    if (amount + (pending?.t ?? 0) > org.balance) throw new Error('Amount exceeds your available credits (including pending requests).');
    await q(`INSERT INTO settlement_requests (org_id, amount, note, requested_by) VALUES ($1,$2,$3,$4)`, [org.id, amount, s(fd.get('note'), 500) || null, user.id]);
    revalidatePath(`/orgs/${org.id}`);
    return { ok: 'Settlement requested. The network admin will process it.' };
  } catch (e) { return { error: friendlyError(e) }; }
}

// ---------- Verifier ----------
export async function saveOpportunityAction(_: ActionResult, fd: FormData): Promise<ActionResult> {
  try {
    const { org } = await requireOrg(String(fd.get('org_id')), 'verifier'); active(org);
    const title = s(fd.get('title'), 120); if (!title) throw new Error('Title is required.');
    const at = await one<any>(`SELECT id FROM activity_types WHERE id=$1 AND active`, [fd.get('activity_type_id')]);
    if (!at) throw new Error('Choose an activity type.');
    const cap = Number(fd.get('capacity') || 0) || null;
    const starts = s(fd.get('starts_at')) || null, ends = s(fd.get('ends_at')) || null;
    await q(`INSERT INTO opportunities (org_id, title, description, activity_type_id, location, starts_at, ends_at, capacity)
             VALUES ($1,$2,$3,$4,$5,$6,$7,$8)`, [org.id, title, s(fd.get('description'), 1000) || null, at.id, s(fd.get('location')) || null, starts, ends, cap]);
    revalidatePath(`/orgs/${org.id}/opportunities`);
    return { ok: 'Opportunity created.' };
  } catch (e) { return { error: friendlyError(e) }; }
}
export async function toggleOpportunityAction(_: ActionResult, fd: FormData): Promise<ActionResult> {
  try {
    const { org } = await requireOrg(String(fd.get('org_id')), 'verifier');
    await q(`UPDATE opportunities SET active = NOT active WHERE id=$1 AND org_id=$2`, [fd.get('id'), org.id]);
    revalidatePath(`/orgs/${org.id}/opportunities`);
    return { ok: 'Updated.' };
  } catch (e) { return { error: friendlyError(e) }; }
}

export async function reviewClaimAction(_: ActionResult, fd: FormData): Promise<ActionResult> {
  try {
    const { user, org } = await requireOrg(String(fd.get('org_id')), 'verifier'); active(org);
    const claim = await one<any>(`SELECT * FROM hour_claims WHERE id=$1 AND org_id=$2`, [fd.get('claim_id'), org.id]);
    if (!claim) throw new Error('Claim not found.');
    const note = s(fd.get('note'), 300) || null;
    if (fd.get('decision') === 'reject') {
      const r = await q(`UPDATE hour_claims SET status='rejected', reviewed_by=$2, reviewed_at=now(), review_note=$3 WHERE id=$1 AND status IN ('pending','open') RETURNING id`, [claim.id, user.id, note]);
      if (!r.length) throw new Error('This claim was already reviewed.');
    } else {
      const mins = Number(fd.get('minutes') || 0);
      if (mins && mins !== claim.minutes) {
        if (mins < 1 || mins > 1440) throw new Error('Minutes must be 1–1440.');
        await q(`UPDATE hour_claims SET minutes=$2 WHERE id=$1 AND status='pending'`, [claim.id, mins]);
      }
      await one(`SELECT approve_claim($1,$2,$3)`, [claim.id, user.id, note]);
    }
    await audit(user.id, `claim.${fd.get('decision') === 'reject' ? 'reject' : 'approve'}`, { claim: claim.id });
    revalidatePath(`/orgs/${org.id}/claims`);
    return { ok: fd.get('decision') === 'reject' ? 'Rejected.' : 'Approved — credits issued.' };
  } catch (e) { return { error: friendlyError(e) }; }
}

export async function logHoursAction(_: ActionResult, fd: FormData): Promise<ActionResult> {
  try {
    const { user, org } = await requireOrg(String(fd.get('org_id')), 'verifier'); active(org);
    const email = s(fd.get('email')).toLowerCase();
    const member = await one<any>(`SELECT id FROM users WHERE email=$1 AND status='active'`, [email]);
    if (!member) throw new Error('No active member with that email. Ask them to sign in to Tended first.');
    const minutes = Math.round(Number(fd.get('hours') || 0) * 60);
    if (!(minutes >= 5 && minutes <= 1440)) throw new Error('Enter hours between 0.1 and 24.');
    const date = s(fd.get('work_date')) || today();
    if (!/^\d{4}-\d{2}-\d{2}$/.test(date) || date > today()) throw new Error('Enter a valid date (not in the future).');
    const c = await one<any>(`INSERT INTO hour_claims (user_id, org_id, activity_type_id, description, work_date, minutes, source)
       VALUES ($1,$2,$3,$4,$5,$6,'verifier') RETURNING id`, [member.id, org.id, fd.get('activity_type_id'), s(fd.get('description'), 500) || 'Logged by coordinator', date, minutes]);
    await one(`SELECT approve_claim($1,$2,$3)`, [c.id, user.id, 'Logged by coordinator']);
    await audit(user.id, 'claim.log', { claim: c.id, member: member.id });
    revalidatePath(`/orgs/${org.id}/claims`);
    return { ok: `Logged ${minutes / 60}h for ${email}. Credits issued.` };
  } catch (e) { return { error: friendlyError(e) }; }
}

// ---------- Team ----------
export async function addStaffAction(_: ActionResult, fd: FormData): Promise<ActionResult> {
  try {
    const { user, org } = await requireOrg(String(fd.get('org_id')), undefined, { owner: true });
    const email = s(fd.get('email')).toLowerCase();
    if (!/^[^@\s]+@[^@\s]+\.[^@\s]+$/.test(email)) throw new Error('Enter a valid email.');
    const role = fd.get('role') === 'owner' ? 'owner' : 'staff';
    const u = await one<any>(`INSERT INTO users (email) VALUES ($1) ON CONFLICT (email) DO UPDATE SET email=EXCLUDED.email RETURNING id`, [email]);
    await q(`INSERT INTO wallets (owner_type, user_id) VALUES ('user',$1) ON CONFLICT (user_id) DO NOTHING`, [u.id]);
    await q(`INSERT INTO org_members (org_id, user_id, role) VALUES ($1,$2,$3) ON CONFLICT (org_id,user_id) DO UPDATE SET role=EXCLUDED.role`, [org.id, u.id, role]);
    await audit(user.id, 'org.staff.add', { org: org.id, email, role });
    revalidatePath(`/orgs/${org.id}/team`);
    return { ok: `${email} added as ${role}. They’ll see this organization after signing in.` };
  } catch (e) { return { error: friendlyError(e) }; }
}
export async function removeStaffAction(_: ActionResult, fd: FormData): Promise<ActionResult> {
  try {
    const { user, org } = await requireOrg(String(fd.get('org_id')), undefined, { owner: true });
    const target = String(fd.get('user_id'));
    const owners = await one<{ n: number }>(`SELECT count(*)::int n FROM org_members WHERE org_id=$1 AND role='owner' AND user_id<>$2`, [org.id, target]);
    if (!owners?.n) throw new Error('An organization needs at least one owner.');
    await q(`DELETE FROM org_members WHERE org_id=$1 AND user_id=$2`, [org.id, target]);
    await audit(user.id, 'org.staff.remove', { org: org.id, user: target });
    revalidatePath(`/orgs/${org.id}/team`);
    return { ok: 'Removed.' };
  } catch (e) { return { error: friendlyError(e) }; }
}
