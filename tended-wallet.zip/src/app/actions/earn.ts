'use server';
import { revalidatePath } from 'next/cache';
import { one, q, friendlyError } from '@/lib/db';
import { requireUser, settings } from '@/lib/session';
import { today } from '@/lib/time';
import type { ActionResult } from '@/components/ActionForm';

async function flagFor(userId: string, workDate: string, minutes: number): Promise<string | null> {
  const s = await settings();
  const r = await one<{ m: number }>(`SELECT coalesce(sum(minutes),0)::int m FROM hour_claims WHERE user_id=$1 AND work_date=$2 AND status IN ('pending','approved')`, [userId, workDate]);
  const total = (r?.m ?? 0) + minutes;
  if (total > s.daily_minute_cap) return `Over daily cap: ${Math.round(total / 6) / 10}h logged on ${workDate}`;
  return null;
}

export async function submitClaimAction(_: ActionResult, fd: FormData): Promise<ActionResult> {
  try {
    const user = await requireUser();
    const orgId = String(fd.get('org_id'));
    const org = await one<any>(`SELECT id, kind, status FROM orgs WHERE id=$1`, [orgId]);
    if (!org || org.status !== 'active' || org.kind === 'provider') throw new Error('Choose an active verifying organization.');
    const at = await one<any>(`SELECT id FROM activity_types WHERE id=$1 AND active`, [fd.get('activity_type_id')]);
    if (!at) throw new Error('Choose an activity type.');
    const date = String(fd.get('work_date') || '');
    if (!/^\d{4}-\d{2}-\d{2}$/.test(date)) throw new Error('Enter the date you served.');
    if (date > today()) throw new Error('Date cannot be in the future.');
    const h = Number(fd.get('hours') || 0), m = Number(fd.get('minutes') || 0);
    const minutes = Math.round(h * 60 + m);
    if (!(minutes >= 5 && minutes <= 1440)) throw new Error('Enter between 5 minutes and 24 hours.');
    const desc = String(fd.get('description') || '').trim().slice(0, 500);
    if (desc.length < 5) throw new Error('Briefly describe what you did.');
    const flagged = await flagFor(user.id, date, minutes);
    await q(`INSERT INTO hour_claims (user_id, org_id, activity_type_id, description, work_date, minutes, source, flagged)
             VALUES ($1,$2,$3,$4,$5,$6,'self',$7)`, [user.id, orgId, at.id, desc, date, minutes, flagged]);
    revalidatePath('/', 'layout');
    return { ok: 'Submitted. The organization will review your hours.' };
  } catch (e) { return { error: friendlyError(e) }; }
}

export async function checkinAction(_: ActionResult, fd: FormData): Promise<ActionResult> {
  try {
    const user = await requireUser();
    const opp = await one<any>(`SELECT p.*, o.status AS org_status FROM opportunities p JOIN orgs o ON o.id=p.org_id WHERE p.checkin_code=$1`, [fd.get('code')]);
    if (!opp || !opp.active || opp.org_status !== 'active') throw new Error('This check-in code is not active.');
    const open = await one<any>(`SELECT * FROM hour_claims WHERE user_id=$1 AND opportunity_id=$2 AND status='open' ORDER BY checkin_at DESC LIMIT 1`, [user.id, opp.id]);
    if (!open) {
      if (opp.capacity) {
        const c = await one<{ n: number }>(`SELECT count(*)::int n FROM hour_claims WHERE opportunity_id=$1 AND status='open'`, [opp.id]);
        if (c!.n >= opp.capacity) throw new Error('This shift is at capacity.');
      }
      await q(`INSERT INTO hour_claims (user_id, org_id, opportunity_id, activity_type_id, description, source, status, checkin_at, work_date)
               VALUES ($1,$2,$3,$4,$5,'checkin','open',now(),current_date)`, [user.id, opp.org_id, opp.id, opp.activity_type_id, opp.title]);
      revalidatePath('/', 'layout');
      return { ok: `Checked in to “${opp.title}”. Scan again when you leave.`, data: { state: 'in' } };
    }
    const minutes = Math.max(1, Math.min(1440, Math.round((Date.now() - new Date(open.checkin_at).getTime()) / 60000)));
    const flagged = await flagFor(user.id, String(open.work_date), minutes);
    await q(`UPDATE hour_claims SET status='pending', checkout_at=now(), minutes=$2, flagged=$3 WHERE id=$1`, [open.id, minutes, flagged]);
    revalidatePath('/', 'layout');
    return { ok: `Checked out after ${Math.floor(minutes / 60)}h ${minutes % 60}m. Sent for approval.`, data: { state: 'out' } };
  } catch (e) { return { error: friendlyError(e) }; }
}
