'use server';
import { revalidatePath } from 'next/cache';
import { one, q, friendlyError } from '@/lib/db';
import { fmt, parseCredits } from '@/lib/money';
import { audit, requireUser, settings } from '@/lib/session';
import { hashPin, randomToken } from '@/lib/tokens';
import type { ActionResult } from '@/components/ActionForm';

export async function payRequestAction(_: ActionResult, fd: FormData): Promise<ActionResult> {
  try {
    const user = await requireUser();
    const id = String(fd.get('request_id'));
    await one(`SELECT pay_request($1,$2)`, [id, user.id]);
    revalidatePath('/', 'layout');
    return { ok: 'Paid. Thank you!', data: { paid: true } };
  } catch (e) { return { error: friendlyError(e) }; }
}

/** Member-initiated payment to a provider (from a sticker / static provider QR or the marketplace). */
export async function payProviderAction(_: ActionResult, fd: FormData): Promise<ActionResult> {
  try {
    const user = await requireUser();
    const orgId = String(fd.get('org_id'));
    const itemIds = fd.getAll('item').map(String).filter(Boolean);
    let amount = 0; let memo = String(fd.get('memo') || '').slice(0, 200);
    const org = await one<any>(`SELECT o.id, o.name, o.status, o.kind, w.id AS wallet_id FROM orgs o JOIN wallets w ON w.org_id=o.id WHERE o.id=$1`, [orgId]);
    if (!org || org.status !== 'active' || org.kind === 'verifier') throw new Error('This provider cannot accept credits right now.');
    if (itemIds.length) {
      const items = await q<any>(`SELECT name, price FROM catalog_items WHERE org_id=$1 AND active AND id = ANY($2::uuid[])`, [orgId, itemIds]);
      amount = items.reduce((s, i) => s + i.price, 0);
      memo = memo || items.map((i) => i.name).join(', ');
    } else amount = parseCredits(fd.get('amount'));
    if (!amount) throw new Error('Choose an item or enter an amount.');
    const via = ['nfc_tag', 'qr_static', 'market'].includes(String(fd.get('via'))) ? String(fd.get('via')) : 'direct';
    const r = await one<{ post_txn: string }>(`SELECT post_txn('payment',$5,$1,$2,$3,'org',$4)`, [
      memo || `Payment to ${org.name}`, user.id,
      JSON.stringify([{ wallet_id: user.wallet_id, amount: -amount }, { wallet_id: org.wallet_id, amount }]), orgId, via]);
    revalidatePath('/', 'layout');
    return { ok: `Paid ${fmt(amount)} credits to ${org.name}.`, data: { txn: r?.post_txn } };
  } catch (e) { return { error: friendlyError(e) }; }
}

export async function sendAction(_: ActionResult, fd: FormData): Promise<ActionResult> {
  try {
    const user = await requireUser();
    const s = await settings();
    if (!s.p2p_enabled) throw new Error('Member-to-member gifts are turned off in this network.');
    const email = String(fd.get('email') || '').trim().toLowerCase();
    const amount = parseCredits(fd.get('amount'));
    const to = await one<any>(`SELECT w.id FROM users u JOIN wallets w ON w.user_id=u.id WHERE u.email=$1 AND u.status='active'`, [email]);
    if (!to) throw new Error('No active member with that email.');
    if (to.id === user.wallet_id) throw new Error('You cannot send credits to yourself.');
    await one(`SELECT post_txn('transfer','manual',$1,$2,$3)`, [String(fd.get('memo') || 'Gift').slice(0, 200), user.id,
      JSON.stringify([{ wallet_id: user.wallet_id, amount: -amount }, { wallet_id: to.id, amount }])]);
    revalidatePath('/', 'layout');
    return { ok: `Sent ${fmt(amount)} credits to ${email}.` };
  } catch (e) { return { error: friendlyError(e) }; }
}

export async function createCardAction(_: ActionResult, fd: FormData): Promise<ActionResult> {
  try {
    const user = await requireUser();
    const pin = String(fd.get('pin') || '');
    if (!/^\d{4,6}$/.test(pin)) throw new Error('PIN must be 4–6 digits.');
    if (pin !== String(fd.get('pin2'))) throw new Error('PINs do not match.');
    const { n } = (await one<{ n: number }>(`SELECT count(*)::int n FROM nfc_cards WHERE user_id=$1 AND status='active'`, [user.id]))!;
    if (n >= 3) throw new Error('You can have up to 3 active cards. Freeze one first.');
    const token = randomToken(18);
    const card = await one<any>(`INSERT INTO nfc_cards (user_id, card_token, pin_hash, label) VALUES ($1,$2,$3,$4) RETURNING id`,
      [user.id, token, hashPin(pin), String(fd.get('label') || 'My card').slice(0, 40)]);
    await audit(user.id, 'card.create', { card: card.id });
    revalidatePath('/wallet/cards');
    return { ok: 'Card created. Hold a blank NFC tag to your phone to write it.', data: { token, id: card.id } };
  } catch (e) { return { error: friendlyError(e) }; }
}

export async function setCardStatusAction(_: ActionResult, fd: FormData): Promise<ActionResult> {
  try {
    const user = await requireUser();
    const status = fd.get('status') === 'active' ? 'active' : 'frozen';
    await q(`UPDATE nfc_cards SET status=$1, failed_attempts=0 WHERE id=$2 AND user_id=$3`, [status, fd.get('id'), user.id]);
    await audit(user.id, `card.${status}`, { card: fd.get('id') });
    revalidatePath('/wallet/cards');
    return { ok: status === 'frozen' ? 'Card frozen.' : 'Card reactivated.' };
  } catch (e) { return { error: friendlyError(e) }; }
}

export async function profileAction(_: ActionResult, fd: FormData): Promise<ActionResult> {
  try {
    const user = await requireUser();
    await q(`UPDATE users SET name=$1, phone=$2 WHERE id=$3`, [String(fd.get('name') || '').slice(0, 80) || null, String(fd.get('phone') || '').slice(0, 30) || null, user.id]);
    revalidatePath('/', 'layout');
    return { ok: 'Saved.' };
  } catch (e) { return { error: friendlyError(e) }; }
}
