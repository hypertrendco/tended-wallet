import { redirect } from 'next/navigation';
import Link from 'next/link';
import Logo from '@/components/Logo';
import { missingConfig } from '@/lib/config';
import { getUser, loginUrl } from '@/lib/session';

export const dynamic = 'force-dynamic';

export default async function Home() {
  if (missingConfig().length) redirect('/setup');
  const user = await getUser();
  if (user) redirect('/wallet');
  const steps = [
    ['Serve', 'Volunteer with a verified community organization. Check in with a QR code at the event, or log your hours.'],
    ['Earn', 'When a coordinator approves your hours, credits are added to your wallet — one credit per hour, more for skilled work.'],
    ['Redeem', 'Pay participating clinics, pharmacies and wellness providers by scanning a QR code or tapping your card.'],
  ];
  return (
    <main className="mx-auto max-w-md px-4 py-10">
      <div className="flex items-center gap-2"><Logo /><span className="text-xl font-bold text-brand-700">Tended</span></div>
      <h1 className="mt-10 text-4xl font-bold tracking-tight leading-tight">Your time, returned as care.</h1>
      <p className="mt-3 text-black/60">A community wallet where hours of service become credits you can spend on healthcare services and products in the network.</p>
      <Link href={loginUrl('/wallet')} className="btn-primary mt-8 w-full py-3.5 text-base">Sign in or join</Link>
      <p className="muted mt-2 text-center">We’ll email you a one-time sign-in link. No password.</p>
      <ol className="mt-10 space-y-3">
        {steps.map(([t, d], i) => (
          <li key={t} className="card flex gap-3">
            <span className="grid h-8 w-8 shrink-0 place-items-center rounded-full bg-brand-50 font-bold text-brand-700">{i + 1}</span>
            <div><p className="font-semibold">{t}</p><p className="muted">{d}</p></div>
          </li>
        ))}
      </ol>
      <p className="muted mt-8 text-xs">Credits are a community exchange unit, not money. They have no cash value and cannot be bought, sold, or withdrawn.</p>
    </main>
  );
}
