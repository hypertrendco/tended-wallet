import { NextResponse } from 'next/server';
import { auth0Configured } from '@/lib/config';
export async function GET(req: Request) {
  const url = new URL(req.url);
  if (auth0Configured()) return NextResponse.redirect(new URL('/auth/logout', url));
  const res = NextResponse.redirect(new URL('/', url));
  res.cookies.delete('dev_session');
  return res;
}
