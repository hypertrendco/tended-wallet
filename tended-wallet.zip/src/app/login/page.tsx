import { redirect } from 'next/navigation';
import { cookies } from 'next/headers';
import { devLoginEnabled } from '@/lib/config';
import { sign } from '@/lib/tokens';
import Logo from '@/components/Logo';

export const dynamic = 'force-dynamic';

async function login(fd: FormData) {
  'use server';
  if (!devLoginEnabled()) throw new Error('Dev login disabled');
  const email = String(fd.get('email') || '').trim().toLowerCase();
  if (!/^[^@\s]+@[^@\s]+\.[^@\s]+$/.test(email)) throw new Error('Enter a valid email');
  (await cookies()).set('dev_session', sign({ email }), { httpOnly: true, sameSite: 'lax', path: '/', maxAge: 60 * 60 * 24 * 7 });
  const next = String(fd.get('next') || '/wallet');
  redirect(next.startsWith('/') ? next : '/wallet');
}

export default async function Login({ searchParams }: { searchParams: Promise<{ next?: string }> }) {
  if (!devLoginEnabled()) redirect('/auth/login');
  const { next } = await searchParams;
  return (
    <main className="mx-auto max-w-sm px-4 py-16">
      <div className="flex items-center gap-2"><Logo /><span className="text-xl font-bold text-brand-700">Tended</span></div>
      <div className="mt-6 rounded-xl bg-sun-400/20 p-3 text-sm">Demo sign-in: no email verification. Configure Auth0 before inviting real members.</div>
      <form action={login} className="mt-6 space-y-3">
        <input type="hidden" name="next" value={next || '/wallet'} />
        <label className="label" htmlFor="email">Email</label>
        <input id="email" name="email" type="email" required className="input" placeholder="you@example.org" />
        <button className="btn-primary w-full">Continue</button>
      </form>
    </main>
  );
}
