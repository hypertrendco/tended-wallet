import { NextResponse } from 'next/server';
import { one, q } from '@/lib/db';
import { getUser, settings } from '@/lib/session';
import { randomToken, sign } from '@/lib/tokens';

export const dynamic = 'force-dynamic';

/** Issue a one-time, short-lived pay code for the signed-in member. */
export async function POST(req: Request) {
  const user = await getUser();
  if (!user || user.status !== 'active') return NextResponse.json({ error: 'Not signed in' }, { status: 401 });
  const body = await req.json().catch(() => ({}));
  const max = body?.max ? Math.round(Number(body.max) * 100) : null;
  if (max !== null && !(max > 0)) return NextResponse.json({ error: 'Bad limit' }, { status: 400 });
  const st = await settings();
  const nonce = randomToken(12);
  // retire this member's unused codes so only one is live at a time
  await q(`UPDATE pay_codes SET expires_at = now() WHERE user_id=$1 AND used_at IS NULL AND expires_at > now()`, [user.id]);
  const r = await one<any>(`INSERT INTO pay_codes (nonce, user_id, max_amount, expires_at) VALUES ($1,$2,$3, now() + make_interval(secs => $4)) RETURNING expires_at`,
    [nonce, user.id, max, st.pay_code_ttl_sec]);
  return NextResponse.json({ code: `TENDED:PAY:${sign({ t: 'pay', n: nonce })}`, expires_at: r.expires_at, nonce });
}

/** Poll whether a code has been used. */
export async function GET(req: Request) {
  const user = await getUser();
  if (!user) return NextResponse.json({ error: 'Not signed in' }, { status: 401 });
  const nonce = new URL(req.url).searchParams.get('n');
  const r = await one<any>(`SELECT p.used_at, t.memo, t.amount FROM pay_codes p LEFT JOIN txns t ON t.id=p.txn_id WHERE p.nonce=$1 AND p.user_id=$2`, [nonce, user.id]);
  return NextResponse.json({ used: !!r?.used_at, amount: r?.amount ?? null, memo: r?.memo ?? null });
}
