import { NextResponse } from 'next/server';
import { one } from '@/lib/db';
import { getUser } from '@/lib/session';

export const dynamic = 'force-dynamic';

export async function GET(_: Request, { params }: { params: Promise<{ id: string }> }) {
  const user = await getUser();
  if (!user) return NextResponse.json({ error: 'Not signed in' }, { status: 401 });
  const { id } = await params;
  if (!/^[0-9a-f-]{36}$/.test(id)) return NextResponse.json({ error: 'Bad id' }, { status: 400 });
  const r = await one<any>(`SELECT r.status, r.expires_at < now() AS expired, u.name, u.email FROM payment_requests r
    LEFT JOIN users u ON u.id = r.paid_by
    WHERE r.id=$1 AND (r.org_id IN (SELECT org_id FROM org_members WHERE user_id=$2) OR $3)`, [id, user.id, user.is_admin]);
  if (!r) return NextResponse.json({ error: 'Not found' }, { status: 404 });
  return NextResponse.json({ status: r.status === 'open' && r.expired ? 'expired' : r.status, paid_by: r.name || r.email || null });
}
