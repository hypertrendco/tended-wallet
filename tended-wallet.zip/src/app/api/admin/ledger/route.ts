import { q } from '@/lib/db';
import { getUser } from '@/lib/session';

export const dynamic = 'force-dynamic';

export async function GET(req: Request) {
  const user = await getUser();
  if (!user?.is_admin) return new Response('Forbidden', { status: 403 });
  const kind = new URL(req.url).searchParams.get('kind') || '';
  const rows = await q<any>(`SELECT t.created_at, t.id AS txn_id, t.kind, t.method, t.memo, t.reversed, e.amount,
      coalesce(o.name, u.email, w.system_key) AS wallet, w.owner_type
    FROM txns t JOIN entries e ON e.txn_id=t.id JOIN wallets w ON w.id=e.wallet_id
    LEFT JOIN orgs o ON o.id=w.org_id LEFT JOIN users u ON u.id=w.user_id
    WHERE $1='' OR t.kind=$1 ORDER BY t.created_at, e.id`, [kind]);
  const esc = (v: unknown) => { const s = v instanceof Date ? v.toISOString() : String(v ?? ''); return /[",\n]/.test(s) ? `"${s.replace(/"/g, '""')}"` : s; };
  const head = ['created_at', 'txn_id', 'kind', 'method', 'memo', 'reversed', 'wallet', 'owner_type', 'credits'];
  const body = rows.map((r) => [r.created_at, r.txn_id, r.kind, r.method, r.memo, r.reversed, r.wallet, r.owner_type, (r.amount / 100).toFixed(2)].map(esc).join(','));
  return new Response([head.join(','), ...body].join('\n'), {
    headers: { 'content-type': 'text/csv', 'content-disposition': `attachment; filename="tended-ledger-${new Date().toISOString().slice(0, 10)}.csv"` },
  });
}
