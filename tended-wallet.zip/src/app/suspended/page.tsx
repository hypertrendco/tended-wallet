export default function Suspended() {
  return <main className="mx-auto max-w-md px-4 py-16 text-center"><h1 className="h1">Account paused</h1><p className="muted mt-2">Your account has been suspended by the network administrator. Contact your coordinator for help.</p><a className="btn-secondary mt-6" href="/logout">Sign out</a></main>;
}
