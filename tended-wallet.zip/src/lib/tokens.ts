import crypto from 'node:crypto';
import { appSecret } from './config';

const b64u = (b: Buffer) => b.toString('base64url');

/** Short signed token: "<payload>.<sig>" (payload base64url JSON). */
export function sign(payload: object): string {
  const p = b64u(Buffer.from(JSON.stringify(payload)));
  const s = b64u(crypto.createHmac('sha256', appSecret()).update(p).digest()).slice(0, 22);
  return `${p}.${s}`;
}
export function verify<T = any>(token: string): T | null {
  const [p, s] = token.split('.');
  if (!p || !s) return null;
  const exp = b64u(crypto.createHmac('sha256', appSecret()).update(p).digest()).slice(0, 22);
  if (exp.length !== s.length || !crypto.timingSafeEqual(Buffer.from(exp), Buffer.from(s))) return null;
  try { return JSON.parse(Buffer.from(p, 'base64url').toString()); } catch { return null; }
}
export function randomToken(bytes = 16) { return crypto.randomBytes(bytes).toString('base64url'); }

export function hashPin(pin: string, salt = crypto.randomBytes(12).toString('hex')) {
  const h = crypto.scryptSync(pin, salt, 32).toString('hex');
  return `${salt}:${h}`;
}
export function checkPin(pin: string, stored: string) {
  const [salt, h] = stored.split(':');
  const test = crypto.scryptSync(pin, salt, 32).toString('hex');
  return crypto.timingSafeEqual(Buffer.from(h, 'hex'), Buffer.from(test, 'hex'));
}
