import { Auth0Client } from '@auth0/nextjs-auth0/server';
import { auth0Configured } from './config';

let client: Auth0Client | null = null;
export function auth0(): Auth0Client | null {
  if (!auth0Configured()) return null;
  if (!client) {
    client = new Auth0Client({
      appBaseUrl: process.env.APP_BASE_URL || (process.env.VERCEL_PROJECT_PRODUCTION_URL ? `https://${process.env.VERCEL_PROJECT_PRODUCTION_URL}` : undefined),
      authorizationParameters: { scope: 'openid profile email' },
    });
  }
  return client;
}
