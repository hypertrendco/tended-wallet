import { unstable_rethrow } from 'next/navigation';
import pg from 'pg';

declare global { var __tendedPool: pg.Pool | undefined }

// Return BIGINT as JS number (credit hundredths stay well within 2^53).
pg.types.setTypeParser(20, (v) => Number(v));
pg.types.setTypeParser(1700, (v) => Number(v));
pg.types.setTypeParser(1082, (v) => v); // DATE as 'YYYY-MM-DD'

export function pool(): pg.Pool {
  if (!global.__tendedPool) {
    const url = process.env.DATABASE_URL;
    if (!url) throw new Error('DATABASE_URL is not configured');
    const local = /localhost|127\.0\.0\.1/.test(url);
    global.__tendedPool = new pg.Pool({
      connectionString: url,
      ssl: local ? false : { rejectUnauthorized: false },
      max: 5,
      idleTimeoutMillis: 10_000,
    });
    const tz = (process.env.NETWORK_TZ || 'America/New_York').replace(/[^\w/+-]/g, '');
    global.__tendedPool.on('connect', (c) => { c.query(`SET TIME ZONE '${tz}'`).catch(() => {}); });
  }
  return global.__tendedPool;
}

export async function q<T = any>(text: string, params: unknown[] = []): Promise<T[]> {
  const r = await pool().query(text, params);
  return r.rows as T[];
}

export async function one<T = any>(text: string, params: unknown[] = []): Promise<T | null> {
  const rows = await q<T>(text, params);
  return rows[0] ?? null;
}

const FRIENDLY: Record<string, string> = {
  INSUFFICIENT_FUNDS: 'Not enough credits in the wallet.',
  BALANCE_CAP_EXCEEDED: 'This would exceed the network’s maximum member balance.',
  REQUEST_NOT_OPEN: 'This payment request was already paid or cancelled.',
  REQUEST_EXPIRED: 'This payment request has expired. Ask the provider for a new code.',
  REQUEST_NOT_FOUND: 'Payment request not found.',
  PROVIDER_INACTIVE: 'This provider is not active in the network.',
  CODE_INVALID: 'That pay code is not valid.',
  CODE_USED: 'That pay code was already used. Ask the member to refresh it.',
  CODE_EXPIRED: 'That pay code expired. Ask the member to refresh it.',
  CODE_LIMIT: 'Amount is above the limit the member set on this code.',
  CLAIM_NOT_PENDING: 'This claim was already reviewed.',
  CLAIM_NO_MINUTES: 'This claim has no hours yet (member has not checked out).',
  SELF_APPROVAL: 'You cannot approve your own hours.',
  TXN_ALREADY_REVERSED: 'That transaction was already reversed.',
  TXN_IS_REVERSAL: 'A reversal cannot itself be reversed.',
};

export function friendlyError(e: unknown): string {
  unstable_rethrow(e); // let redirect()/notFound() propagate
  const msg = e instanceof Error ? e.message : String(e);
  for (const k of Object.keys(FRIENDLY)) if (msg.includes(k)) return FRIENDLY[k];
  console.error(e);
  return msg.length < 160 ? msg : 'Something went wrong.';
}
