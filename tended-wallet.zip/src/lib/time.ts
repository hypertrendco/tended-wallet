/** The network operates in one local timezone (set NETWORK_TZ; default America/New_York). */
export const TZ = process.env.NETWORK_TZ || 'America/New_York';
type O = Intl.DateTimeFormatOptions;
export const dt = (d: Date | string, o: O = { month: 'short', day: 'numeric', hour: 'numeric', minute: '2-digit' }) => new Date(d).toLocaleString('en-US', { timeZone: TZ, ...o });
export const dDate = (d: Date | string) => dt(d, { month: 'short', day: 'numeric', year: 'numeric' });
export const dTime = (d: Date | string) => dt(d, { hour: 'numeric', minute: '2-digit' });
export const today = () => new Date().toLocaleDateString('en-CA', { timeZone: TZ });
