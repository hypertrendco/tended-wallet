/** Credits are stored as integer hundredths. */
export function fmt(h: number | null | undefined): string {
  const v = (h ?? 0) / 100;
  return v.toLocaleString('en-US', { minimumFractionDigits: v % 1 ? 2 : 0, maximumFractionDigits: 2 });
}
export function parseCredits(input: FormDataEntryValue | string | null | undefined): number {
  const s = String(input ?? '').trim();
  if (!/^\d+(\.\d{1,2})?$/.test(s)) throw new Error('Enter an amount like 5 or 2.50');
  const h = Math.round(parseFloat(s) * 100);
  if (h <= 0) throw new Error('Amount must be greater than zero');
  if (h > 100_000_00) throw new Error('Amount is too large');
  return h;
}
export function hours(min: number | null | undefined) {
  if (!min) return '—';
  const h = Math.floor(min / 60), m = min % 60;
  return h ? `${h}h${m ? ` ${m}m` : ''}` : `${m}m`;
}
