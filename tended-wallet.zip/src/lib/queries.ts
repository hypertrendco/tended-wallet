import 'server-only';
import { q } from './db';

export type Activity = { id: string; kind: string; method: string; memo: string | null; created_at: Date; amount: number; party: string; reversed: boolean };

export function activity(walletId: string, limit = 30) {
  return q<Activity>(`
    SELECT t.id, t.kind, t.method, t.memo, t.created_at, t.reversed, e.amount,
      (SELECT coalesce(o.name, u.name, u.email, 'Tended network') FROM entries e2
         JOIN wallets w2 ON w2.id=e2.wallet_id LEFT JOIN orgs o ON o.id=w2.org_id LEFT JOIN users u ON u.id=w2.user_id
        WHERE e2.txn_id=t.id AND e2.wallet_id<>e.wallet_id LIMIT 1) AS party
    FROM entries e JOIN txns t ON t.id=e.txn_id WHERE e.wallet_id=$1 ORDER BY e.id DESC LIMIT $2`, [walletId, limit]);
}

export function activityTypes() {
  return q<{ id: string; name: string; multiplier: number; description: string | null; active: boolean }>(`SELECT * FROM activity_types ORDER BY active DESC, name`);
}
