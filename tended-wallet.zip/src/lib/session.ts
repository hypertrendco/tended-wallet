import 'server-only';
import { cookies } from 'next/headers';
import { redirect } from 'next/navigation';
import { cache } from 'react';
import { auth0 } from './auth0';
import { devLoginEnabled } from './config';
import { one, q } from './db';
import { verify } from './tokens';

export type User = {
  id: string; email: string; name: string | null; phone: string | null;
  is_admin: boolean; status: string; wallet_id: string; balance: number;
};
export type OrgRole = { org_id: string; name: string; kind: 'verifier' | 'provider' | 'both'; status: string; role: 'owner' | 'staff' };

async function identity(): Promise<{ sub: string; email: string; name?: string } | null> {
  const a = auth0();
  if (a) {
    const s = await a.getSession();
    if (!s?.user?.email) return null;
    return { sub: s.user.sub, email: String(s.user.email).toLowerCase(), name: s.user.name as string | undefined };
  }
  if (devLoginEnabled()) {
    const c = (await cookies()).get('dev_session')?.value;
    const v = c ? verify<{ email: string }>(c) : null;
    return v ? { sub: `dev|${v.email}`, email: v.email } : null;
  }
  return null;
}

export const getUser = cache(async (): Promise<User | null> => {
  const id = await identity();
  if (!id) return null;
  const bootstrap = (process.env.BOOTSTRAP_ADMIN_EMAIL || '').toLowerCase().split(',').map((s) => s.trim()).filter(Boolean);
  const isBoot = bootstrap.includes(id.email);
  const u = await one<{ id: string }>(
    `INSERT INTO users (auth_sub, email, name, is_admin) VALUES ($1,$2,$3,$4)
     ON CONFLICT (email) DO UPDATE SET auth_sub = EXCLUDED.auth_sub,
       name = coalesce(users.name, EXCLUDED.name), is_admin = users.is_admin OR $4
     RETURNING id`, [id.sub, id.email, id.name && id.name !== id.email ? id.name : null, isBoot]);
  await q(`INSERT INTO wallets (owner_type, user_id) VALUES ('user',$1) ON CONFLICT (user_id) DO NOTHING`, [u!.id]);
  return one<User>(
    `SELECT u.id, u.email, u.name, u.phone, u.is_admin, u.status, w.id AS wallet_id, w.balance
       FROM users u JOIN wallets w ON w.user_id = u.id WHERE u.id = $1`, [u!.id]);
});

export function loginUrl(next = '/wallet') {
  return auth0() ? `/auth/login?returnTo=${encodeURIComponent(next)}` : `/login?next=${encodeURIComponent(next)}`;
}
export async function requireUser(next?: string): Promise<User> {
  const u = await getUser();
  if (!u) redirect(next ? loginUrl(next) : '/');
  if (u.status !== 'active') redirect('/suspended');
  return u;
}
export async function requireAdmin(): Promise<User> {
  const u = await requireUser();
  if (!u.is_admin) redirect('/wallet');
  return u;
}
export const myOrgs = cache(async (userId: string): Promise<OrgRole[]> =>
  q<OrgRole>(`SELECT o.id AS org_id, o.name, o.kind, o.status, m.role FROM org_members m JOIN orgs o ON o.id = m.org_id
              WHERE m.user_id = $1 ORDER BY o.name`, [userId]));

/** Staff of an active org (admins can act on any org). */
export async function requireOrg(orgId: string, need?: 'provider' | 'verifier', opts: { owner?: boolean } = {}) {
  const user = await requireUser();
  const org = await one<any>(`SELECT o.*, w.id AS wallet_id, w.balance FROM orgs o JOIN wallets w ON w.org_id = o.id WHERE o.id = $1`, [orgId]);
  if (!org) redirect('/orgs');
  const m = await one<{ role: string }>(`SELECT role FROM org_members WHERE org_id=$1 AND user_id=$2`, [orgId, user.id]);
  if (!m && !user.is_admin) redirect('/orgs');
  if (opts.owner && m?.role !== 'owner' && !user.is_admin) throw new Error('Only org owners can do that');
  if (need && org.kind !== need && org.kind !== 'both') throw new Error(`This organization is not a ${need}`);
  return { user, org, role: m?.role ?? 'admin' };
}

export async function audit(actorId: string | null, action: string, detail: object = {}) {
  await q(`INSERT INTO audit_log (actor_id, action, detail) VALUES ($1,$2,$3)`, [actorId, action, JSON.stringify(detail)]);
}

export async function settings() {
  return (await one<any>(`SELECT * FROM app_settings WHERE id = 1`))!;
}
