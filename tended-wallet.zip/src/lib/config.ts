export const AUTH0_VARS = ['AUTH0_DOMAIN', 'AUTH0_CLIENT_ID', 'AUTH0_CLIENT_SECRET', 'AUTH0_SECRET'] as const;

export function missingConfig(): string[] {
  const miss: string[] = [];
  if (!process.env.DATABASE_URL) miss.push('DATABASE_URL');
  if (!auth0Configured() && !devLoginEnabled()) miss.push(...AUTH0_VARS.filter((k) => !process.env[k]));
  return miss;
}
export function auth0Configured() {
  return AUTH0_VARS.every((k) => !!process.env[k]);
}
/** Local/demo sign-in by email with no verification. Never enable for real members. */
export function devLoginEnabled() {
  return process.env.DEV_LOGIN === '1' && !auth0Configured();
}
export function appSecret(): string {
  const s = process.env.APP_SECRET || process.env.AUTH0_SECRET;
  if (s) return s;
  if (devLoginEnabled()) return 'dev-only-insecure-secret';
  throw new Error('APP_SECRET (or AUTH0_SECRET) must be set');
}
