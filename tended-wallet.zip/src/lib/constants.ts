export const CARD_PREFIX = 'tended-card:';
