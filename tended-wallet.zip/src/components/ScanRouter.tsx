'use client';
import { useCallback, useState } from 'react';
import { useRouter } from 'next/navigation';
import Scanner from './Scanner';
import { nfcReadOnce, nfcSupported } from './nfc';

export function routeFor(text: string): string | null {
  try {
    const u = new URL(text.trim(), window.location.origin);
    if (/^\/(pay\/r|pay\/o|checkin)\/[\w-]+$/.test(u.pathname)) return u.pathname;
  } catch {}
  return null;
}

export default function ScanRouter() {
  const router = useRouter();
  const [msg, setMsg] = useState<string | null>(null);
  const [key, setKey] = useState(0);
  const [nfcBusy, setNfcBusy] = useState(false);

  const handle = useCallback((text: string) => {
    const path = routeFor(text);
    if (path) { router.push(path); return; }
    if (text.startsWith('TENDED:PAY:')) setMsg('That is a member’s pay code. Providers scan those from their organization’s checkout screen.');
    else setMsg('That code isn’t a Tended payment or check-in code.');
  }, [router]);

  async function tapNfc() {
    setMsg(null); setNfcBusy(true);
    try { const r = await nfcReadOnce(); handle(r.url || r.text || ''); }
    catch (e: any) { setMsg(e?.message || 'NFC read failed'); }
    finally { setNfcBusy(false); }
  }

  return (
    <div className="space-y-4">
      <Scanner key={key} onScan={handle} />
      {msg && <div className="card text-sm" role="alert">{msg} <button className="btn-ghost ml-1 px-2 py-1" onClick={() => { setMsg(null); setKey((k) => k + 1); }}>Scan again</button></div>}
      <div className="grid gap-2 sm:grid-cols-2">
        {nfcSupported() ? (
          <button className="btn-secondary" onClick={tapNfc} disabled={nfcBusy}>{nfcBusy ? 'Hold phone to the tag…' : 'Tap an NFC tag instead'}</button>
        ) : (
          <p className="muted text-center sm:col-span-2">To pay at an NFC sticker, just hold your phone near it — it opens the payment page.</p>
        )}
      </div>
    </div>
  );
}
