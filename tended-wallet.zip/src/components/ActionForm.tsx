'use client';
import { useActionState, useEffect, useRef } from 'react';

export type ActionResult = { ok?: string; error?: string; data?: any } | null;
type Props = {
  action: (prev: ActionResult, fd: FormData) => Promise<ActionResult>;
  children: React.ReactNode;
  className?: string;
  resetOnOk?: boolean;
  onResult?: (r: ActionResult) => void;
};

export default function ActionForm({ action, children, className, resetOnOk, onResult }: Props) {
  const [state, run, pending] = useActionState(action, null);
  const ref = useRef<HTMLFormElement>(null);
  useEffect(() => {
    if (state?.ok && resetOnOk) ref.current?.reset();
    if (state) onResult?.(state);
  }, [state]); // eslint-disable-line react-hooks/exhaustive-deps
  return (
    <form ref={ref} action={run} className={className}>
      <fieldset disabled={pending} className="contents">{children}</fieldset>
      {state?.error && <p role="alert" className="mt-2 text-sm text-red-700 w-full">{state.error}</p>}
      {state?.ok && <p role="status" className="mt-2 text-sm text-brand-700 w-full">{state.ok}</p>}
    </form>
  );
}
