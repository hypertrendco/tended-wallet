'use client';
import Link from 'next/link';
import { usePathname } from 'next/navigation';
export default function SubNav({ items }: { items: { href: string; label: string; badge?: number }[] }) {
  const path = usePathname();
  return (
    <nav className="-mx-4 overflow-x-auto px-4"><ul className="flex gap-1 border-b border-black/10">
      {items.map((i) => {
        const on = path === i.href;
        return <li key={i.href}><Link href={i.href} className={`block whitespace-nowrap border-b-2 px-3 py-2 text-sm font-medium ${on ? 'border-brand-600 text-brand-700' : 'border-transparent text-black/55 hover:text-black'}`}>
          {i.label}{i.badge ? <span className="badge ml-1.5 bg-sun-400 text-black">{i.badge}</span> : null}</Link></li>;
      })}
    </ul></nav>
  );
}
