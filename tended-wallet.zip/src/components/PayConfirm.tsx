'use client';
import { useActionState } from 'react';
import Link from 'next/link';
import type { ActionResult } from './ActionForm';

export default function PayConfirm({ action, hidden, label, disabled }: {
  action: (p: ActionResult, fd: FormData) => Promise<ActionResult>;
  hidden: Record<string, string>; label: string; disabled?: boolean; children?: React.ReactNode;
}) {
  const [state, run, pending] = useActionState(action, null);
  if (state?.ok) return (
    <div className="text-center py-4" role="status">
      <div className="mx-auto grid h-16 w-16 place-items-center rounded-full bg-brand-600 text-3xl text-white">✓</div>
      <p className="mt-3 text-xl font-bold">{state.ok}</p>
      <Link href="/wallet" className="btn-secondary mt-5">Back to wallet</Link>
    </div>
  );
  return (
    <form action={run}>
      {Object.entries(hidden).map(([k, v]) => <input key={k} type="hidden" name={k} value={v} />)}
      <button className="btn-primary w-full py-3.5 text-base" disabled={pending || disabled}>{pending ? 'Paying…' : label}</button>
      {state?.error && <p role="alert" className="mt-2 text-sm text-red-700">{state.error}</p>}
    </form>
  );
}
