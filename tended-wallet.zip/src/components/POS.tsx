'use client';
import { useEffect, useMemo, useState } from 'react';
import { useRouter } from 'next/navigation';
import type { ActionResult } from './ActionForm';
import { fmt } from '@/lib/money';
import QR from './QR';
import Scanner from './Scanner';
import { nfcReadOnce, nfcSupported } from './nfc';

type Act = (p: ActionResult, fd: FormData) => Promise<ActionResult>;
type Item = { id: string; name: string; price: number };
type Mode = null | 'qr' | 'code' | 'card';

export default function POS({ orgId, items, cardLimit, actions }: {
  orgId: string; items: Item[]; cardLimit: number;
  actions: { create: Act; cancel: Act; payCode: Act; card: Act };
}) {
  const router = useRouter();
  const [amt, setAmt] = useState('');
  const [memo, setMemo] = useState('');
  const [sel, setSel] = useState<string[]>([]);
  const [mode, setMode] = useState<Mode>(null);
  const [req, setReq] = useState<{ id: string } | null>(null);
  const [reqStatus, setReqStatus] = useState<string>('open');
  const [paidBy, setPaidBy] = useState<string | null>(null);
  const [cardToken, setCardToken] = useState<string | null>(null);
  const [pin, setPin] = useState('');
  const [busy, setBusy] = useState(false);
  const [msg, setMsg] = useState<{ ok?: string; error?: string } | null>(null);
  const [nfc, setNfc] = useState(false);
  useEffect(() => setNfc(nfcSupported()), []);

  const total = useMemo(() => sel.length ? items.filter((i) => sel.includes(i.id)).reduce((a, i) => a + i.price, 0) : Math.round(Number(amt || 0) * 100), [sel, amt, items]);

  function fd(extra: Record<string, string> = {}) {
    const f = new FormData();
    f.set('org_id', orgId); f.set('memo', memo);
    if (sel.length) sel.forEach((i) => f.append('item', i)); else f.set('amount', amt);
    Object.entries(extra).forEach(([k, v]) => f.set(k, v));
    return f;
  }
  function reset(keepMsg = false) {
    setMode(null); setReq(null); setReqStatus('open'); setPaidBy(null); setCardToken(null); setPin('');
    setAmt(''); setMemo(''); setSel([]); if (!keepMsg) setMsg(null);
  }
  function done(r: ActionResult) {
    if (r?.ok) { setMsg({ ok: r.ok }); navigator.vibrate?.([80, 40, 80]); reset(true); router.refresh(); }
    else setMsg({ error: r?.error || 'Failed' });
  }

  // QR charge
  async function startQr() {
    setBusy(true); setMsg(null);
    const r = await actions.create(null, fd());
    setBusy(false);
    if (r?.error) { setMsg({ error: r.error }); return; }
    setReq(r!.data); setMode('qr');
  }
  useEffect(() => {
    if (mode !== 'qr' || !req) return;
    const t = setInterval(async () => {
      const j = await fetch(`/api/requests/${req.id}`).then((r) => r.json()).catch(() => null);
      if (!j) return;
      setReqStatus(j.status);
      if (j.status === 'paid') { setPaidBy(j.paid_by); navigator.vibrate?.([80, 40, 80]); clearInterval(t); router.refresh(); }
      if (j.status !== 'open') clearInterval(t);
    }, 1500);
    return () => clearInterval(t);
  }, [mode, req, router]);

  // Member pay code
  async function onCode(text: string) {
    setBusy(true);
    done(await actions.payCode(null, fd({ token: text })));
    setBusy(false);
  }

  // NFC card
  async function readCard() {
    setMsg(null); setMode('card'); setCardToken(null);
    try {
      const r = await nfcReadOnce();
      if (!r.text?.startsWith('tended-card:')) throw new Error('That tag is not a Tended card.');
      setCardToken(r.text); navigator.vibrate?.(60);
    } catch (e: any) { setMsg({ error: e?.message || 'Could not read card' }); setMode(null); }
  }
  async function chargeCard() {
    setBusy(true);
    const r = await actions.card(null, fd({ card_token: cardToken!, pin }));
    setBusy(false);
    if (r?.ok) done(r); else { setMsg({ error: r?.error }); setPin(''); }
  }

  if (mode === 'qr' && req) return (
    <div className="card flex flex-col items-center gap-3 py-6 text-center">
      {reqStatus === 'paid' ? (<>
        <div className="grid h-16 w-16 place-items-center rounded-full bg-brand-600 text-3xl text-white">✓</div>
        <p className="text-2xl font-bold" role="status">Paid {fmt(total)} credits</p>
        <p className="muted">by {paidBy}</p>
        <button className="btn-primary" onClick={() => reset()}>New sale</button>
      </>) : (<>
        <p className="text-3xl font-bold">{fmt(total)} credits</p>
        {reqStatus === 'open' ? <QR value={`${location.origin}/pay/r/${req.id}`} size={260} /> : <p className="text-red-700">Request {reqStatus}.</p>}
        <p className="muted">Member scans with their phone camera or the Tended app. Waiting…</p>
        <button className="btn-ghost" onClick={async () => { await actions.cancel(null, fd({ request_id: req.id })); reset(); }}>Cancel</button>
      </>)}
    </div>
  );

  return (
    <div className="space-y-4">
      {msg?.ok && <div className="card border-brand-200 bg-brand-50 text-brand-700 font-semibold" role="status">✓ {msg.ok}</div>}
      {msg?.error && <div className="card border-red-100 bg-red-50 text-red-700" role="alert">{msg.error}</div>}
      <div className="card space-y-3">
        {items.length > 0 && (
          <div className="flex flex-wrap gap-2">
            {items.map((i) => (
              <button key={i.id} type="button" onClick={() => setSel((s) => s.includes(i.id) ? s.filter((x) => x !== i.id) : [...s, i.id])}
                className={`rounded-xl border px-3 py-2 text-sm ${sel.includes(i.id) ? 'border-brand-600 bg-brand-600 text-white' : 'border-black/10 bg-white'}`}>
                {i.name} · {fmt(i.price)}
              </button>
            ))}
          </div>
        )}
        {!sel.length && (
          <div className="grid gap-2 sm:grid-cols-2">
            <div><label className="label" htmlFor="pos-amt">Amount (credits)</label><input id="pos-amt" className="input text-2xl" inputMode="decimal" value={amt} onChange={(e) => setAmt(e.target.value.replace(/[^\d.]/g, ''))} placeholder="0" /></div>
            <div><label className="label" htmlFor="pos-memo">Description</label><input id="pos-memo" className="input" value={memo} onChange={(e) => setMemo(e.target.value)} placeholder="e.g. Flu shot" /></div>
          </div>
        )}
        <p className="text-right text-lg">Total <b className="tabular-nums">{fmt(total)}</b> credits</p>
      </div>
      {mode === 'code' ? (
        <div className="space-y-2">
          <p className="muted text-center">Scan the member’s pay code</p>
          {busy ? <p className="text-center">Charging…</p> : <Scanner onScan={onCode} />}
          <button className="btn-ghost w-full" onClick={() => setMode(null)}>Cancel</button>
        </div>
      ) : mode === 'card' ? (
        <div className="card space-y-3 text-center">
          {!cardToken ? <p>Hold the member’s card to the back of this phone…</p> : (<>
            <p className="font-semibold">Card read ✓ — hand the device to the member</p>
            <input className="input mx-auto max-w-40 text-center text-2xl tracking-[0.5em]" type="password" inputMode="numeric" maxLength={6} placeholder="PIN" autoFocus value={pin} onChange={(e) => setPin(e.target.value.replace(/\D/g, ''))} aria-label="Member PIN" />
            <button className="btn-primary w-full" disabled={busy || pin.length < 4} onClick={chargeCard}>{busy ? 'Charging…' : `Charge ${fmt(total)} credits`}</button>
          </>)}
          <button className="btn-ghost" onClick={() => { setMode(null); setCardToken(null); }}>Cancel</button>
        </div>
      ) : (
        <div className="grid gap-2 sm:grid-cols-3">
          <button className="btn-primary py-4" disabled={total <= 0 || busy} onClick={startQr}>Show QR to member</button>
          <button className="btn-secondary py-4" disabled={total <= 0} onClick={() => { setMsg(null); setMode('code'); }}>Scan member’s code</button>
          <button className="btn-secondary py-4" disabled={total <= 0 || !nfc || total > cardLimit} onClick={readCard}
            title={!nfc ? 'NFC needs Chrome on Android' : undefined}>
            Tap NFC card{!nfc ? ' (Android)' : total > cardLimit ? ` (max ${cardLimit / 100})` : ''}
          </button>
        </div>
      )}
    </div>
  );
}
