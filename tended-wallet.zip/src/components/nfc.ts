'use client';
// Web NFC (Chrome on Android). iPhones cannot read/write NFC from the browser, but they
// DO open URL stickers natively, so provider stickers work for everyone.
export const nfcSupported = () => typeof window !== 'undefined' && 'NDEFReader' in window;

export async function nfcReadOnce(signal?: AbortSignal): Promise<{ url?: string; text?: string; serial?: string }> {
  const R = (window as any).NDEFReader;
  const reader = new R();
  const ctrl = new AbortController();
  signal?.addEventListener('abort', () => ctrl.abort());
  await reader.scan({ signal: ctrl.signal });
  return new Promise((resolve, reject) => {
    reader.onreadingerror = () => reject(new Error('Could not read that tag. Try again.'));
    reader.onreading = (ev: any) => {
      const out: { url?: string; text?: string; serial?: string } = { serial: ev.serialNumber };
      for (const rec of ev.message.records) {
        const dec = new TextDecoder(rec.encoding || 'utf-8');
        if (rec.recordType === 'url' || rec.recordType === 'absolute-url') out.url = dec.decode(rec.data);
        else if (rec.recordType === 'text') out.text = dec.decode(rec.data);
      }
      ctrl.abort();
      resolve(out);
    };
  });
}

export async function nfcWrite(record: { url?: string; text?: string }) {
  const R = (window as any).NDEFReader;
  const w = new R();
  const records = [] as any[];
  if (record.url) records.push({ recordType: 'url', data: record.url });
  if (record.text) records.push({ recordType: 'text', data: record.text });
  await w.write({ records }, { overwrite: true });
}

export { CARD_PREFIX } from '@/lib/constants';
