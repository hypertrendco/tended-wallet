'use client';
import { useEffect, useState } from 'react';
import QR from './QR';

/** QR for an in-app path with a printable poster. */
export default function PrintQR({ url, title, subtitle, size = 180 }: { url: string; title: string; subtitle: string; size?: number }) {
  const [full, setFull] = useState('');
  useEffect(() => setFull(new URL(url, location.origin).toString()), [url]);
  if (!full) return null;
  function print() {
    const img = document.querySelector<HTMLImageElement>(`img[data-qr="${CSS.escape(full)}"]`)?.src;
    const w = window.open('', '_blank', 'width=600,height=800');
    if (!w || !img) return;
    w.document.write(`<!doctype html><title>${title}</title><body style="font-family:system-ui;text-align:center;padding:40px">
      <h1 style="margin:0 0 4px">${title.replace(/</g, '&lt;')}</h1><p style="font-size:20px;margin:0 0 24px;color:#444">${subtitle.replace(/</g, '&lt;')}</p>
      <img src="${img}" style="width:380px;height:380px"/><p style="color:#666;font-size:12px;word-break:break-all">${full}</p>
      <script>onload=()=>setTimeout(()=>print(),200)</script></body>`);
    w.document.close();
  }
  return (
    <div className="flex flex-wrap items-center gap-4">
      <QR value={full} size={size} className="rounded-lg border border-black/10" />
      <div className="space-y-2">
        <button type="button" className="btn-secondary" onClick={print}>Print poster</button>
        <p className="muted max-w-48 break-all text-xs">{full}</p>
      </div>
    </div>
  );
}
