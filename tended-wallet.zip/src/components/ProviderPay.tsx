'use client';
import { useActionState, useMemo, useState } from 'react';
import Link from 'next/link';
import type { ActionResult } from './ActionForm';
import { fmt } from '@/lib/money';

type Item = { id: string; name: string; description: string | null; price: number; category: string };
export default function ProviderPay({ action, orgId, items, balance, via }: {
  action: (p: ActionResult, fd: FormData) => Promise<ActionResult>; orgId: string; items: Item[]; balance: number; via: string;
}) {
  const [state, run, pending] = useActionState(action, null);
  const [sel, setSel] = useState<string[]>([]);
  const [amt, setAmt] = useState('');
  const total = useMemo(() => sel.length ? items.filter((i) => sel.includes(i.id)).reduce((a, i) => a + i.price, 0) : Math.round(Number(amt || 0) * 100), [sel, amt, items]);
  if (state?.ok) return (
    <div className="card text-center py-8" role="status">
      <div className="mx-auto grid h-16 w-16 place-items-center rounded-full bg-brand-600 text-3xl text-white">✓</div>
      <p className="mt-3 text-xl font-bold">{state.ok}</p>
      <p className="muted mt-1">Show this screen to the provider.</p>
      <Link href="/wallet" className="btn-secondary mt-5">Back to wallet</Link>
    </div>
  );
  return (
    <form action={run} className="space-y-4">
      <input type="hidden" name="org_id" value={orgId} />
      <input type="hidden" name="via" value={via} />
      {items.length > 0 && (
        <div className="card">
          <h2 className="h2 mb-2">Choose services or products</h2>
          <ul className="divide-y divide-black/5">
            {items.map((i) => (
              <li key={i.id}>
                <label className="flex cursor-pointer items-center gap-3 py-2.5">
                  <input type="checkbox" name="item" value={i.id} className="h-5 w-5 accent-brand-600" checked={sel.includes(i.id)}
                    onChange={(e) => setSel((s) => e.target.checked ? [...s, i.id] : s.filter((x) => x !== i.id))} />
                  <span className="flex-1"><span className="font-medium">{i.name}</span>{i.description && <span className="muted block">{i.description}</span>}</span>
                  <span className="font-semibold tabular-nums">{fmt(i.price)}</span>
                </label>
              </li>
            ))}
          </ul>
        </div>
      )}
      {!sel.length && (
        <div className="card">
          <label className="label" htmlFor="amount">{items.length ? 'Or enter an amount' : 'Amount (credits)'}</label>
          <input id="amount" name="amount" inputMode="decimal" className="input text-2xl" placeholder="0" value={amt} onChange={(e) => setAmt(e.target.value.replace(/[^\d.]/g, ''))} />
          <label className="label mt-3" htmlFor="memo">What’s it for? (optional)</label>
          <input id="memo" name="memo" className="input" maxLength={200} />
        </div>
      )}
      <p className="muted text-center">Balance {fmt(balance)} credits</p>
      <button className="btn-primary w-full py-3.5 text-base" disabled={pending || total <= 0 || total > balance}>
        {pending ? 'Paying…' : total > balance ? 'Not enough credits' : `Pay ${total ? fmt(total) : ''} credits`}
      </button>
      {state?.error && <p role="alert" className="text-sm text-red-700">{state.error}</p>}
    </form>
  );
}
