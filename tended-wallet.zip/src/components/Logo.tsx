export default function Logo({ className = 'h-7 w-7' }: { className?: string }) {
  return <img src="/icon.svg" alt="" className={className} />;
}
