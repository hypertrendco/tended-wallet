'use client';
import Link from 'next/link';
import { usePathname } from 'next/navigation';

const I = {
  wallet: 'M3 7h15a3 3 0 0 1 3 3v7a3 3 0 0 1-3 3H6a3 3 0 0 1-3-3V7zm0 0V6a2 2 0 0 1 2-2h11M16 13.5h.01',
  earn: 'M12 21s-7-4.4-7-10a4 4 0 0 1 7-2.6A4 4 0 0 1 19 11c0 5.6-7 10-7 10z',
  scan: 'M4 8V5a1 1 0 0 1 1-1h3M16 4h3a1 1 0 0 1 1 1v3M20 16v3a1 1 0 0 1-1 1h-3M8 20H5a1 1 0 0 1-1-1v-3M7 12h10',
  market: 'M4 9l1.5-5h13L20 9M4 9h16M4 9v10a1 1 0 0 0 1 1h14a1 1 0 0 0 1-1V9M9 13h6',
  orgs: 'M4 21V8l8-5 8 5v13M9 21v-6h6v6',
};
function Icon({ d }: { d: string }) {
  return <svg viewBox="0 0 24 24" className="h-6 w-6" fill="none" stroke="currentColor" strokeWidth={1.8} strokeLinecap="round" strokeLinejoin="round"><path d={d} /></svg>;
}
const items = [
  { href: '/wallet', label: 'Wallet', icon: I.wallet },
  { href: '/earn', label: 'Earn', icon: I.earn },
  { href: '/scan', label: 'Scan', icon: I.scan, main: true },
  { href: '/market', label: 'Redeem', icon: I.market },
  { href: '/orgs', label: 'Orgs', icon: I.orgs },
];

export default function Nav() {
  const path = usePathname();
  return (
    <nav className="fixed inset-x-0 bottom-0 z-30 border-t border-black/10 bg-white/95 backdrop-blur pb-[env(safe-area-inset-bottom)] md:static md:border-0 md:bg-transparent md:pb-0">
      <ul className="mx-auto flex max-w-md justify-around md:max-w-none md:justify-start md:gap-1">
        {items.map((it) => {
          const on = path === it.href || path.startsWith(it.href + '/');
          return (
            <li key={it.href}>
              <Link href={it.href} className={`flex flex-col items-center px-3 py-2 text-[11px] font-medium md:flex-row md:gap-2 md:rounded-lg md:text-sm ${on ? 'text-brand-700 md:bg-brand-50' : 'text-black/50 hover:text-black'}`}>
                {it.main ? <span className="-mt-5 grid h-12 w-12 place-items-center rounded-full bg-brand-600 text-white shadow-lg md:mt-0 md:h-auto md:w-auto md:bg-transparent md:text-inherit md:shadow-none"><Icon d={it.icon} /></span> : <Icon d={it.icon} />}
                <span>{it.label}</span>
              </Link>
            </li>
          );
        })}
      </ul>
    </nav>
  );
}
