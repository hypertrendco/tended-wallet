'use client';
import { useCallback, useEffect, useState } from 'react';
import { useRouter } from 'next/navigation';
import QR from './QR';

export default function PayCode() {
  const router = useRouter();
  const [code, setCode] = useState<{ code: string; expires_at: string; nonce: string } | null>(null);
  const [left, setLeft] = useState(0);
  const [max, setMax] = useState('');
  const [paid, setPaid] = useState<{ amount: number; memo: string } | null>(null);
  const [err, setErr] = useState<string | null>(null);

  const refresh = useCallback(async () => {
    setErr(null); setPaid(null);
    const r = await fetch('/api/paycode', { method: 'POST', headers: { 'content-type': 'application/json' }, body: JSON.stringify({ max: max || null }) });
    const j = await r.json();
    if (!r.ok) { setErr(j.error || 'Could not create a code'); return; }
    setCode(j);
  }, [max]);

  useEffect(() => { refresh(); }, []); // eslint-disable-line react-hooks/exhaustive-deps

  useEffect(() => {
    if (!code || paid) return;
    const t = setInterval(() => {
      const s = Math.max(0, Math.round((new Date(code.expires_at).getTime() - Date.now()) / 1000));
      setLeft(s);
      if (s === 0 && document.visibilityState === 'visible') refresh();
    }, 500);
    const p = setInterval(async () => {
      const r = await fetch(`/api/paycode?n=${encodeURIComponent(code.nonce)}`).then((r) => r.json()).catch(() => null);
      if (r?.used) { setPaid({ amount: r.amount, memo: r.memo }); navigator.vibrate?.([80, 40, 80]); router.refresh(); }
    }, 2000);
    return () => { clearInterval(t); clearInterval(p); };
  }, [code, paid, refresh, router]);

  if (paid) return (
    <div className="card text-center py-10" role="status">
      <div className="mx-auto grid h-16 w-16 place-items-center rounded-full bg-brand-600 text-3xl text-white">✓</div>
      <p className="mt-4 text-2xl font-bold">Paid {paid.amount / 100} credits</p>
      <p className="muted">{paid.memo}</p>
      <button className="btn-secondary mt-6" onClick={refresh}>New code</button>
    </div>
  );
  return (
    <div className="card flex flex-col items-center gap-4 py-6">
      {err && <p className="text-sm text-red-700">{err}</p>}
      {code ? <QR value={code.code} size={260} /> : <div className="h-[260px] w-[260px] animate-pulse rounded-xl bg-black/5" />}
      <p className="muted" aria-live="polite">{left > 0 ? `Refreshes in ${left}s · single use` : 'Refreshing…'}</p>
      <details className="w-full max-w-xs text-sm">
        <summary className="cursor-pointer text-brand-700 font-medium">Set a spending limit for this code</summary>
        <div className="mt-2 flex gap-2">
          <input className="input" inputMode="decimal" placeholder="e.g. 10" value={max} onChange={(e) => setMax(e.target.value.replace(/[^\d.]/g, ''))} />
          <button className="btn-secondary" onClick={refresh}>Apply</button>
        </div>
      </details>
    </div>
  );
}
