'use client';
import { useState } from 'react';
import ActionForm, { type ActionResult } from './ActionForm';
import NfcWriteButton from './NfcWriteButton';
import Submit from './Submit';
import { CARD_PREFIX } from './nfc';

export default function NewCard({ action }: { action: (p: ActionResult, fd: FormData) => Promise<ActionResult> }) {
  const [token, setToken] = useState<string | null>(null);
  if (token) return (
    <div className="space-y-2">
      <p className="text-sm text-brand-700">Card created. Now write it to a blank NFC card, sticker, or key fob (NTAG213/215/216).</p>
      <NfcWriteButton text={CARD_PREFIX + token} label="Write card to NFC tag" className="btn-primary" />
      <button className="btn-ghost" onClick={() => setToken(null)}>Done</button>
    </div>
  );
  return (
    <ActionForm action={action} resetOnOk onResult={(r) => r?.data?.token && setToken(r.data.token)} className="grid gap-3 sm:grid-cols-3">
      <div><label className="label" htmlFor="label">Card name</label><input id="label" name="label" className="input" placeholder="Keychain" maxLength={40} /></div>
      <div><label className="label" htmlFor="pin">PIN (4–6 digits)</label><input id="pin" name="pin" className="input" inputMode="numeric" type="password" pattern="\d{4,6}" required /></div>
      <div><label className="label" htmlFor="pin2">Confirm PIN</label><input id="pin2" name="pin2" className="input" inputMode="numeric" type="password" pattern="\d{4,6}" required /></div>
      <div className="sm:col-span-3"><Submit>Create card</Submit></div>
    </ActionForm>
  );
}
