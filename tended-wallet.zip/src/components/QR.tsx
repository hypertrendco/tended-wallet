'use client';
import QRCode from 'qrcode';
import { useEffect, useState } from 'react';

export default function QR({ value, size = 240, className }: { value: string; size?: number; className?: string }) {
  const [src, setSrc] = useState<string>('');
  useEffect(() => {
    QRCode.toDataURL(value, { width: size * 2, margin: 1, errorCorrectionLevel: 'M', color: { dark: '#0e3322', light: '#ffffff' } })
      .then(setSrc).catch(() => setSrc(''));
  }, [value, size]);
  return src ? <img src={src} width={size} height={size} alt="QR code" className={className} data-qr={value} />
             : <div style={{ width: size, height: size }} className="animate-pulse bg-black/5 rounded-xl" />;
}
