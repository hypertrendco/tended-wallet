'use client';
import { useEffect, useState } from 'react';
import { nfcSupported, nfcWrite } from './nfc';

export default function NfcWriteButton({ url, text, label = 'Write to NFC tag', className = 'btn-secondary' }: { url?: string; text?: string; label?: string; className?: string }) {
  const [ok, setOk] = useState<boolean | null>(null);
  const [msg, setMsg] = useState<string | null>(null);
  const [busy, setBusy] = useState(false);
  useEffect(() => setOk(nfcSupported()), []);
  if (ok === null) return null;
  if (!ok) return <p className="muted text-xs">NFC writing needs Chrome on an Android phone. Open this page there to write tags.</p>;
  return (
    <span className="inline-flex flex-col gap-1">
      <button type="button" className={className} disabled={busy} onClick={async () => {
        setBusy(true); setMsg('Hold a blank NFC tag to the back of your phone…');
        try { await nfcWrite({ url: url ? new URL(url, location.origin).toString() : undefined, text }); setMsg('Written ✓'); }
        catch (e: any) { setMsg(e?.name === 'NotAllowedError' ? 'NFC permission denied.' : e?.message || 'Write failed'); }
        finally { setBusy(false); }
      }}>{busy ? 'Waiting for tag…' : label}</button>
      {msg && <span className="text-xs text-black/60" role="status">{msg}</span>}
    </span>
  );
}
