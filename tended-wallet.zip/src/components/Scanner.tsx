'use client';
import jsQR from 'jsqr';
import { useEffect, useRef, useState } from 'react';

/** Camera QR scanner. Uses native BarcodeDetector when present, jsQR otherwise. */
export default function Scanner({ onScan, active = true }: { onScan: (text: string) => void; active?: boolean }) {
  const video = useRef<HTMLVideoElement>(null);
  const canvas = useRef<HTMLCanvasElement>(null);
  const [err, setErr] = useState<string | null>(null);
  const done = useRef(false);

  useEffect(() => {
    if (!active) return;
    done.current = false;
    let stream: MediaStream | null = null;
    let raf = 0;
    let detector: any = null;
    const W: any = window;
    (async () => {
      try {
        stream = await navigator.mediaDevices.getUserMedia({ video: { facingMode: 'environment' }, audio: false });
        const v = video.current!;
        v.srcObject = stream;
        await v.play();
        if (W.BarcodeDetector) {
          try { detector = new W.BarcodeDetector({ formats: ['qr_code'] }); } catch { detector = null; }
        }
        const tick = async () => {
          if (done.current) return;
          if (v.readyState >= 2) {
            let text: string | null = null;
            if (detector) {
              try { const r = await detector.detect(v); text = r[0]?.rawValue ?? null; } catch { detector = null; }
            } else {
              const c = canvas.current!;
              const w = Math.min(v.videoWidth, 640), h = Math.round((v.videoHeight / v.videoWidth) * w);
              c.width = w; c.height = h;
              const ctx = c.getContext('2d', { willReadFrequently: true })!;
              ctx.drawImage(v, 0, 0, w, h);
              const img = ctx.getImageData(0, 0, w, h);
              text = jsQR(img.data, w, h, { inversionAttempts: 'dontInvert' })?.data ?? null;
            }
            if (text) { done.current = true; navigator.vibrate?.(60); onScan(text); return; }
          }
          raf = requestAnimationFrame(tick);
        };
        raf = requestAnimationFrame(tick);
      } catch (e: any) {
        setErr(e?.name === 'NotAllowedError' ? 'Camera permission was denied. Allow camera access in your browser settings.' : 'Camera is unavailable on this device.');
      }
    })();
    return () => { done.current = true; cancelAnimationFrame(raf); stream?.getTracks().forEach((t) => t.stop()); };
  }, [active, onScan]);

  if (err) return <div className="card text-sm text-red-700">{err}</div>;
  return (
    <div className="relative overflow-hidden rounded-2xl bg-black aspect-square w-full max-w-sm mx-auto">
      <video ref={video} playsInline muted className="h-full w-full object-cover" />
      <canvas ref={canvas} className="hidden" />
      <div className="pointer-events-none absolute inset-10 rounded-2xl border-4 border-white/80" />
    </div>
  );
}
