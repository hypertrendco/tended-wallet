import { dt } from '@/lib/time';
import type { Activity } from '@/lib/queries';
import { fmt } from '@/lib/money';

const LABEL: Record<string, string> = { mint: 'Earned', payment: 'Payment', transfer: 'Gift', reversal: 'Reversal', retire: 'Settlement', adjustment: 'Adjustment' };
const METHOD: Record<string, string> = { qr_request: 'QR', pay_code: 'Pay code', nfc_card: 'NFC card', nfc_tag: 'NFC tag', qr_static: 'QR', market: 'Online', claim: 'Service hours', manual: '', settlement: '', direct: '' };

export default function ActivityList({ items, empty = 'No activity yet.' }: { items: Activity[]; empty?: string }) {
  if (!items.length) return <p className="muted py-6 text-center">{empty}</p>;
  return (
    <ul className="divide-y divide-black/5">
      {items.map((a) => (
        <li key={a.id + a.amount} className="flex items-center gap-3 py-3">
          <span className={`grid h-9 w-9 shrink-0 place-items-center rounded-full text-sm font-bold ${a.amount > 0 ? 'bg-brand-50 text-brand-700' : 'bg-black/5 text-black/60'}`}>{a.amount > 0 ? '+' : '−'}</span>
          <div className="min-w-0 flex-1">
            <p className="truncate font-medium">{a.memo || a.party}</p>
            <p className="muted truncate text-xs">
              {LABEL[a.kind]}{METHOD[a.method] ? ` · ${METHOD[a.method]}` : ''} · {a.party} · {dt(a.created_at, { month: 'short', day: 'numeric', hour: 'numeric', minute: '2-digit' })}
              {a.reversed && <span className="badge ml-1 bg-red-50 text-red-700">reversed</span>}
            </p>
          </div>
          <span className={`font-semibold tabular-nums ${a.amount > 0 ? 'text-brand-700' : ''}`}>{a.amount > 0 ? '+' : '−'}{fmt(Math.abs(a.amount))}</span>
        </li>
      ))}
    </ul>
  );
}
