'use client';
import { useFormStatus } from 'react-dom';
export default function Submit({ children, className = 'btn-primary', name, value }: { children: React.ReactNode; className?: string; name?: string; value?: string }) {
  const { pending } = useFormStatus();
  return <button type="submit" name={name} value={value} className={className} disabled={pending}>{pending ? 'Working…' : children}</button>;
}
