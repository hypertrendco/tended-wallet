// Ledger integrity tests against a real Postgres. Run: TEST_DATABASE_URL=postgres://... npm test
import { test, before, after } from 'node:test';
import assert from 'node:assert/strict';
import pg from 'pg';
import fs from 'node:fs';

const url = process.env.TEST_DATABASE_URL;
if (!url) { test('skipped: set TEST_DATABASE_URL', () => {}); }
else {
  const admin = new pg.Client({ connectionString: url });
  const db = `tended_test_${Date.now()}`;
  let pool;
  const q = async (sql, p = []) => (await pool.query(sql, p)).rows;
  const one = async (sql, p) => (await q(sql, p))[0];
  const err = async (fn, code) => { await assert.rejects(fn, (e) => { assert.match(e.message, new RegExp(code)); return true; }); };

  let alice, bob, coord, org, prov, aliceW, provW, atId;
  before(async () => {
    await admin.connect();
    await admin.query(`CREATE DATABASE ${db}`);
    pool = new pg.Pool({ connectionString: url.replace(/\/[^/]*$/, '/' + db), max: 25 });
    for (const f of fs.readdirSync('sql').sort()) await pool.query(fs.readFileSync('sql/' + f, 'utf8'));
    const mk = async (email) => { const u = await one(`INSERT INTO users(email) VALUES ($1) RETURNING id`, [email]); await q(`INSERT INTO wallets(owner_type,user_id) VALUES ('user',$1)`, [u.id]); return u.id; };
    alice = await mk('alice@x.org'); bob = await mk('bob@x.org'); coord = await mk('coord@x.org');
    org = (await one(`INSERT INTO orgs(name,kind,status) VALUES ('Pantry','verifier','active') RETURNING id`)).id;
    prov = (await one(`INSERT INTO orgs(name,kind,status) VALUES ('Clinic','provider','active') RETURNING id`)).id;
    await q(`INSERT INTO wallets(owner_type,org_id) VALUES ('org',$1),('org',$2)`, [org, prov]);
    aliceW = (await one(`SELECT id FROM wallets WHERE user_id=$1`, [alice])).id;
    provW = (await one(`SELECT id FROM wallets WHERE org_id=$1`, [prov])).id;
    atId = (await one(`SELECT id FROM activity_types WHERE multiplier=1.5`)).id;
  });
  after(async () => { await pool?.end(); await admin.query(`DROP DATABASE IF EXISTS ${db}`); await admin.end(); });

  const claim = async (user, minutes) => (await one(`INSERT INTO hour_claims(user_id,org_id,activity_type_id,minutes) VALUES ($1,$2,$3,$4) RETURNING id`, [user, org, atId, minutes])).id;
  const bal = async (w) => (await one(`SELECT balance FROM wallets WHERE id=$1`, [w])).balance;

  test('approve_claim mints hours × base × multiplier', async () => {
    const c = await claim(alice, 90);
    await one(`SELECT approve_claim($1,$2)`, [c, coord]);
    const r = await one(`SELECT status, credits FROM hour_claims WHERE id=$1`, [c]);
    assert.equal(r.status, 'approved');
    assert.equal(Number(r.credits), 225); // 1.5h × 1.00 × 1.5 = 2.25 credits
    assert.equal(Number(await bal(aliceW)), 225);
  });

  test('claims cannot be approved twice or by the claimant', async () => {
    const c = await claim(alice, 60);
    await err(() => one(`SELECT approve_claim($1,$2)`, [c, alice]), 'SELF_APPROVAL');
    await one(`SELECT approve_claim($1,$2)`, [c, coord]);
    await err(() => one(`SELECT approve_claim($1,$2)`, [c, coord]), 'CLAIM_NOT_PENDING');
    assert.equal(Number(await bal(aliceW)), 375);
  });

  test('payment request: pays once, rejects insufficient and expired', async () => {
    const r1 = (await one(`INSERT INTO payment_requests(org_id,amount,expires_at) VALUES ($1,200,now()+interval '5 min') RETURNING id`, [prov])).id;
    await one(`SELECT pay_request($1,$2)`, [r1, alice]);
    await err(() => one(`SELECT pay_request($1,$2)`, [r1, alice]), 'REQUEST_NOT_OPEN');
    assert.equal(Number(await bal(aliceW)), 175);
    assert.equal(Number(await bal(provW)), 200);
    const big = (await one(`INSERT INTO payment_requests(org_id,amount,expires_at) VALUES ($1,99999,now()+interval '5 min') RETURNING id`, [prov])).id;
    await err(() => one(`SELECT pay_request($1,$2)`, [big, alice]), 'INSUFFICIENT_FUNDS');
    assert.equal((await one(`SELECT status FROM payment_requests WHERE id=$1`, [big])).status, 'open');
    const old = (await one(`INSERT INTO payment_requests(org_id,amount,expires_at) VALUES ($1,1,now()-interval '1 min') RETURNING id`, [prov])).id;
    await err(() => one(`SELECT pay_request($1,$2)`, [old, alice]), 'REQUEST_EXPIRED');
  });

  test('pay codes are single-use and respect limits', async () => {
    await q(`INSERT INTO pay_codes(nonce,user_id,max_amount,expires_at) VALUES ('n1',$1,50,now()+interval '1 min')`, [alice]);
    await err(() => one(`SELECT redeem_pay_code('n1',$1,60,$2,'x')`, [prov, coord]), 'CODE_LIMIT');
    await one(`SELECT redeem_pay_code('n1',$1,50,$2,'x')`, [prov, coord]);
    await err(() => one(`SELECT redeem_pay_code('n1',$1,10,$2,'x')`, [prov, coord]), 'CODE_USED');
    await q(`INSERT INTO pay_codes(nonce,user_id,expires_at) VALUES ('n2',$1,now()-interval '1 s')`, [alice]);
    await err(() => one(`SELECT redeem_pay_code('n2',$1,10,$2,'x')`, [prov, coord]), 'CODE_EXPIRED');
    assert.equal(Number(await bal(aliceW)), 125);
  });

  test('unbalanced legs are rejected', async () => {
    await err(() => one(`SELECT post_txn('transfer','manual','x',NULL,$1)`, [JSON.stringify([{ wallet_id: aliceW, amount: -10 }, { wallet_id: provW, amount: 11 }])]), 'LEDGER_UNBALANCED');
  });

  test('concurrent spends never overdraw (row locking)', async () => {
    // Alice has 125. Fire 20 concurrent 10-credit payments: exactly 12 may succeed.
    const results = await Promise.allSettled(Array.from({ length: 20 }, () =>
      pool.query(`SELECT post_txn('payment','direct','race',NULL,$1)`, [JSON.stringify([{ wallet_id: aliceW, amount: -10 }, { wallet_id: provW, amount: 10 }])])));
    const ok = results.filter((r) => r.status === 'fulfilled').length;
    assert.equal(ok, 12);
    assert.equal(Number(await bal(aliceW)), 5);
  });

  test('balance cap blocks minting above max_balance', async () => {
    await q(`UPDATE app_settings SET max_balance=100`);
    const c = await claim(alice, 600);
    await err(() => one(`SELECT approve_claim($1,$2)`, [c, coord]), 'BALANCE_CAP_EXCEEDED');
    assert.equal((await one(`SELECT status FROM hour_claims WHERE id=$1`, [c])).status, 'pending');
    await q(`UPDATE app_settings SET max_balance=NULL`);
  });

  test('reversal restores balances, only once; blocked if recipient spent it', async () => {
    const t = (await one(`SELECT post_txn('payment','direct','rev',NULL,$1) AS id`, [JSON.stringify([{ wallet_id: aliceW, amount: -5 }, { wallet_id: provW, amount: 5 }])])).id;
    await one(`SELECT reverse_txn($1,$2,'refund')`, [t, coord]);
    assert.equal(Number(await bal(aliceW)), 5);
    await err(() => one(`SELECT reverse_txn($1,$2,'again')`, [t, coord]), 'TXN_ALREADY_REVERSED');
    // Bob earns, spends everything, then the mint is reversed -> must fail (no negative balances)
    const c = await claim(bob, 60);
    const mint = (await one(`SELECT approve_claim($1,$2) AS id`, [c, coord])).id;
    const bobW = (await one(`SELECT id FROM wallets WHERE user_id=$1`, [bob])).id;
    await one(`SELECT post_txn('payment','direct','spend',NULL,$1)`, [JSON.stringify([{ wallet_id: bobW, amount: -150 }, { wallet_id: provW, amount: 150 }])]);
    await err(() => one(`SELECT reverse_txn($1,$2,'fraud')`, [mint, coord]), 'INSUFFICIENT_FUNDS');
  });

  test('ledger integrity: every txn nets to zero, balances match entries, total is zero', async () => {
    const i = await one(`SELECT * FROM ledger_integrity`);
    assert.equal(Number(i.wallet_mismatches), 0);
    assert.equal(Number(i.unbalanced_txns), 0);
    assert.equal(Number(i.total_sum), 0);
    const circ = await one(`SELECT -balance AS c FROM wallets WHERE system_key='issuance'`);
    const held = await one(`SELECT sum(balance) AS h FROM wallets WHERE owner_type<>'system'`);
    assert.equal(Number(circ.c), Number(held.h));
  });
}
