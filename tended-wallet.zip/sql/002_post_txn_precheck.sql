-- Check funds before updating so callers get INSUFFICIENT_FUNDS rather than a raw constraint error,
-- and aggregate legs per wallet so a wallet appearing twice is checked on its net change.
CREATE OR REPLACE FUNCTION post_txn(
  p_kind text, p_method text, p_memo text, p_created_by uuid,
  p_legs jsonb, p_ref_type text DEFAULT NULL, p_ref_id uuid DEFAULT NULL,
  p_reverses uuid DEFAULT NULL
) RETURNS uuid LANGUAGE plpgsql AS $$
DECLARE
  v_txn uuid; v_sum bigint; v_pos bigint; v_max bigint;
  v_leg record; v_w wallets%ROWTYPE; v_n int;
BEGIN
  SELECT coalesce(sum((l->>'amount')::bigint),0), coalesce(sum(greatest((l->>'amount')::bigint,0)),0)
    INTO v_sum, v_pos FROM jsonb_array_elements(p_legs) l;
  IF v_sum <> 0 THEN RAISE EXCEPTION 'LEDGER_UNBALANCED'; END IF;
  IF v_pos <= 0 THEN RAISE EXCEPTION 'LEDGER_EMPTY'; END IF;
  SELECT max_balance INTO v_max FROM app_settings WHERE id = 1;

  SELECT count(*) INTO v_n FROM (
    SELECT 1 FROM wallets WHERE id IN (SELECT (l->>'wallet_id')::uuid FROM jsonb_array_elements(p_legs) l)
    ORDER BY id FOR UPDATE) x;
  IF v_n <> (SELECT count(DISTINCT l->>'wallet_id') FROM jsonb_array_elements(p_legs) l) THEN
    RAISE EXCEPTION 'WALLET_NOT_FOUND';
  END IF;

  FOR v_leg IN SELECT (l->>'wallet_id')::uuid AS wid, sum((l->>'amount')::bigint) AS amt
                 FROM jsonb_array_elements(p_legs) l GROUP BY 1 LOOP
    SELECT * INTO v_w FROM wallets WHERE id = v_leg.wid;
    IF NOT v_w.allow_negative AND v_w.balance + v_leg.amt < 0 THEN RAISE EXCEPTION 'INSUFFICIENT_FUNDS'; END IF;
    IF v_leg.amt > 0 AND v_w.owner_type = 'user' AND v_max IS NOT NULL AND v_w.balance + v_leg.amt > v_max
       AND p_kind <> 'reversal' THEN RAISE EXCEPTION 'BALANCE_CAP_EXCEEDED'; END IF;
    UPDATE wallets SET balance = balance + v_leg.amt WHERE id = v_leg.wid;
  END LOOP;

  INSERT INTO txns (kind, method, memo, amount, created_by, ref_type, ref_id, reverses_txn_id)
    VALUES (p_kind, p_method, p_memo, v_pos, p_created_by, p_ref_type, p_ref_id, p_reverses)
    RETURNING id INTO v_txn;
  INSERT INTO entries (txn_id, wallet_id, amount)
    SELECT v_txn, (l->>'wallet_id')::uuid, (l->>'amount')::bigint FROM jsonb_array_elements(p_legs) l
    WHERE (l->>'amount')::bigint <> 0;
  RETURN v_txn;
END $$;
