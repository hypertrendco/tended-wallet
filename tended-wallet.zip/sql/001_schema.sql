-- Tended: community-care credit network
-- All credit amounts are BIGINT hundredths of a credit (1.00 credit = 100).

CREATE EXTENSION IF NOT EXISTS pgcrypto;

CREATE TABLE app_settings (
  id              int PRIMARY KEY DEFAULT 1 CHECK (id = 1),
  network_name    text   NOT NULL DEFAULT 'Tended Community Network',
  base_rate       bigint NOT NULL DEFAULT 100,      -- credits per hour of service (hundredths)
  p2p_enabled     boolean NOT NULL DEFAULT true,     -- members may gift credits to each other
  daily_minute_cap int   NOT NULL DEFAULT 720,       -- claims above this per member/day are flagged
  card_tx_limit   bigint NOT NULL DEFAULT 5000,      -- max per NFC card tap (hundredths)
  pay_code_ttl_sec int   NOT NULL DEFAULT 90,
  request_ttl_min int    NOT NULL DEFAULT 15,
  max_balance     bigint,                            -- optional cap on member balances (null = none)
  updated_at      timestamptz NOT NULL DEFAULT now()
);
INSERT INTO app_settings (id) VALUES (1);

CREATE TABLE users (
  id          uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  auth_sub    text UNIQUE,
  email       text NOT NULL UNIQUE,
  name        text,
  phone       text,
  is_admin    boolean NOT NULL DEFAULT false,
  status      text NOT NULL DEFAULT 'active' CHECK (status IN ('active','suspended')),
  created_at  timestamptz NOT NULL DEFAULT now()
);

CREATE TABLE orgs (
  id          uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  name        text NOT NULL,
  kind        text NOT NULL CHECK (kind IN ('verifier','provider','both')),
  status      text NOT NULL DEFAULT 'pending' CHECK (status IN ('pending','active','suspended','rejected')),
  description text,
  address     text,
  npi         text,
  website     text,
  created_by  uuid REFERENCES users(id),
  created_at  timestamptz NOT NULL DEFAULT now()
);

CREATE TABLE org_members (
  org_id   uuid NOT NULL REFERENCES orgs(id) ON DELETE CASCADE,
  user_id  uuid NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  role     text NOT NULL DEFAULT 'staff' CHECK (role IN ('owner','staff')),
  PRIMARY KEY (org_id, user_id)
);

CREATE TABLE wallets (
  id             uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  owner_type     text NOT NULL CHECK (owner_type IN ('user','org','system')),
  user_id        uuid UNIQUE REFERENCES users(id),
  org_id         uuid UNIQUE REFERENCES orgs(id),
  system_key     text UNIQUE,
  balance        bigint NOT NULL DEFAULT 0,
  allow_negative boolean NOT NULL DEFAULT false,
  created_at     timestamptz NOT NULL DEFAULT now(),
  CHECK (allow_negative OR balance >= 0)
);
-- The issuance wallet is where credits are minted from; its (negative) balance = credits in circulation.
INSERT INTO wallets (owner_type, system_key, allow_negative) VALUES ('system','issuance', true);

CREATE TABLE txns (
  id              uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  kind            text NOT NULL CHECK (kind IN ('mint','payment','transfer','reversal','retire','adjustment')),
  method          text NOT NULL DEFAULT 'manual',
  memo            text,
  amount          bigint NOT NULL CHECK (amount > 0),
  created_by      uuid REFERENCES users(id),
  ref_type        text,
  ref_id          uuid,
  reverses_txn_id uuid REFERENCES txns(id),
  reversed        boolean NOT NULL DEFAULT false,
  created_at      timestamptz NOT NULL DEFAULT now()
);
CREATE INDEX txns_created_idx ON txns (created_at DESC);

CREATE TABLE entries (
  id         bigserial PRIMARY KEY,
  txn_id     uuid NOT NULL REFERENCES txns(id),
  wallet_id  uuid NOT NULL REFERENCES wallets(id),
  amount     bigint NOT NULL CHECK (amount <> 0),
  created_at timestamptz NOT NULL DEFAULT now()
);
CREATE INDEX entries_wallet_idx ON entries (wallet_id, created_at DESC);
CREATE INDEX entries_txn_idx ON entries (txn_id);

CREATE TABLE activity_types (
  id          uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  name        text NOT NULL UNIQUE,
  multiplier  numeric(6,2) NOT NULL DEFAULT 1.00 CHECK (multiplier > 0),
  description text,
  active      boolean NOT NULL DEFAULT true
);
INSERT INTO activity_types (name, multiplier, description) VALUES
  ('General volunteering', 1.00, 'Standard community service hour'),
  ('Food security', 1.00, 'Food bank, pantry, meal delivery'),
  ('Elder & caregiver support', 1.25, 'Companionship, respite, errands for older adults'),
  ('Health outreach', 1.50, 'Screenings, health fairs, community health worker support'),
  ('Skilled / licensed service', 2.00, 'Licensed professional services (e.g., RN, CPR instruction)');

CREATE TABLE opportunities (
  id               uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  org_id           uuid NOT NULL REFERENCES orgs(id) ON DELETE CASCADE,
  title            text NOT NULL,
  description      text,
  activity_type_id uuid NOT NULL REFERENCES activity_types(id),
  location         text,
  starts_at        timestamptz,
  ends_at          timestamptz,
  capacity         int,
  checkin_code     text NOT NULL UNIQUE DEFAULT encode(gen_random_bytes(9), 'hex'),
  active           boolean NOT NULL DEFAULT true,
  created_at       timestamptz NOT NULL DEFAULT now()
);

CREATE TABLE hour_claims (
  id               uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id          uuid NOT NULL REFERENCES users(id),
  org_id           uuid NOT NULL REFERENCES orgs(id),
  opportunity_id   uuid REFERENCES opportunities(id),
  activity_type_id uuid NOT NULL REFERENCES activity_types(id),
  description      text,
  work_date        date NOT NULL DEFAULT current_date,
  minutes          int CHECK (minutes IS NULL OR (minutes > 0 AND minutes <= 1440)),
  source           text NOT NULL DEFAULT 'self' CHECK (source IN ('self','checkin','verifier')),
  checkin_at       timestamptz,
  checkout_at      timestamptz,
  status           text NOT NULL DEFAULT 'pending' CHECK (status IN ('open','pending','approved','rejected')),
  credits          bigint,
  flagged          text,
  reviewed_by      uuid REFERENCES users(id),
  reviewed_at      timestamptz,
  review_note      text,
  txn_id           uuid REFERENCES txns(id),
  created_at       timestamptz NOT NULL DEFAULT now()
);
CREATE INDEX hour_claims_org_status ON hour_claims (org_id, status);
CREATE INDEX hour_claims_user ON hour_claims (user_id, created_at DESC);

CREATE TABLE catalog_items (
  id          uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  org_id      uuid NOT NULL REFERENCES orgs(id) ON DELETE CASCADE,
  name        text NOT NULL,
  description text,
  category    text NOT NULL DEFAULT 'service' CHECK (category IN ('service','product')),
  price       bigint NOT NULL CHECK (price > 0),
  active      boolean NOT NULL DEFAULT true,
  created_at  timestamptz NOT NULL DEFAULT now()
);

CREATE TABLE payment_requests (
  id          uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  org_id      uuid NOT NULL REFERENCES orgs(id),
  created_by  uuid REFERENCES users(id),
  amount      bigint NOT NULL CHECK (amount > 0),
  memo        text,
  items       jsonb NOT NULL DEFAULT '[]',
  status      text NOT NULL DEFAULT 'open' CHECK (status IN ('open','paid','cancelled')),
  expires_at  timestamptz NOT NULL,
  paid_by     uuid REFERENCES users(id),
  txn_id      uuid REFERENCES txns(id),
  created_at  timestamptz NOT NULL DEFAULT now()
);

CREATE TABLE pay_codes (
  nonce       text PRIMARY KEY,
  user_id     uuid NOT NULL REFERENCES users(id),
  max_amount  bigint,
  expires_at  timestamptz NOT NULL,
  used_at     timestamptz,
  txn_id      uuid REFERENCES txns(id),
  created_at  timestamptz NOT NULL DEFAULT now()
);

CREATE TABLE nfc_cards (
  id              uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id         uuid NOT NULL REFERENCES users(id),
  card_token      text NOT NULL UNIQUE,
  pin_hash        text NOT NULL,
  label           text,
  status          text NOT NULL DEFAULT 'active' CHECK (status IN ('active','frozen')),
  failed_attempts int NOT NULL DEFAULT 0,
  last_used_at    timestamptz,
  created_at      timestamptz NOT NULL DEFAULT now()
);

CREATE TABLE settlement_requests (
  id          uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  org_id      uuid NOT NULL REFERENCES orgs(id),
  amount      bigint NOT NULL CHECK (amount > 0),
  note        text,
  status      text NOT NULL DEFAULT 'pending' CHECK (status IN ('pending','settled','rejected')),
  requested_by uuid REFERENCES users(id),
  reviewed_by uuid REFERENCES users(id),
  reviewed_at timestamptz,
  txn_id      uuid REFERENCES txns(id),
  created_at  timestamptz NOT NULL DEFAULT now()
);

CREATE TABLE audit_log (
  id         bigserial PRIMARY KEY,
  actor_id   uuid REFERENCES users(id),
  action     text NOT NULL,
  detail     jsonb NOT NULL DEFAULT '{}',
  created_at timestamptz NOT NULL DEFAULT now()
);

-- ---------------------------------------------------------------------------
-- Ledger core: post a balanced transaction atomically.
-- legs: [{"wallet_id": "...", "amount": -500}, {"wallet_id": "...", "amount": 500}]
-- ---------------------------------------------------------------------------
CREATE OR REPLACE FUNCTION post_txn(
  p_kind text, p_method text, p_memo text, p_created_by uuid,
  p_legs jsonb, p_ref_type text DEFAULT NULL, p_ref_id uuid DEFAULT NULL,
  p_reverses uuid DEFAULT NULL
) RETURNS uuid LANGUAGE plpgsql AS $$
DECLARE
  v_txn uuid;
  v_sum bigint;
  v_pos bigint;
  v_leg record;
  v_w wallets%ROWTYPE;
  v_max bigint;
BEGIN
  SELECT coalesce(sum((l->>'amount')::bigint),0),
         coalesce(sum(greatest((l->>'amount')::bigint,0)),0)
    INTO v_sum, v_pos FROM jsonb_array_elements(p_legs) l;
  IF v_sum <> 0 THEN RAISE EXCEPTION 'LEDGER_UNBALANCED'; END IF;
  IF v_pos <= 0 THEN RAISE EXCEPTION 'LEDGER_EMPTY'; END IF;

  SELECT max_balance INTO v_max FROM app_settings WHERE id = 1;

  -- lock wallets in a stable order to avoid deadlocks
  PERFORM 1 FROM wallets
    WHERE id IN (SELECT (l->>'wallet_id')::uuid FROM jsonb_array_elements(p_legs) l)
    ORDER BY id FOR UPDATE;

  INSERT INTO txns (kind, method, memo, amount, created_by, ref_type, ref_id, reverses_txn_id)
    VALUES (p_kind, p_method, p_memo, v_pos, p_created_by, p_ref_type, p_ref_id, p_reverses)
    RETURNING id INTO v_txn;

  FOR v_leg IN SELECT (l->>'wallet_id')::uuid AS wid, (l->>'amount')::bigint AS amt
                 FROM jsonb_array_elements(p_legs) l LOOP
    UPDATE wallets SET balance = balance + v_leg.amt WHERE id = v_leg.wid RETURNING * INTO v_w;
    IF NOT FOUND THEN RAISE EXCEPTION 'WALLET_NOT_FOUND'; END IF;
    IF NOT v_w.allow_negative AND v_w.balance < 0 THEN RAISE EXCEPTION 'INSUFFICIENT_FUNDS'; END IF;
    IF v_leg.amt > 0 AND v_w.owner_type = 'user' AND v_max IS NOT NULL AND v_w.balance > v_max
       AND p_kind <> 'reversal' THEN
      RAISE EXCEPTION 'BALANCE_CAP_EXCEEDED';
    END IF;
    INSERT INTO entries (txn_id, wallet_id, amount) VALUES (v_txn, v_leg.wid, v_leg.amt);
  END LOOP;
  RETURN v_txn;
END $$;

CREATE OR REPLACE FUNCTION issuance_wallet() RETURNS uuid LANGUAGE sql STABLE AS
$$ SELECT id FROM wallets WHERE system_key = 'issuance' $$;

-- Approve an hour claim: compute credits from base rate x multiplier and mint to the member.
CREATE OR REPLACE FUNCTION approve_claim(p_claim uuid, p_reviewer uuid, p_note text DEFAULT NULL)
RETURNS uuid LANGUAGE plpgsql AS $$
DECLARE
  c hour_claims%ROWTYPE;
  v_mult numeric; v_rate bigint; v_credits bigint; v_wallet uuid; v_txn uuid;
BEGIN
  SELECT * INTO c FROM hour_claims WHERE id = p_claim FOR UPDATE;
  IF NOT FOUND THEN RAISE EXCEPTION 'CLAIM_NOT_FOUND'; END IF;
  IF c.status <> 'pending' THEN RAISE EXCEPTION 'CLAIM_NOT_PENDING'; END IF;
  IF c.minutes IS NULL THEN RAISE EXCEPTION 'CLAIM_NO_MINUTES'; END IF;
  IF c.user_id = p_reviewer THEN RAISE EXCEPTION 'SELF_APPROVAL'; END IF;
  SELECT multiplier INTO v_mult FROM activity_types WHERE id = c.activity_type_id;
  SELECT base_rate INTO v_rate FROM app_settings WHERE id = 1;
  v_credits := round(c.minutes::numeric / 60 * v_rate * v_mult);
  IF v_credits <= 0 THEN RAISE EXCEPTION 'CLAIM_ZERO_CREDITS'; END IF;
  SELECT id INTO v_wallet FROM wallets WHERE user_id = c.user_id;
  v_txn := post_txn('mint', 'claim',
    format('%s min service', c.minutes), p_reviewer,
    jsonb_build_array(
      jsonb_build_object('wallet_id', issuance_wallet(), 'amount', -v_credits),
      jsonb_build_object('wallet_id', v_wallet, 'amount', v_credits)),
    'hour_claim', c.id);
  UPDATE hour_claims SET status='approved', credits=v_credits, reviewed_by=p_reviewer,
    reviewed_at=now(), review_note=p_note, txn_id=v_txn WHERE id = c.id;
  RETURN v_txn;
END $$;

-- Member pays an open payment request (QR charge).
CREATE OR REPLACE FUNCTION pay_request(p_req uuid, p_payer uuid)
RETURNS uuid LANGUAGE plpgsql AS $$
DECLARE r payment_requests%ROWTYPE; v_from uuid; v_to uuid; v_txn uuid;
BEGIN
  SELECT * INTO r FROM payment_requests WHERE id = p_req FOR UPDATE;
  IF NOT FOUND THEN RAISE EXCEPTION 'REQUEST_NOT_FOUND'; END IF;
  IF r.status <> 'open' THEN RAISE EXCEPTION 'REQUEST_NOT_OPEN'; END IF;
  IF r.expires_at < now() THEN RAISE EXCEPTION 'REQUEST_EXPIRED'; END IF;
  IF EXISTS (SELECT 1 FROM orgs WHERE id = r.org_id AND status <> 'active') THEN RAISE EXCEPTION 'PROVIDER_INACTIVE'; END IF;
  SELECT id INTO v_from FROM wallets WHERE user_id = p_payer;
  SELECT id INTO v_to FROM wallets WHERE org_id = r.org_id;
  v_txn := post_txn('payment','qr_request', r.memo, p_payer,
    jsonb_build_array(jsonb_build_object('wallet_id', v_from, 'amount', -r.amount),
                      jsonb_build_object('wallet_id', v_to, 'amount', r.amount)),
    'payment_request', r.id);
  UPDATE payment_requests SET status='paid', paid_by=p_payer, txn_id=v_txn WHERE id = r.id;
  RETURN v_txn;
END $$;

-- Provider redeems a member's one-time pay code.
CREATE OR REPLACE FUNCTION redeem_pay_code(p_nonce text, p_org uuid, p_amount bigint, p_staff uuid, p_memo text)
RETURNS uuid LANGUAGE plpgsql AS $$
DECLARE pc pay_codes%ROWTYPE; v_from uuid; v_to uuid; v_txn uuid;
BEGIN
  SELECT * INTO pc FROM pay_codes WHERE nonce = p_nonce FOR UPDATE;
  IF NOT FOUND THEN RAISE EXCEPTION 'CODE_INVALID'; END IF;
  IF pc.used_at IS NOT NULL THEN RAISE EXCEPTION 'CODE_USED'; END IF;
  IF pc.expires_at < now() THEN RAISE EXCEPTION 'CODE_EXPIRED'; END IF;
  IF pc.max_amount IS NOT NULL AND p_amount > pc.max_amount THEN RAISE EXCEPTION 'CODE_LIMIT'; END IF;
  SELECT id INTO v_from FROM wallets WHERE user_id = pc.user_id;
  SELECT id INTO v_to FROM wallets WHERE org_id = p_org;
  v_txn := post_txn('payment','pay_code', p_memo, p_staff,
    jsonb_build_array(jsonb_build_object('wallet_id', v_from, 'amount', -p_amount),
                      jsonb_build_object('wallet_id', v_to, 'amount', p_amount)),
    'pay_code', NULL);
  UPDATE pay_codes SET used_at = now(), txn_id = v_txn WHERE nonce = p_nonce;
  RETURN v_txn;
END $$;

-- Reverse a transaction (admin). Fails if a recipient no longer has the funds.
CREATE OR REPLACE FUNCTION reverse_txn(p_txn uuid, p_admin uuid, p_reason text)
RETURNS uuid LANGUAGE plpgsql AS $$
DECLARE t txns%ROWTYPE; v_legs jsonb; v_new uuid;
BEGIN
  SELECT * INTO t FROM txns WHERE id = p_txn FOR UPDATE;
  IF NOT FOUND THEN RAISE EXCEPTION 'TXN_NOT_FOUND'; END IF;
  IF t.reversed THEN RAISE EXCEPTION 'TXN_ALREADY_REVERSED'; END IF;
  IF t.kind = 'reversal' THEN RAISE EXCEPTION 'TXN_IS_REVERSAL'; END IF;
  SELECT jsonb_agg(jsonb_build_object('wallet_id', wallet_id, 'amount', -amount))
    INTO v_legs FROM entries WHERE txn_id = p_txn;
  v_new := post_txn('reversal','manual', p_reason, p_admin, v_legs, 'txn', p_txn, p_txn);
  UPDATE txns SET reversed = true WHERE id = p_txn;
  UPDATE hour_claims SET status='rejected', review_note = coalesce(review_note,'') || ' [reversed: ' || coalesce(p_reason,'') || ']'
    WHERE txn_id = p_txn;
  RETURN v_new;
END $$;

-- Integrity view: cached balances must equal sum of entries, and each txn must net to zero.
CREATE OR REPLACE VIEW ledger_integrity AS
SELECT
  (SELECT count(*) FROM wallets w WHERE w.balance <> coalesce((SELECT sum(amount) FROM entries e WHERE e.wallet_id = w.id),0)) AS wallet_mismatches,
  (SELECT count(*) FROM (SELECT txn_id FROM entries GROUP BY txn_id HAVING sum(amount) <> 0) x) AS unbalanced_txns,
  (SELECT coalesce(sum(balance),0) FROM wallets) AS total_sum;
